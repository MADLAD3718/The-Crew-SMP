// scripts/main.ts
import { DisplaySlotId, system as system30, world as world40 } from "@minecraft/server";

// scripts/block_components/waystone.ts
import { CustomForm, ObservableString, ObservableBoolean } from "@minecraft/server-ui";

// node_modules/@madlad3718/mcveclib/dist/index.js
import { Direction } from "@minecraft/server";
var Vec3;
((Vec32) => {
  Vec32.Zero = { x: 0, y: 0, z: 0 };
  Vec32.One = { x: 1, y: 1, z: 1 };
  Vec32.Up = { x: 0, y: 1, z: 0 };
  Vec32.Down = { x: 0, y: -1, z: 0 };
  Vec32.North = { x: 0, y: 0, z: -1 };
  Vec32.South = { x: 0, y: 0, z: 1 };
  Vec32.East = { x: 1, y: 0, z: 0 };
  Vec32.West = { x: -1, y: 0, z: 0 };
  Vec32.X = Vec32.East;
  Vec32.Y = Vec32.Up;
  Vec32.Z = Vec32.South;
  function isVector3(v) {
    return typeof v === "object" && "x" in v && "y" in v && "z" in v;
  }
  Vec32.isVector3 = isVector3;
  function from(x, y, z) {
    if (typeof x === "number") return {
      x,
      y: y ?? x,
      z: z ?? x
    };
    if (Array.isArray(x) && x.length >= 3) return {
      x: x[0],
      y: x[1],
      z: x[2]
    };
    throw new Error("Invalid input values for vector construction.");
  }
  Vec32.from = from;
  function fromVectorXZ(v) {
    return {
      x: v.x,
      y: 0,
      z: v.z
    };
  }
  Vec32.fromVectorXZ = fromVectorXZ;
  function toVectorXZ(v) {
    return {
      x: v.x,
      z: v.z
    };
  }
  Vec32.toVectorXZ = toVectorXZ;
  function fromBlockFace(face) {
    switch (face) {
      case "up":
        return Vec32.Up;
      case "down":
        return Vec32.Down;
      case "north":
        return Vec32.North;
      case "south":
        return Vec32.South;
      case "east":
        return Vec32.East;
      case "west":
        return Vec32.West;
    }
    throw new Error("Argument was not of type 'block_face' or 'cardinal_direction'.");
  }
  Vec32.fromBlockFace = fromBlockFace;
  function toBlockFace(v) {
    return toDirection(v).toLowerCase();
  }
  Vec32.toBlockFace = toBlockFace;
  function fromDirection(d) {
    switch (d) {
      case Direction.Up:
        return Vec32.Up;
      case Direction.Down:
        return Vec32.Down;
      case Direction.North:
        return Vec32.North;
      case Direction.South:
        return Vec32.South;
      case Direction.East:
        return Vec32.East;
      case Direction.West:
        return Vec32.West;
    }
  }
  Vec32.fromDirection = fromDirection;
  function toDirection(v) {
    const a = abs(v), max2 = Math.max(a.x, a.y, a.z);
    if (max2 === a.x)
      return v.x >= 0 ? Direction.East : Direction.West;
    else if (max2 === a.y)
      return v.y >= 0 ? Direction.Up : Direction.Down;
    else return v.z >= 0 ? Direction.South : Direction.North;
  }
  Vec32.toDirection = toDirection;
  function fromRGB(c) {
    return {
      x: c.red,
      y: c.green,
      z: c.blue
    };
  }
  Vec32.fromRGB = fromRGB;
  function toRGB(v) {
    return {
      red: v.x,
      green: v.y,
      blue: v.z
    };
  }
  Vec32.toRGB = toRGB;
  function toRotation(v) {
    return {
      x: -degrees(Math.asin(v.y)),
      y: -degrees(Math.atan2(v.x, v.z))
    };
  }
  Vec32.toRotation = toRotation;
  function degrees(radians) {
    return 180 * radians / Math.PI;
  }
  function toArray(v) {
    const { x, y, z } = v;
    return [x, y, z];
  }
  Vec32.toArray = toArray;
  function toString(v) {
    return toArray(v).join(" ");
  }
  Vec32.toString = toString;
  function parse(s) {
    const [x, y, z] = s.split(" ").map(Number);
    return { x, y, z };
  }
  Vec32.parse = parse;
  function isNaN(v) {
    return Number.isNaN(v.x) || Number.isNaN(v.y) || Number.isNaN(v.z);
  }
  Vec32.isNaN = isNaN;
  function isInf(v) {
    return !isFinite(v);
  }
  Vec32.isInf = isInf;
  function isFinite(v) {
    return Number.isFinite(v.x) && Number.isFinite(v.y) && Number.isFinite(v.z);
  }
  Vec32.isFinite = isFinite;
  function any(v) {
    return v.x !== 0 || v.y !== 0 || v.z !== 0;
  }
  Vec32.any = any;
  function all(v) {
    return v.x !== 0 && v.y !== 0 && v.z !== 0;
  }
  Vec32.all = all;
  function greaterThan(u, v) {
    return {
      x: u.x > v.x ? 1 : 0,
      y: u.y > v.y ? 1 : 0,
      z: u.z > v.z ? 1 : 0
    };
  }
  Vec32.greaterThan = greaterThan;
  function lessThan(u, v) {
    return {
      x: u.x < v.x ? 1 : 0,
      y: u.y < v.y ? 1 : 0,
      z: u.z < v.z ? 1 : 0
    };
  }
  Vec32.lessThan = lessThan;
  function greaterEqual(u, v) {
    return {
      x: u.x >= v.x ? 1 : 0,
      y: u.y >= v.y ? 1 : 0,
      z: u.z >= v.z ? 1 : 0
    };
  }
  Vec32.greaterEqual = greaterEqual;
  function lessEqual(u, v) {
    return {
      x: u.x <= v.x ? 1 : 0,
      y: u.y <= v.y ? 1 : 0,
      z: u.z <= v.z ? 1 : 0
    };
  }
  Vec32.lessEqual = lessEqual;
  function equal(u, v) {
    return u.x === v.x && u.y === v.y && u.z === v.z;
  }
  Vec32.equal = equal;
  function min(u, v) {
    return {
      x: Math.min(u.x, v.x),
      y: Math.min(u.y, v.y),
      z: Math.min(u.z, v.z)
    };
  }
  Vec32.min = min;
  function max(u, v) {
    return {
      x: Math.max(u.x, v.x),
      y: Math.max(u.y, v.y),
      z: Math.max(u.z, v.z)
    };
  }
  Vec32.max = max;
  function clamp2(v, min2, max2) {
    return {
      x: Math.min(Math.max(v.x, min2.x), max2.x),
      y: Math.min(Math.max(v.y, min2.y), max2.y),
      z: Math.min(Math.max(v.z, min2.z), max2.z)
    };
  }
  Vec32.clamp = clamp2;
  function saturate(v) {
    return {
      x: Math.min(Math.max(v.x, 0), 1),
      y: Math.min(Math.max(v.y, 0), 1),
      z: Math.min(Math.max(v.z, 0), 1)
    };
  }
  Vec32.saturate = saturate;
  function sign(v) {
    return {
      x: Math.sign(v.x),
      y: Math.sign(v.y),
      z: Math.sign(v.z)
    };
  }
  Vec32.sign = sign;
  function floor(v) {
    return {
      x: Math.floor(v.x),
      y: Math.floor(v.y),
      z: Math.floor(v.z)
    };
  }
  Vec32.floor = floor;
  function ceil(v) {
    return {
      x: Math.ceil(v.x),
      y: Math.ceil(v.y),
      z: Math.ceil(v.z)
    };
  }
  Vec32.ceil = ceil;
  function frac(v) {
    return {
      x: v.x - Math.floor(v.x),
      y: v.y - Math.floor(v.y),
      z: v.z - Math.floor(v.z)
    };
  }
  Vec32.frac = frac;
  function round(v) {
    return {
      x: Math.round(v.x),
      y: Math.round(v.y),
      z: Math.round(v.z)
    };
  }
  Vec32.round = round;
  function mod(u, v) {
    return {
      x: u.x % v.x,
      y: u.y % v.y,
      z: u.z % v.z
    };
  }
  Vec32.mod = mod;
  function neg(v) {
    return {
      x: -v.x,
      y: -v.y,
      z: -v.z
    };
  }
  Vec32.neg = neg;
  function abs(v) {
    return {
      x: Math.abs(v.x),
      y: Math.abs(v.y),
      z: Math.abs(v.z)
    };
  }
  Vec32.abs = abs;
  function add(v, ...args) {
    for (const arg of args) v = {
      x: v.x + arg.x,
      y: v.y + arg.y,
      z: v.z + arg.z
    };
    return v;
  }
  Vec32.add = add;
  function sub(v, ...args) {
    for (const arg of args) v = {
      x: v.x - arg.x,
      y: v.y - arg.y,
      z: v.z - arg.z
    };
    return v;
  }
  Vec32.sub = sub;
  function mul(v, m) {
    if (isVector3(m)) return {
      x: v.x * m.x,
      y: v.y * m.y,
      z: v.z * m.z
    };
    else return {
      x: v.x * m,
      y: v.y * m,
      z: v.z * m
    };
  }
  Vec32.mul = mul;
  function div(v, m) {
    if (isVector3(m)) return {
      x: v.x / m.x,
      y: v.y / m.y,
      z: v.z / m.z
    };
    else return {
      x: v.x / m,
      y: v.y / m,
      z: v.z / m
    };
  }
  Vec32.div = div;
  function sqrt(v) {
    return {
      x: Math.sqrt(v.x),
      y: Math.sqrt(v.y),
      z: Math.sqrt(v.z)
    };
  }
  Vec32.sqrt = sqrt;
  function exp(v) {
    return {
      x: Math.exp(v.x),
      y: Math.exp(v.y),
      z: Math.exp(v.z)
    };
  }
  Vec32.exp = exp;
  function exp2(v) {
    return {
      x: Math.pow(2, v.x),
      y: Math.pow(2, v.y),
      z: Math.pow(2, v.z)
    };
  }
  Vec32.exp2 = exp2;
  function log(v) {
    return {
      x: Math.log(v.x),
      y: Math.log(v.y),
      z: Math.log(v.z)
    };
  }
  Vec32.log = log;
  function log2(v) {
    return {
      x: Math.log2(v.x),
      y: Math.log2(v.y),
      z: Math.log2(v.z)
    };
  }
  Vec32.log2 = log2;
  function log10(v) {
    return {
      x: Math.log10(v.x),
      y: Math.log10(v.y),
      z: Math.log10(v.z)
    };
  }
  Vec32.log10 = log10;
  function pow(v, p) {
    if (isVector3(p)) return {
      x: Math.pow(v.x, p.x),
      y: Math.pow(v.y, p.y),
      z: Math.pow(v.z, p.z)
    };
    else return {
      x: Math.pow(v.x, p),
      y: Math.pow(v.y, p),
      z: Math.pow(v.z, p)
    };
  }
  Vec32.pow = pow;
  function sin(v) {
    return {
      x: Math.sin(v.x),
      y: Math.sin(v.y),
      z: Math.sin(v.z)
    };
  }
  Vec32.sin = sin;
  function asin(v) {
    return {
      x: Math.asin(v.x),
      y: Math.asin(v.y),
      z: Math.asin(v.z)
    };
  }
  Vec32.asin = asin;
  function sinh(v) {
    return {
      x: Math.sinh(v.x),
      y: Math.sinh(v.y),
      z: Math.sinh(v.z)
    };
  }
  Vec32.sinh = sinh;
  function asinh(v) {
    return {
      x: Math.asinh(v.x),
      y: Math.asinh(v.y),
      z: Math.asinh(v.z)
    };
  }
  Vec32.asinh = asinh;
  function cos(v) {
    return {
      x: Math.cos(v.x),
      y: Math.cos(v.y),
      z: Math.cos(v.z)
    };
  }
  Vec32.cos = cos;
  function acos(v) {
    return {
      x: Math.acos(v.x),
      y: Math.acos(v.y),
      z: Math.acos(v.z)
    };
  }
  Vec32.acos = acos;
  function cosh(v) {
    return {
      x: Math.cosh(v.x),
      y: Math.cosh(v.y),
      z: Math.cosh(v.z)
    };
  }
  Vec32.cosh = cosh;
  function acosh(v) {
    return {
      x: Math.acosh(v.x),
      y: Math.acosh(v.y),
      z: Math.acosh(v.z)
    };
  }
  Vec32.acosh = acosh;
  function tan(v) {
    return {
      x: Math.tan(v.x),
      y: Math.tan(v.y),
      z: Math.tan(v.z)
    };
  }
  Vec32.tan = tan;
  function atan(v) {
    return {
      x: Math.atan(v.x),
      y: Math.atan(v.y),
      z: Math.atan(v.z)
    };
  }
  Vec32.atan = atan;
  function tanh(v) {
    return {
      x: Math.tanh(v.x),
      y: Math.tanh(v.y),
      z: Math.tanh(v.z)
    };
  }
  Vec32.tanh = tanh;
  function atanh(v) {
    return {
      x: Math.atanh(v.x),
      y: Math.atanh(v.y),
      z: Math.atanh(v.z)
    };
  }
  Vec32.atanh = atanh;
  function above(v, s = 1) {
    return add(v, mul(Vec32.Up, s));
  }
  Vec32.above = above;
  function below(v, s = 1) {
    return add(v, mul(Vec32.Down, s));
  }
  Vec32.below = below;
  function north(v, s = 1) {
    return add(v, mul(Vec32.North, s));
  }
  Vec32.north = north;
  function south(v, s = 1) {
    return add(v, mul(Vec32.South, s));
  }
  Vec32.south = south;
  function east(v, s = 1) {
    return add(v, mul(Vec32.East, s));
  }
  Vec32.east = east;
  function west(v, s = 1) {
    return add(v, mul(Vec32.West, s));
  }
  Vec32.west = west;
  function dot(u, v) {
    return u.x * v.x + u.y * v.y + u.z * v.z;
  }
  Vec32.dot = dot;
  function cross(u, v) {
    return {
      x: u.y * v.z - u.z * v.y,
      y: u.z * v.x - u.x * v.z,
      z: u.x * v.y - u.y * v.x
    };
  }
  Vec32.cross = cross;
  function length(v) {
    return Math.hypot(v.x, v.y, v.z);
  }
  Vec32.length = length;
  function normalize(v) {
    return div(v, length(v));
  }
  Vec32.normalize = normalize;
  function distance(u, v) {
    return length(sub(u, v));
  }
  Vec32.distance = distance;
  function project(u, v) {
    return mul(v, dot(u, v) / dot(v, v));
  }
  Vec32.project = project;
  function reject(u, v) {
    return sub(u, project(u, v));
  }
  Vec32.reject = reject;
  function reflect(i, n) {
    return sub(i, mul(n, 2 * dot(n, i)));
  }
  Vec32.reflect = reflect;
  function refract(i, n, eta) {
    const cosi = -dot(i, n);
    const sin2t = eta * eta * (1 - cosi * cosi);
    const cost = Math.sqrt(1 - sin2t);
    return add(mul(i, eta), mul(n, eta * cosi - cost));
  }
  Vec32.refract = refract;
  function lerp2(u, v, t) {
    if (t === 0) return u;
    if (t === 1) return v;
    return {
      x: u.x + t * (v.x - u.x),
      y: u.y + t * (v.y - u.y),
      z: u.z + t * (v.z - u.z)
    };
  }
  Vec32.lerp = lerp2;
  function slerp(u, v, t) {
    if (t === 0) return u;
    if (t === 1) return v;
    const cost = dot(u, v);
    const theta = Math.acos(cost);
    const sint = Math.sqrt(1 - cost * cost);
    const tu = Math.sin((1 - t) * theta) / sint;
    const tv = Math.sin(t * theta) / sint;
    return add(mul(u, tu), mul(v, tv));
  }
  Vec32.slerp = slerp;
  function rotate(v, k, t) {
    const cost = Math.cos(t), sint = Math.sin(t);
    const par = mul(k, dot(v, k)), per = sub(v, par), kxv = cross(k, v);
    return add(par, add(mul(per, cost), mul(kxv, sint)));
  }
  Vec32.rotate = rotate;
})(Vec3 || (Vec3 = {}));
var Mat3;
((Mat32) => {
  Mat32.Identity = {
    m11: 1,
    m12: 0,
    m13: 0,
    m21: 0,
    m22: 1,
    m23: 0,
    m31: 0,
    m32: 0,
    m33: 1
  };
  function isMatrix3(m) {
    return typeof m === "object" && "m11" in m && "m12" in m && "m13" in m && "m21" in m && "m22" in m && "m23" in m && "m31" in m && "m32" in m && "m33" in m;
  }
  Mat32.isMatrix3 = isMatrix3;
  function from(u, v, w) {
    if (Array.isArray(u) && u.length >= 9) return {
      m11: u[0],
      m12: u[1],
      m13: u[2],
      m21: u[3],
      m22: u[4],
      m23: u[5],
      m31: u[6],
      m32: u[7],
      m33: u[8]
    };
    if (Vec3.isVector3(u) && v && w) return {
      m11: u.x,
      m12: v.x,
      m13: w.x,
      m21: u.y,
      m22: v.y,
      m23: w.y,
      m31: u.z,
      m32: v.z,
      m33: w.z
    };
    throw new Error("Invalid input values for matrix construction.");
  }
  Mat32.from = from;
  function c1(m) {
    return {
      x: m.m11,
      y: m.m21,
      z: m.m31
    };
  }
  Mat32.c1 = c1;
  function c2(m) {
    return {
      x: m.m12,
      y: m.m22,
      z: m.m32
    };
  }
  Mat32.c2 = c2;
  function c3(m) {
    return {
      x: m.m13,
      y: m.m23,
      z: m.m33
    };
  }
  Mat32.c3 = c3;
  function r1(m) {
    return {
      x: m.m11,
      y: m.m12,
      z: m.m13
    };
  }
  Mat32.r1 = r1;
  function r2(m) {
    return {
      x: m.m21,
      y: m.m22,
      z: m.m23
    };
  }
  Mat32.r2 = r2;
  function r3(m) {
    return {
      x: m.m31,
      y: m.m32,
      z: m.m33
    };
  }
  Mat32.r3 = r3;
  function mul(m, t) {
    if (isMatrix3(t)) return {
      m11: Vec3.dot(r1(m), c1(t)),
      m12: Vec3.dot(r1(m), c2(t)),
      m13: Vec3.dot(r1(m), c3(t)),
      m21: Vec3.dot(r2(m), c1(t)),
      m22: Vec3.dot(r2(m), c2(t)),
      m23: Vec3.dot(r2(m), c3(t)),
      m31: Vec3.dot(r3(m), c1(t)),
      m32: Vec3.dot(r3(m), c2(t)),
      m33: Vec3.dot(r3(m), c3(t))
    };
    else if (Vec3.isVector3(t)) return {
      x: Vec3.dot(r1(m), t),
      y: Vec3.dot(r2(m), t),
      z: Vec3.dot(r3(m), t)
    };
    else return {
      m11: m.m11 * t,
      m12: m.m12 * t,
      m13: m.m13 * t,
      m21: m.m21 * t,
      m22: m.m22 * t,
      m23: m.m23 * t,
      m31: m.m31 * t,
      m32: m.m32 * t,
      m33: m.m33 * t
    };
  }
  Mat32.mul = mul;
  function trace(m) {
    return m.m11 + m.m22 + m.m33;
  }
  Mat32.trace = trace;
  function determinant(m) {
    return m.m11 * m.m22 * m.m33 + m.m21 * m.m32 * m.m13 + m.m31 * m.m12 * m.m23 - m.m13 * m.m22 * m.m31 - m.m23 * m.m32 * m.m11 - m.m33 * m.m12 * m.m21;
  }
  Mat32.determinant = determinant;
  function transpose(m) {
    return {
      m11: m.m11,
      m12: m.m21,
      m13: m.m31,
      m21: m.m12,
      m22: m.m22,
      m23: m.m32,
      m31: m.m13,
      m32: m.m23,
      m33: m.m33
    };
  }
  Mat32.transpose = transpose;
  function cofactor(m) {
    return {
      m11: m.m22 * m.m33 - m.m23 * m.m32,
      m12: m.m23 * m.m31 - m.m21 * m.m33,
      m13: m.m21 * m.m32 - m.m22 * m.m31,
      m21: m.m13 * m.m32 - m.m12 * m.m33,
      m22: m.m11 * m.m33 - m.m13 * m.m31,
      m23: m.m12 * m.m31 - m.m11 * m.m32,
      m31: m.m12 * m.m23 - m.m13 * m.m22,
      m32: m.m13 * m.m21 - m.m11 * m.m23,
      m33: m.m11 * m.m22 - m.m12 * m.m21
    };
  }
  Mat32.cofactor = cofactor;
  function adjugate(m) {
    return {
      m11: m.m22 * m.m33 - m.m23 * m.m32,
      m12: m.m13 * m.m32 - m.m12 * m.m33,
      m13: m.m12 * m.m23 - m.m13 * m.m22,
      m21: m.m23 * m.m31 - m.m21 * m.m33,
      m22: m.m11 * m.m33 - m.m13 * m.m31,
      m23: m.m13 * m.m21 - m.m11 * m.m23,
      m31: m.m21 * m.m32 - m.m22 * m.m31,
      m32: m.m12 * m.m31 - m.m11 * m.m32,
      m33: m.m11 * m.m22 - m.m12 * m.m21
    };
  }
  Mat32.adjugate = adjugate;
  function inverse(m) {
    const det = determinant(m);
    if (det === 0) throw new Error("Matrix is not invertible.");
    return mul(adjugate(m), 1 / det);
  }
  Mat32.inverse = inverse;
  function buildTNB(n) {
    const t = Math.abs(n.y) === 1 ? Vec3.East : Vec3.normalize(Vec3.from(n.z, 0, -n.x));
    const b = Vec3.cross(n, t);
    return from(t, n, b);
  }
  Mat32.buildTNB = buildTNB;
})(Mat3 || (Mat3 = {}));
var Mat2;
((Mat22) => {
  Mat22.Identity = {
    m11: 1,
    m12: 0,
    m21: 0,
    m22: 1
  };
  function isMatrix2(m) {
    return typeof m === "object" && "m11" in m && "m12" in m && "m21" in m && "m22" in m;
  }
  Mat22.isMatrix2 = isMatrix2;
  function from(u, v) {
    if (Array.isArray(u) && u.length >= 4) return {
      m11: u[0],
      m12: u[1],
      m21: u[2],
      m22: u[3]
    };
    if (Vec2.isVector2(u) && v) return {
      m11: u.x,
      m12: v.x,
      m21: u.y,
      m22: v.y
    };
    throw new Error("Invalid input values for matrix construction.");
  }
  Mat22.from = from;
  function c1(m) {
    return {
      x: m.m11,
      y: m.m21
    };
  }
  Mat22.c1 = c1;
  function c2(m) {
    return {
      x: m.m12,
      y: m.m22
    };
  }
  Mat22.c2 = c2;
  function r1(m) {
    return {
      x: m.m11,
      y: m.m12
    };
  }
  Mat22.r1 = r1;
  function r2(m) {
    return {
      x: m.m21,
      y: m.m22
    };
  }
  Mat22.r2 = r2;
  function mul(m, t) {
    if (isMatrix2(t)) return {
      m11: Vec2.dot(r1(m), c1(t)),
      m12: Vec2.dot(r1(m), c2(t)),
      m21: Vec2.dot(r2(m), c1(t)),
      m22: Vec2.dot(r2(m), c2(t))
    };
    else if (Vec2.isVector2(t)) return {
      x: Vec2.dot(r1(m), t),
      y: Vec2.dot(r2(m), t)
    };
    else return {
      m11: m.m11 * t,
      m12: m.m12 * t,
      m21: m.m21 * t,
      m22: m.m22 * t
    };
  }
  Mat22.mul = mul;
  function trace(m) {
    return m.m11 + m.m22;
  }
  Mat22.trace = trace;
  function determinant(m) {
    return m.m11 * m.m22 - m.m12 * m.m21;
  }
  Mat22.determinant = determinant;
  function transpose(m) {
    return {
      m11: m.m11,
      m12: m.m21,
      m21: m.m12,
      m22: m.m22
    };
  }
  Mat22.transpose = transpose;
  function cofactor(m) {
    return {
      m11: m.m22,
      m12: -m.m21,
      m21: -m.m12,
      m22: m.m11
    };
  }
  Mat22.cofactor = cofactor;
  function adjugate(m) {
    return {
      m11: m.m22,
      m12: -m.m12,
      m21: -m.m21,
      m22: m.m11
    };
  }
  Mat22.adjugate = adjugate;
  function inverse(m) {
    const det = determinant(m);
    if (det === 0) throw new Error("Matrix is not invertible.");
    return mul(adjugate(m), 1 / det);
  }
  Mat22.inverse = inverse;
})(Mat2 || (Mat2 = {}));
var Vec2;
((Vec22) => {
  Vec22.Zero = { x: 0, y: 0 };
  Vec22.One = { x: 1, y: 1 };
  Vec22.Up = { x: 0, y: 1 };
  Vec22.Down = { x: 0, y: -1 };
  Vec22.Left = { x: -1, y: 0 };
  Vec22.Right = { x: 1, y: 0 };
  Vec22.X = Vec22.Right;
  Vec22.Y = Vec22.Up;
  function isVector2(v) {
    return typeof v === "object" && "x" in v && "y" in v;
  }
  Vec22.isVector2 = isVector2;
  function from(x, y) {
    if (Array.isArray(x) && x.length >= 2) return {
      x: x[0],
      y: x[1]
    };
    else if (typeof x === "number") return {
      x,
      y: y ?? x
    };
    throw new Error("Invalid input values for vector construction.");
  }
  Vec22.from = from;
  function fromVectorXZ(v) {
    return {
      x: v.x,
      y: v.z
    };
  }
  Vec22.fromVectorXZ = fromVectorXZ;
  function toVectorXZ(v) {
    return {
      x: v.x,
      z: v.y
    };
  }
  Vec22.toVectorXZ = toVectorXZ;
  function toArray(v) {
    const { x, y } = v;
    return [x, y];
  }
  Vec22.toArray = toArray;
  function toString(v) {
    return toArray(v).join(" ");
  }
  Vec22.toString = toString;
  function parse(s) {
    const [x, y] = s.split(" ").map(Number);
    return { x, y };
  }
  Vec22.parse = parse;
  function isNaN(v) {
    return Number.isNaN(v.x) || Number.isNaN(v.y);
  }
  Vec22.isNaN = isNaN;
  function isInf(v) {
    return !isFinite(v);
  }
  Vec22.isInf = isInf;
  function isFinite(v) {
    return Number.isFinite(v.x) && Number.isFinite(v.y);
  }
  Vec22.isFinite = isFinite;
  function any(v) {
    return v.x !== 0 || v.y !== 0;
  }
  Vec22.any = any;
  function all(v) {
    return v.x !== 0 && v.y !== 0;
  }
  Vec22.all = all;
  function greaterThan(u, v) {
    return {
      x: u.x > v.x ? 1 : 0,
      y: u.y > v.y ? 1 : 0
    };
  }
  Vec22.greaterThan = greaterThan;
  function lessThan(u, v) {
    return {
      x: u.x < v.x ? 1 : 0,
      y: u.y < v.y ? 1 : 0
    };
  }
  Vec22.lessThan = lessThan;
  function greaterEqual(u, v) {
    return {
      x: u.x >= v.x ? 1 : 0,
      y: u.y >= v.y ? 1 : 0
    };
  }
  Vec22.greaterEqual = greaterEqual;
  function lessEqual(u, v) {
    return {
      x: u.x <= v.x ? 1 : 0,
      y: u.y <= v.y ? 1 : 0
    };
  }
  Vec22.lessEqual = lessEqual;
  function equal(u, v) {
    return u.x === v.x && u.y === v.y;
  }
  Vec22.equal = equal;
  function min(u, v) {
    return {
      x: Math.min(u.x, v.x),
      y: Math.min(u.y, v.y)
    };
  }
  Vec22.min = min;
  function max(u, v) {
    return {
      x: Math.max(u.x, v.x),
      y: Math.max(u.y, v.y)
    };
  }
  Vec22.max = max;
  function clamp2(v, min2, max2) {
    return {
      x: Math.min(Math.max(v.x, min2.x), max2.x),
      y: Math.min(Math.max(v.y, min2.y), max2.y)
    };
  }
  Vec22.clamp = clamp2;
  function saturate(v) {
    return {
      x: Math.min(Math.max(v.x, 0), 1),
      y: Math.min(Math.max(v.y, 0), 1)
    };
  }
  Vec22.saturate = saturate;
  function sign(v) {
    return {
      x: Math.sign(v.x),
      y: Math.sign(v.y)
    };
  }
  Vec22.sign = sign;
  function floor(v) {
    return {
      x: Math.floor(v.x),
      y: Math.floor(v.y)
    };
  }
  Vec22.floor = floor;
  function ceil(v) {
    return {
      x: Math.ceil(v.x),
      y: Math.ceil(v.y)
    };
  }
  Vec22.ceil = ceil;
  function frac(v) {
    return {
      x: v.x - Math.floor(v.x),
      y: v.y - Math.floor(v.y)
    };
  }
  Vec22.frac = frac;
  function round(v) {
    return {
      x: Math.round(v.x),
      y: Math.round(v.y)
    };
  }
  Vec22.round = round;
  function mod(u, v) {
    return {
      x: u.x % v.x,
      y: u.y % v.y
    };
  }
  Vec22.mod = mod;
  function neg(v) {
    return {
      x: -v.x,
      y: -v.y
    };
  }
  Vec22.neg = neg;
  function abs(v) {
    return {
      x: Math.abs(v.x),
      y: Math.abs(v.y)
    };
  }
  Vec22.abs = abs;
  function add(v, ...args) {
    for (const arg of args) v = {
      x: v.x + arg.x,
      y: v.y + arg.y
    };
    return v;
  }
  Vec22.add = add;
  function sub(v, ...args) {
    for (const arg of args) v = {
      x: v.x - arg.x,
      y: v.y - arg.y
    };
    return v;
  }
  Vec22.sub = sub;
  function mul(v, m) {
    if (isVector2(m)) return {
      x: v.x * m.x,
      y: v.y * m.y
    };
    else return {
      x: v.x * m,
      y: v.y * m
    };
  }
  Vec22.mul = mul;
  function div(v, m) {
    if (isVector2(m)) return {
      x: v.x / m.x,
      y: v.y / m.y
    };
    else return {
      x: v.x / m,
      y: v.y / m
    };
  }
  Vec22.div = div;
  function sqrt(v) {
    return {
      x: Math.sqrt(v.x),
      y: Math.sqrt(v.y)
    };
  }
  Vec22.sqrt = sqrt;
  function exp(v) {
    return {
      x: Math.exp(v.x),
      y: Math.exp(v.y)
    };
  }
  Vec22.exp = exp;
  function exp2(v) {
    return {
      x: Math.pow(2, v.x),
      y: Math.pow(2, v.y)
    };
  }
  Vec22.exp2 = exp2;
  function log(v) {
    return {
      x: Math.log(v.x),
      y: Math.log(v.y)
    };
  }
  Vec22.log = log;
  function log2(v) {
    return {
      x: Math.log2(v.x),
      y: Math.log2(v.y)
    };
  }
  Vec22.log2 = log2;
  function log10(v) {
    return {
      x: Math.log10(v.x),
      y: Math.log10(v.y)
    };
  }
  Vec22.log10 = log10;
  function pow(v, p) {
    if (isVector2(p)) return {
      x: Math.pow(v.x, p.x),
      y: Math.pow(v.y, p.y)
    };
    else return {
      x: Math.pow(v.x, p),
      y: Math.pow(v.y, p)
    };
  }
  Vec22.pow = pow;
  function sin(v) {
    return {
      x: Math.sin(v.x),
      y: Math.sin(v.y)
    };
  }
  Vec22.sin = sin;
  function asin(v) {
    return {
      x: Math.asin(v.x),
      y: Math.asin(v.y)
    };
  }
  Vec22.asin = asin;
  function sinh(v) {
    return {
      x: Math.sinh(v.x),
      y: Math.sinh(v.y)
    };
  }
  Vec22.sinh = sinh;
  function asinh(v) {
    return {
      x: Math.asinh(v.x),
      y: Math.asinh(v.y)
    };
  }
  Vec22.asinh = asinh;
  function cos(v) {
    return {
      x: Math.cos(v.x),
      y: Math.cos(v.y)
    };
  }
  Vec22.cos = cos;
  function acos(v) {
    return {
      x: Math.acos(v.x),
      y: Math.acos(v.y)
    };
  }
  Vec22.acos = acos;
  function cosh(v) {
    return {
      x: Math.cosh(v.x),
      y: Math.cosh(v.y)
    };
  }
  Vec22.cosh = cosh;
  function acosh(v) {
    return {
      x: Math.acosh(v.x),
      y: Math.acosh(v.y)
    };
  }
  Vec22.acosh = acosh;
  function tan(v) {
    return {
      x: Math.tan(v.x),
      y: Math.tan(v.y)
    };
  }
  Vec22.tan = tan;
  function atan(v) {
    return {
      x: Math.atan(v.x),
      y: Math.atan(v.y)
    };
  }
  Vec22.atan = atan;
  function tanh(v) {
    return {
      x: Math.tanh(v.x),
      y: Math.tanh(v.y)
    };
  }
  Vec22.tanh = tanh;
  function atanh(v) {
    return {
      x: Math.atanh(v.x),
      y: Math.atanh(v.y)
    };
  }
  Vec22.atanh = atanh;
  function dot(u, v) {
    return u.x * v.x + u.y * v.y;
  }
  Vec22.dot = dot;
  function wedge(u, v) {
    return u.x * v.y - u.y * v.x;
  }
  Vec22.wedge = wedge;
  function length(v) {
    return Math.hypot(v.x, v.y);
  }
  Vec22.length = length;
  function normalize(v) {
    return div(v, length(v));
  }
  Vec22.normalize = normalize;
  function distance(u, v) {
    return length(sub(u, v));
  }
  Vec22.distance = distance;
  function project(u, v) {
    return mul(v, dot(u, v) / dot(v, v));
  }
  Vec22.project = project;
  function reject(u, v) {
    return sub(u, project(u, v));
  }
  Vec22.reject = reject;
  function reflect(i, n) {
    return sub(i, mul(n, 2 * dot(n, i)));
  }
  Vec22.reflect = reflect;
  function refract(i, n, e) {
    const cosi = -dot(i, n);
    const sin2t = e * e * (1 - cosi * cosi);
    const cost = Math.sqrt(1 - sin2t);
    return add(mul(i, e), mul(n, e * cosi - cost));
  }
  Vec22.refract = refract;
  function lerp2(u, v, t) {
    if (t === 0) return u;
    if (t === 1) return v;
    return {
      x: u.x + t * (v.x - u.x),
      y: u.y + t * (v.y - u.y)
    };
  }
  Vec22.lerp = lerp2;
  function slerp(u, v, t) {
    if (t === 0) return u;
    if (t === 1) return v;
    const cost = dot(u, v);
    const theta = Math.acos(cost);
    const sint = Math.sqrt(1 - cost * cost);
    const tu = Math.sin((1 - t) * theta) / sint;
    const tv = Math.sin(t * theta) / sint;
    return add(mul(u, tu), mul(v, tv));
  }
  Vec22.slerp = slerp;
  function rotate(v, t) {
    const cost = Math.cos(t), sint = Math.sin(t);
    const rot = Mat2.from([
      cost,
      -sint,
      sint,
      cost
    ]);
    return Mat2.mul(rot, v);
  }
  Vec22.rotate = rotate;
})(Vec2 || (Vec2 = {}));
var RandVec;
((RandVec2) => {
  function random2() {
    return {
      x: Math.random(),
      y: Math.random()
    };
  }
  RandVec2.random2 = random2;
  function random3() {
    return {
      x: Math.random(),
      y: Math.random(),
      z: Math.random()
    };
  }
  RandVec2.random3 = random3;
  function circle() {
    const phi = Math.random() * Math.PI * 2;
    return {
      x: Math.cos(phi),
      y: Math.sin(phi)
    };
  }
  RandVec2.circle = circle;
  function disk() {
    const rand = random2();
    const phi = rand.x * Math.PI * 2;
    const radius = Math.sqrt(rand.y);
    return {
      x: radius * Math.cos(phi),
      y: radius * Math.sin(phi)
    };
  }
  RandVec2.disk = disk;
  function sphere() {
    const rand = random2();
    const phi = rand.x * Math.PI * 2;
    const sint = 2 * Math.sqrt(rand.y * (1 - rand.y));
    return {
      x: Math.cos(phi) * sint,
      y: 1 - 2 * rand.y,
      z: Math.sin(phi) * sint
    };
  }
  RandVec2.sphere = sphere;
  function hemisphere() {
    const rand = random2();
    const phi = rand.x * Math.PI * 2;
    const sint = Math.sqrt(rand.y * (2 - rand.y));
    return {
      x: Math.cos(phi) * sint,
      y: 1 - rand.y,
      z: Math.sin(phi) * sint
    };
  }
  RandVec2.hemisphere = hemisphere;
  function cosHemisphere() {
    const rand = random2();
    const phi = rand.x * Math.PI * 2;
    const sint = Math.sqrt(rand.y);
    return {
      x: Math.cos(phi) * sint,
      y: Math.sqrt(1 - rand.y),
      z: Math.sin(phi) * sint
    };
  }
  RandVec2.cosHemisphere = cosHemisphere;
  function cap(t) {
    const rand = random2();
    const phi = rand.x * Math.PI * 2;
    const u = rand.y * (1 - Math.cos(t));
    const sint = Math.sqrt(u * (2 - u));
    return {
      x: Math.cos(phi) * sint,
      y: 1 - u,
      z: Math.sin(phi) * sint
    };
  }
  RandVec2.cap = cap;
})(RandVec || (RandVec = {}));

// scripts/systems/dynamic_property_database.ts
var DynamicPropertyDatabase = class {
  /**
   * Constructs a dynamic property database with an arbitrary list of index keys.
   * @param medium The storage medium used to store dynamic properties.
   * @param id The identifier of this database.
   * @param dataFields A list of string fields the database will use to index values.
   */
  constructor(medium, id, ...dataFields) {
    this.medium = medium;
    this.id = id;
    this.dataFields = dataFields;
  }
  medium;
  id;
  dataFields;
  /**
   * Writes a dynamic property value to a database field.
   * Optionally intakes just a field parameter to write undefined to the field.
   * @param field The full data field to write a value to.
   * @param value The dynamic property value to write.
   */
  write(field, value) {
    const values = this.dataFields.map((key) => field[key]);
    const identifier = [this.id, ...values].join("/");
    return this.medium.setDynamicProperty(identifier, value);
  }
  /**
   * Reads a dynamic property value from a database field.
   * @param field The full data field to read a value from.
   * @returns The dynamic property stored in this field.
   * Returns undefined if there is no property stored.
   */
  read(field) {
    const values = this.dataFields.map((key) => field[key]);
    const identifier = [this.id, ...values].join("/");
    return this.medium.getDynamicProperty(identifier);
  }
  /**
   * Finds and returns all data fields and their corresonding values that cause 
   * the predicate function to return true.
   * @param predicate A predicate used to evaluate every database field and determine
   * if it should be included in the resulting array or not.
   * @returns An array of objects containing each field and its corresponding value
   * that passed the predicate test.
   */
  findAll(predicate) {
    const matches = [];
    for (const identifier of this.medium.getDynamicPropertyIds()) {
      const values = identifier.split("/");
      if (values[0] != this.id) continue;
      const field = this.dataFields.reduce((object, key, index) => {
        object[key] = values[index + 1];
        return object;
      }, {});
      if (!predicate || predicate(field))
        matches.push({ field, value: this.medium.getDynamicProperty(identifier) });
    }
    return matches;
  }
};

// scripts/systems/waystones.ts
import { world as world3 } from "@minecraft/server";

// scripts/systems/factions.ts
import { Player as Player2, world as world2 } from "@minecraft/server";

// scripts/systems/waypoints.ts
import { PlayerWaypoint, WaypointTexture, world } from "@minecraft/server";
var FactionWaypoint = class extends PlayerWaypoint {
  constructor(player) {
    super(player, {
      textureBoundsList: [
        {
          texture: WaypointTexture.Square,
          lowerBound: 0,
          upperBound: 179
        },
        {
          texture: WaypointTexture.Circle,
          lowerBound: 179,
          upperBound: 230
        },
        {
          texture: WaypointTexture.SmallSquare,
          lowerBound: 230,
          upperBound: 281
        },
        {
          texture: WaypointTexture.SmallStar,
          lowerBound: 281
        }
      ]
    }, {
      showSpectator: false,
      showHidden: false,
      showSpectatorToSpectator: true,
      showDead: false,
      showInvisible: false,
      showSneaking: true
    }, FactionColourMap[FactionRegistry.getFaction(player).colour]);
  }
};
var FactionColourMap = {
  ["u" /* amethyst */]: { red: 0.59, green: 0.37, blue: 0.76 },
  ["n" /* copper */]: { red: 0.67, green: 0.43, blue: 0.32 },
  ["s" /* diamond */]: { red: 0.33, green: 0.71, blue: 0.66 },
  ["q" /* emerald */]: { red: 0.24, green: 0.61, blue: 0.25 },
  ["p" /* gold */]: { red: 0.84, green: 0.71, blue: 0.25 },
  ["i" /* iron */]: { red: 0.8, green: 0.79, blue: 0.79 },
  ["t" /* lapis */]: { red: 0.18, green: 0.28, blue: 0.47 },
  ["j" /* netherite */]: { red: 0.26, green: 0.23, blue: 0.23 },
  ["h" /* quartz */]: { red: 0.88, green: 0.84, blue: 0.82 },
  ["m" /* redstone */]: { red: 0.55, green: 0.17, blue: 0.07 },
  ["v" /* resin */]: { red: 0.87, green: 0.49, blue: 0.16 }
};
var WaypointManager;
((WaypointManager2) => {
  function refreshFactionWaypoints() {
    const players = world.getAllPlayers();
    for (const player of players)
      player.locatorBar.removeAllWaypoints();
    for (const player of players) {
      const faction = FactionRegistry.getFaction(player);
      if (!faction) continue;
      const waypoint = new FactionWaypoint(player);
      for (const memberId of [faction.owner, ...faction.players]) {
        if (memberId === player.id) continue;
        const member = world.getEntity(memberId);
        if (!(member == null ? void 0 : member.locatorBar.hasWaypoint(waypoint)))
          member == null ? void 0 : member.locatorBar.addWaypoint(waypoint);
      }
    }
  }
  WaypointManager2.refreshFactionWaypoints = refreshFactionWaypoints;
})(WaypointManager || (WaypointManager = {}));

// scripts/systems/factions.ts
var FactionDatabase = new DynamicPropertyDatabase(world2, "faction", "owner", "name", "colour");
var FactionColour = /* @__PURE__ */ ((FactionColour2) => {
  FactionColour2["quartz"] = "h";
  FactionColour2["iron"] = "i";
  FactionColour2["netherite"] = "j";
  FactionColour2["redstone"] = "m";
  FactionColour2["copper"] = "n";
  FactionColour2["gold"] = "p";
  FactionColour2["emerald"] = "q";
  FactionColour2["diamond"] = "s";
  FactionColour2["lapis"] = "t";
  FactionColour2["amethyst"] = "u";
  FactionColour2["resin"] = "v";
  return FactionColour2;
})(FactionColour || {});
var FactionRegistry;
((FactionRegistry2) => {
  function getAllFactions() {
    return FactionDatabase.findAll().map((match) => {
      return {
        name: match.field.name,
        colour: match.field.colour,
        owner: match.field.owner,
        players: match.value.split("/")
      };
    });
  }
  FactionRegistry2.getAllFactions = getAllFactions;
  function getFaction(arg) {
    return FactionDatabase.findAll().filter((match) => {
      const players = match.value.split("/");
      if (arg instanceof Player2)
        return players.includes(arg.id);
      else return match.field.name === arg;
    }).map((match) => {
      return {
        name: match.field.name,
        colour: match.field.colour,
        owner: match.field.owner,
        players: match.value.split("/")
      };
    })[0];
  }
  FactionRegistry2.getFaction = getFaction;
  function nameIsValid(name) {
    if (name.length > 24 || name.length == 0) return false;
    if (name.includes("/") || name.includes("\xA7")) return false;
    for (const faction of getAllFactions())
      if (faction.name == name) return false;
    return true;
  }
  FactionRegistry2.nameIsValid = nameIsValid;
  function addFaction(faction) {
    if (!nameIsValid(faction.name)) return false;
    FactionDatabase.write(faction, faction.players.join("/"));
    for (const id of faction.players) {
      const player = world2.getEntity(id);
      if (player) player.nameTag = player.name + `
\xA7${faction.colour}${faction.name}\xA7r`;
    }
    WaypointManager.refreshFactionWaypoints();
    return true;
  }
  FactionRegistry2.addFaction = addFaction;
  function removeFaction(faction) {
    FactionDatabase.write(faction);
    for (const id of faction.players) {
      const player = world2.getEntity(id);
      if (player) player.nameTag = player.name;
    }
    WaypointManager.refreshFactionWaypoints();
  }
  FactionRegistry2.removeFaction = removeFaction;
  function addPlayer(faction, playerId) {
    faction.players.push(playerId);
    FactionDatabase.write(faction, faction.players.join("/"));
    const player = world2.getEntity(playerId);
    if (player) player.nameTag = player.name + `
\xA7${faction.colour}${faction.name}\xA7r`;
    WaypointManager.refreshFactionWaypoints();
  }
  FactionRegistry2.addPlayer = addPlayer;
  function removePlayer(faction, playerId) {
    faction.players = faction.players.filter((id) => {
      return id != playerId;
    });
    FactionDatabase.write(faction, faction.players.join("/"));
    const player = world2.getEntity(playerId);
    if (player) player.nameTag = player.name;
    WaypointManager.refreshFactionWaypoints();
  }
  FactionRegistry2.removePlayer = removePlayer;
  function sendMessage(faction, message) {
    if (message.length) for (const id of faction.players) {
      const player = world2.getEntity(id);
      player == null ? void 0 : player.sendMessage(`\xA7${faction.colour}[${faction.name}]\xA7r ${message}`);
    }
  }
  FactionRegistry2.sendMessage = sendMessage;
  function invitePlayer(faction, player) {
    player.setDynamicProperty("tcsmp:faction_invite", faction.name);
  }
  FactionRegistry2.invitePlayer = invitePlayer;
})(FactionRegistry || (FactionRegistry = {}));

// scripts/util.ts
var MissingComponentError = class extends Error {
  constructor(component) {
    super(`Object is missing component "${component}".`);
    this.name = "MissingComponentError";
  }
};
function within(value, range) {
  return range.min <= value && value <= range.max;
}
function lerp(t, a, b) {
  return a + t * (b - a);
}
function randomElement(array) {
  return array[Math.floor(Math.random() * array.length)];
}
function randBoundedDisk(min, max) {
  const theta = 2 * Math.PI * Math.random();
  const min2 = min * min, max2 = max * max;
  const radius = Math.sqrt(lerp(Math.random(), min2, max2));
  return {
    x: radius * Math.cos(theta),
    y: radius * Math.sin(theta)
  };
}
function ellipsoidValue(range, position) {
  const pos2 = Vec3.mul(position, position);
  const ran2 = Vec3.mul(range, range);
  const quo = Vec3.div(pos2, ran2);
  return quo.x + quo.y + quo.z;
}
function getRectPrism(range) {
  const span = Vec3.add(Vec3.mul(range, 2), Vec3.from(1));
  const locations = new Array(span.x * span.y * span.z);
  let i = 0;
  for (let x = 0; x <= 2 * range.x; ++x)
    for (let y = 0; y <= 2 * range.y; ++y)
      for (let z = 0; z <= 2 * range.z; ++z, ++i)
        locations[i] = Vec3.sub(Vec3.from(x, y, z), range);
  return locations;
}
function randomExp(mean) {
  return -mean * Math.log(1 - Math.random());
}
function roundTo(x, digits) {
  const factor = 10 ** digits;
  return Math.round(x * factor) / factor;
}
function randomRange(min, max) {
  return min + Math.random() * (max - min);
}
function clamp(x, min, max) {
  return Math.max(Math.min(x, max), min);
}

// scripts/systems/waystones.ts
var WaystoneDatabase = new DynamicPropertyDatabase(world3, "waystone", "owner", "placer", "dimension", "name");
var WaystoneRegistry;
((WaystoneRegistry2) => {
  function get(context) {
    const faction = FactionRegistry.getFaction(context);
    return WaystoneDatabase.findAll((field) => {
      return field.dimension == context.dimension.id && (field.owner == "" || field.owner == context.id || !!(faction == null ? void 0 : faction.players.includes(field.owner)));
    }).map((match) => {
      return {
        name: match.field.name,
        owner: match.field.owner,
        placer: match.field.placer,
        dimension: match.field.dimension,
        location: match.value
      };
    });
  }
  WaystoneRegistry2.get = get;
  function find(base) {
    return WaystoneDatabase.findAll((field) => {
      return field.dimension == base.dimension.id;
    }).filter((match) => {
      return Vec3.equal(base.location, match.value);
    }).map((match) => {
      return {
        name: match.field.name,
        owner: match.field.owner,
        placer: match.field.placer,
        dimension: match.field.dimension,
        location: match.value
      };
    })[0];
  }
  WaystoneRegistry2.find = find;
  function has(context, waystone) {
    const faction = FactionRegistry.getFaction(context);
    return WaystoneDatabase.findAll((field) => {
      return field.dimension == context.dimension.id && (field.owner == "" || field.owner == context.id && !!(faction == null ? void 0 : faction.players.includes(field.owner)));
    }).filter((match) => {
      return waystone.owner == match.field.owner && waystone.name == match.field.name && Vec3.equal(waystone.location, match.value);
    }).length > 0;
  }
  WaystoneRegistry2.has = has;
  function add(waystone) {
    return WaystoneDatabase.write(waystone, waystone.location);
  }
  WaystoneRegistry2.add = add;
  function remove(waystone) {
    return WaystoneDatabase.write(waystone);
  }
  WaystoneRegistry2.remove = remove;
  function valid(waystone) {
    const heightRange = world3.getDimension(waystone.dimension).heightRange;
    const validName = waystone.name.length > 0 && !waystone.name.includes("/");
    const validPosition = within(waystone.location.y, heightRange);
    return validName && validPosition;
  }
  WaystoneRegistry2.valid = valid;
})(WaystoneRegistry || (WaystoneRegistry = {}));

// scripts/systems/block_entities.ts
import { world as world4 } from "@minecraft/server";
var BlockEntityDatabase = new DynamicPropertyDatabase(world4, "blockentity", "dimension", "entityId");
var BlockEntityRegistry;
((BlockEntityRegistry2) => {
  function get(block) {
    var _a;
    const entityId = (_a = BlockEntityDatabase.findAll((field) => {
      return field.dimension == block.dimension.id;
    }).find((match) => {
      return Vec3.equal(block.location, match.value);
    })) == null ? void 0 : _a.field.entityId;
    return entityId ? world4.getEntity(entityId) : void 0;
  }
  BlockEntityRegistry2.get = get;
  function spawn(block, typeId) {
    const { dimension, location } = block;
    const entity = dimension.spawnEntity(typeId, block.bottomCenter());
    BlockEntityDatabase.write({ dimension: dimension.id, entityId: entity.id }, location);
  }
  BlockEntityRegistry2.spawn = spawn;
  function remove(block) {
    var _a;
    const match = BlockEntityDatabase.findAll((field) => {
      return field.dimension == block.dimension.id;
    }).find((match2) => {
      return Vec3.equal(block.location, match2.value);
    });
    if (match == null ? void 0 : match.field.entityId) {
      (_a = world4.getEntity(match.field.entityId)) == null ? void 0 : _a.remove();
      BlockEntityDatabase.write(match.field);
    }
  }
  BlockEntityRegistry2.remove = remove;
})(BlockEntityRegistry || (BlockEntityRegistry = {}));

// scripts/systems/names.ts
import { world as world5 } from "@minecraft/server";
var NameDatabase = new DynamicPropertyDatabase(world5, "lastknownname", "id");
var NameRegistry;
((NameRegistry2) => {
  function getName(id) {
    return NameDatabase.read({ id });
  }
  NameRegistry2.getName = getName;
  function setName(id, name) {
    return NameDatabase.write({ id }, name);
  }
  NameRegistry2.setName = setName;
})(NameRegistry || (NameRegistry = {}));

// scripts/block_components/waystone.ts
var waystoneComponent = {
  // Place is triggered for all multi-block parts
  onPlace({ block }) {
    if (block.permutation.getState("minecraft:multi_block_part") == 1)
      BlockEntityRegistry.spawn(block, "tcsmp:warp_crystal");
  },
  onPlayerInteract({ block, player, dimension }, parameters) {
    const { params } = parameters;
    if (dimension.id != params.dimension) return;
    const { permutation } = block;
    dimension.playSound("use.waystone", block.center());
    const states = permutation.getAllStates();
    const base = states["minecraft:multi_block_part"] === 0 ? block : block.below();
    const top = states["minecraft:multi_block_part"] === 0 ? block.above() : block;
    if (!states["tcsmp:active"])
      return setupWaystone(base, top, player);
    const waystone = WaystoneRegistry.find(base);
    if ((player == null ? void 0 : player.isSneaking) && (waystone == null ? void 0 : waystone.placer) == player.id)
      return editWaystone(waystone, player);
    return useWaystone(base, player);
  },
  // Break is just triggered once for the multi-block part the player broke
  onBreak({ block, brokenBlockPermutation }) {
    const states = brokenBlockPermutation.getAllStates();
    BlockEntityRegistry.remove(
      states["minecraft:multi_block_part"] == 0 ? block.above() : block
    );
    if (!states["tcsmp:active"]) return;
    const base = states["minecraft:multi_block_part"] == 0 ? block : block.below();
    WaystoneRegistry.remove(WaystoneRegistry.find(base));
  }
};
var waystone_default = waystoneComponent;
function setupWaystone(base, top, player) {
  const name_input = new ObservableString("", { clientWritable: true });
  const is_private = new ObservableBoolean(false, { clientWritable: true });
  const form = new CustomForm(player, { translate: "form.setup.waystone.title" }).textField({ translate: "form.setup.waystone.name" }, name_input).toggle({ translate: "form.setup.waystone.private" }, is_private).divider().button({ translate: "form.setup.waystone.submit" }, () => {
    form.close();
    const name = name_input.getData();
    const owner = is_private.getData() ? player.id : "";
    const waystone = {
      name,
      owner,
      placer: player.id,
      dimension: player.dimension.id,
      location: base.location
    };
    if (!WaystoneRegistry.valid(waystone))
      return player.onScreenDisplay.setActionBar({ translate: "info.waystone.invalid", with: [waystone.name] });
    if (WaystoneRegistry.has(player, waystone))
      return player.onScreenDisplay.setActionBar({
        translate: waystone.owner ? "info.waystone.preexists.private" : "info.waystone.preexists.global",
        with: [waystone.name]
      });
    player.dimension.playSound("use.waystone", base.center());
    WaystoneRegistry.add(waystone);
    base.setPermutation(base.permutation.withState("tcsmp:active", true));
    top.setPermutation(top.permutation.withState("tcsmp:active", true));
  });
  form.show();
}
function useWaystone(base, player) {
  const form = new CustomForm(player, { translate: "form.interact.waystone.title" });
  const registry = WaystoneRegistry.get(player);
  for (const waystone of registry) {
    if (Vec3.equal(waystone.location, base.location)) continue;
    form.button(waystone.name, () => {
      form.close();
      teleportToWaystone(player, waystone);
    }, { tooltip: {
      translate: waystone.owner ? "form.interact.waystone.private" : "form.interact.waystone.global",
      with: [NameRegistry.getName(waystone.owner) ?? ""]
    } });
  }
  form.show();
}
function editWaystone(waystone, player) {
  const name_input = new ObservableString(waystone.name, { clientWritable: true });
  const is_private = new ObservableBoolean(!!waystone.owner, { clientWritable: true });
  const form = new CustomForm(player, { translate: "form.edit.waystone.title" }).textField({ translate: "form.setup.waystone.name" }, name_input).toggle({ translate: "form.setup.waystone.private" }, is_private).divider().button({ translate: "form.setup.waystone.submit" }, () => {
    form.close();
    const name = name_input.getData();
    const owner = is_private.getData() ? player.id : "";
    const new_waystone = {
      name,
      owner,
      placer: player.id,
      dimension: player.dimension.id,
      location: waystone.location
    };
    if (!WaystoneRegistry.valid(new_waystone))
      return player.onScreenDisplay.setActionBar({ translate: "info.waystone.invalid", with: [waystone.name] });
    if (WaystoneRegistry.has(player, new_waystone))
      return player.onScreenDisplay.setActionBar({
        translate: waystone.owner ? "info.waystone.preexists.private" : "info.waystone.preexists.global",
        with: [waystone.name]
      });
    player.dimension.playSound("use.waystone", Vec3.add(waystone.location, Vec3.from(0.5)));
    WaystoneRegistry.remove(waystone);
    WaystoneRegistry.add(new_waystone);
  });
  form.show();
}
function teleportToWaystone(player, waystone) {
  player.playSound("waystone.teleport");
  player.camera.fade({
    fadeColor: { red: 0.914, green: 0.882, blue: 0.851 },
    fadeTime: {
      fadeInTime: 0,
      holdTime: 1,
      fadeOutTime: 0.8
    }
  });
  player.teleport(waystone.location);
}

// scripts/block_components/tick_particle.ts
var tickParticleComponent = {
  onPlace({ dimension, block }, parameters) {
    const { params } = parameters;
    dimension.spawnParticle(params.particle, block.bottomCenter());
  },
  onTick({ dimension, block }, parameters) {
    const { params } = parameters;
    dimension.spawnParticle(params.particle, block.bottomCenter());
  }
};
var tick_particle_default = tickParticleComponent;

// scripts/block_components/crop.ts
import { EquipmentSlot, GameMode } from "@minecraft/server";

// node_modules/@minecraft/vanilla-data/lib/index.js
var MinecraftBiomeTypes = ((MinecraftBiomeTypes2) => {
  MinecraftBiomeTypes2["BambooJungle"] = "minecraft:bamboo_jungle";
  MinecraftBiomeTypes2["BambooJungleHills"] = "minecraft:bamboo_jungle_hills";
  MinecraftBiomeTypes2["BasaltDeltas"] = "minecraft:basalt_deltas";
  MinecraftBiomeTypes2["Beach"] = "minecraft:beach";
  MinecraftBiomeTypes2["BirchForest"] = "minecraft:birch_forest";
  MinecraftBiomeTypes2["BirchForestHills"] = "minecraft:birch_forest_hills";
  MinecraftBiomeTypes2["BirchForestHillsMutated"] = "minecraft:birch_forest_hills_mutated";
  MinecraftBiomeTypes2["BirchForestMutated"] = "minecraft:birch_forest_mutated";
  MinecraftBiomeTypes2["CherryGrove"] = "minecraft:cherry_grove";
  MinecraftBiomeTypes2["ColdBeach"] = "minecraft:cold_beach";
  MinecraftBiomeTypes2["ColdOcean"] = "minecraft:cold_ocean";
  MinecraftBiomeTypes2["ColdTaiga"] = "minecraft:cold_taiga";
  MinecraftBiomeTypes2["ColdTaigaHills"] = "minecraft:cold_taiga_hills";
  MinecraftBiomeTypes2["ColdTaigaMutated"] = "minecraft:cold_taiga_mutated";
  MinecraftBiomeTypes2["CrimsonForest"] = "minecraft:crimson_forest";
  MinecraftBiomeTypes2["DeepColdOcean"] = "minecraft:deep_cold_ocean";
  MinecraftBiomeTypes2["DeepDark"] = "minecraft:deep_dark";
  MinecraftBiomeTypes2["DeepFrozenOcean"] = "minecraft:deep_frozen_ocean";
  MinecraftBiomeTypes2["DeepLukewarmOcean"] = "minecraft:deep_lukewarm_ocean";
  MinecraftBiomeTypes2["DeepOcean"] = "minecraft:deep_ocean";
  MinecraftBiomeTypes2["DeepWarmOcean"] = "minecraft:deep_warm_ocean";
  MinecraftBiomeTypes2["Desert"] = "minecraft:desert";
  MinecraftBiomeTypes2["DesertHills"] = "minecraft:desert_hills";
  MinecraftBiomeTypes2["DesertMutated"] = "minecraft:desert_mutated";
  MinecraftBiomeTypes2["DripstoneCaves"] = "minecraft:dripstone_caves";
  MinecraftBiomeTypes2["ExtremeHills"] = "minecraft:extreme_hills";
  MinecraftBiomeTypes2["ExtremeHillsEdge"] = "minecraft:extreme_hills_edge";
  MinecraftBiomeTypes2["ExtremeHillsMutated"] = "minecraft:extreme_hills_mutated";
  MinecraftBiomeTypes2["ExtremeHillsPlusTrees"] = "minecraft:extreme_hills_plus_trees";
  MinecraftBiomeTypes2["ExtremeHillsPlusTreesMutated"] = "minecraft:extreme_hills_plus_trees_mutated";
  MinecraftBiomeTypes2["FlowerForest"] = "minecraft:flower_forest";
  MinecraftBiomeTypes2["Forest"] = "minecraft:forest";
  MinecraftBiomeTypes2["ForestHills"] = "minecraft:forest_hills";
  MinecraftBiomeTypes2["FrozenOcean"] = "minecraft:frozen_ocean";
  MinecraftBiomeTypes2["FrozenPeaks"] = "minecraft:frozen_peaks";
  MinecraftBiomeTypes2["FrozenRiver"] = "minecraft:frozen_river";
  MinecraftBiomeTypes2["Grove"] = "minecraft:grove";
  MinecraftBiomeTypes2["Hell"] = "minecraft:hell";
  MinecraftBiomeTypes2["IceMountains"] = "minecraft:ice_mountains";
  MinecraftBiomeTypes2["IcePlains"] = "minecraft:ice_plains";
  MinecraftBiomeTypes2["IcePlainsSpikes"] = "minecraft:ice_plains_spikes";
  MinecraftBiomeTypes2["JaggedPeaks"] = "minecraft:jagged_peaks";
  MinecraftBiomeTypes2["Jungle"] = "minecraft:jungle";
  MinecraftBiomeTypes2["JungleEdge"] = "minecraft:jungle_edge";
  MinecraftBiomeTypes2["JungleEdgeMutated"] = "minecraft:jungle_edge_mutated";
  MinecraftBiomeTypes2["JungleHills"] = "minecraft:jungle_hills";
  MinecraftBiomeTypes2["JungleMutated"] = "minecraft:jungle_mutated";
  MinecraftBiomeTypes2["LegacyFrozenOcean"] = "minecraft:legacy_frozen_ocean";
  MinecraftBiomeTypes2["LukewarmOcean"] = "minecraft:lukewarm_ocean";
  MinecraftBiomeTypes2["LushCaves"] = "minecraft:lush_caves";
  MinecraftBiomeTypes2["MangroveSwamp"] = "minecraft:mangrove_swamp";
  MinecraftBiomeTypes2["Meadow"] = "minecraft:meadow";
  MinecraftBiomeTypes2["MegaTaiga"] = "minecraft:mega_taiga";
  MinecraftBiomeTypes2["MegaTaigaHills"] = "minecraft:mega_taiga_hills";
  MinecraftBiomeTypes2["Mesa"] = "minecraft:mesa";
  MinecraftBiomeTypes2["MesaBryce"] = "minecraft:mesa_bryce";
  MinecraftBiomeTypes2["MesaPlateau"] = "minecraft:mesa_plateau";
  MinecraftBiomeTypes2["MesaPlateauMutated"] = "minecraft:mesa_plateau_mutated";
  MinecraftBiomeTypes2["MesaPlateauStone"] = "minecraft:mesa_plateau_stone";
  MinecraftBiomeTypes2["MesaPlateauStoneMutated"] = "minecraft:mesa_plateau_stone_mutated";
  MinecraftBiomeTypes2["MushroomIsland"] = "minecraft:mushroom_island";
  MinecraftBiomeTypes2["MushroomIslandShore"] = "minecraft:mushroom_island_shore";
  MinecraftBiomeTypes2["Ocean"] = "minecraft:ocean";
  MinecraftBiomeTypes2["PaleGarden"] = "minecraft:pale_garden";
  MinecraftBiomeTypes2["Plains"] = "minecraft:plains";
  MinecraftBiomeTypes2["RedwoodTaigaHillsMutated"] = "minecraft:redwood_taiga_hills_mutated";
  MinecraftBiomeTypes2["RedwoodTaigaMutated"] = "minecraft:redwood_taiga_mutated";
  MinecraftBiomeTypes2["River"] = "minecraft:river";
  MinecraftBiomeTypes2["RoofedForest"] = "minecraft:roofed_forest";
  MinecraftBiomeTypes2["RoofedForestMutated"] = "minecraft:roofed_forest_mutated";
  MinecraftBiomeTypes2["Savanna"] = "minecraft:savanna";
  MinecraftBiomeTypes2["SavannaMutated"] = "minecraft:savanna_mutated";
  MinecraftBiomeTypes2["SavannaPlateau"] = "minecraft:savanna_plateau";
  MinecraftBiomeTypes2["SavannaPlateauMutated"] = "minecraft:savanna_plateau_mutated";
  MinecraftBiomeTypes2["SnowySlopes"] = "minecraft:snowy_slopes";
  MinecraftBiomeTypes2["SoulsandValley"] = "minecraft:soulsand_valley";
  MinecraftBiomeTypes2["StoneBeach"] = "minecraft:stone_beach";
  MinecraftBiomeTypes2["StonyPeaks"] = "minecraft:stony_peaks";
  MinecraftBiomeTypes2["SulfurCaves"] = "minecraft:sulfur_caves";
  MinecraftBiomeTypes2["SunflowerPlains"] = "minecraft:sunflower_plains";
  MinecraftBiomeTypes2["Swampland"] = "minecraft:swampland";
  MinecraftBiomeTypes2["SwamplandMutated"] = "minecraft:swampland_mutated";
  MinecraftBiomeTypes2["Taiga"] = "minecraft:taiga";
  MinecraftBiomeTypes2["TaigaHills"] = "minecraft:taiga_hills";
  MinecraftBiomeTypes2["TaigaMutated"] = "minecraft:taiga_mutated";
  MinecraftBiomeTypes2["TheEnd"] = "minecraft:the_end";
  MinecraftBiomeTypes2["WarmOcean"] = "minecraft:warm_ocean";
  MinecraftBiomeTypes2["WarpedForest"] = "minecraft:warped_forest";
  return MinecraftBiomeTypes2;
})(MinecraftBiomeTypes || {});
var MinecraftBlockTypes = ((MinecraftBlockTypes2) => {
  MinecraftBlockTypes2["AcaciaButton"] = "minecraft:acacia_button";
  MinecraftBlockTypes2["AcaciaDoor"] = "minecraft:acacia_door";
  MinecraftBlockTypes2["AcaciaDoubleSlab"] = "minecraft:acacia_double_slab";
  MinecraftBlockTypes2["AcaciaFence"] = "minecraft:acacia_fence";
  MinecraftBlockTypes2["AcaciaFenceGate"] = "minecraft:acacia_fence_gate";
  MinecraftBlockTypes2["AcaciaHangingSign"] = "minecraft:acacia_hanging_sign";
  MinecraftBlockTypes2["AcaciaLeaves"] = "minecraft:acacia_leaves";
  MinecraftBlockTypes2["AcaciaLog"] = "minecraft:acacia_log";
  MinecraftBlockTypes2["AcaciaPlanks"] = "minecraft:acacia_planks";
  MinecraftBlockTypes2["AcaciaPressurePlate"] = "minecraft:acacia_pressure_plate";
  MinecraftBlockTypes2["AcaciaSapling"] = "minecraft:acacia_sapling";
  MinecraftBlockTypes2["AcaciaShelf"] = "minecraft:acacia_shelf";
  MinecraftBlockTypes2["AcaciaSlab"] = "minecraft:acacia_slab";
  MinecraftBlockTypes2["AcaciaStairs"] = "minecraft:acacia_stairs";
  MinecraftBlockTypes2["AcaciaStandingSign"] = "minecraft:acacia_standing_sign";
  MinecraftBlockTypes2["AcaciaTrapdoor"] = "minecraft:acacia_trapdoor";
  MinecraftBlockTypes2["AcaciaWallSign"] = "minecraft:acacia_wall_sign";
  MinecraftBlockTypes2["AcaciaWood"] = "minecraft:acacia_wood";
  MinecraftBlockTypes2["ActivatorRail"] = "minecraft:activator_rail";
  MinecraftBlockTypes2["Air"] = "minecraft:air";
  MinecraftBlockTypes2["Allium"] = "minecraft:allium";
  MinecraftBlockTypes2["Allow"] = "minecraft:allow";
  MinecraftBlockTypes2["AmethystBlock"] = "minecraft:amethyst_block";
  MinecraftBlockTypes2["AmethystCluster"] = "minecraft:amethyst_cluster";
  MinecraftBlockTypes2["AncientDebris"] = "minecraft:ancient_debris";
  MinecraftBlockTypes2["Andesite"] = "minecraft:andesite";
  MinecraftBlockTypes2["AndesiteDoubleSlab"] = "minecraft:andesite_double_slab";
  MinecraftBlockTypes2["AndesiteSlab"] = "minecraft:andesite_slab";
  MinecraftBlockTypes2["AndesiteStairs"] = "minecraft:andesite_stairs";
  MinecraftBlockTypes2["AndesiteWall"] = "minecraft:andesite_wall";
  MinecraftBlockTypes2["Anvil"] = "minecraft:anvil";
  MinecraftBlockTypes2["Azalea"] = "minecraft:azalea";
  MinecraftBlockTypes2["AzaleaLeaves"] = "minecraft:azalea_leaves";
  MinecraftBlockTypes2["AzaleaLeavesFlowered"] = "minecraft:azalea_leaves_flowered";
  MinecraftBlockTypes2["AzureBluet"] = "minecraft:azure_bluet";
  MinecraftBlockTypes2["Bamboo"] = "minecraft:bamboo";
  MinecraftBlockTypes2["BambooBlock"] = "minecraft:bamboo_block";
  MinecraftBlockTypes2["BambooButton"] = "minecraft:bamboo_button";
  MinecraftBlockTypes2["BambooDoor"] = "minecraft:bamboo_door";
  MinecraftBlockTypes2["BambooDoubleSlab"] = "minecraft:bamboo_double_slab";
  MinecraftBlockTypes2["BambooFence"] = "minecraft:bamboo_fence";
  MinecraftBlockTypes2["BambooFenceGate"] = "minecraft:bamboo_fence_gate";
  MinecraftBlockTypes2["BambooHangingSign"] = "minecraft:bamboo_hanging_sign";
  MinecraftBlockTypes2["BambooMosaic"] = "minecraft:bamboo_mosaic";
  MinecraftBlockTypes2["BambooMosaicDoubleSlab"] = "minecraft:bamboo_mosaic_double_slab";
  MinecraftBlockTypes2["BambooMosaicSlab"] = "minecraft:bamboo_mosaic_slab";
  MinecraftBlockTypes2["BambooMosaicStairs"] = "minecraft:bamboo_mosaic_stairs";
  MinecraftBlockTypes2["BambooPlanks"] = "minecraft:bamboo_planks";
  MinecraftBlockTypes2["BambooPressurePlate"] = "minecraft:bamboo_pressure_plate";
  MinecraftBlockTypes2["BambooSapling"] = "minecraft:bamboo_sapling";
  MinecraftBlockTypes2["BambooShelf"] = "minecraft:bamboo_shelf";
  MinecraftBlockTypes2["BambooSlab"] = "minecraft:bamboo_slab";
  MinecraftBlockTypes2["BambooStairs"] = "minecraft:bamboo_stairs";
  MinecraftBlockTypes2["BambooStandingSign"] = "minecraft:bamboo_standing_sign";
  MinecraftBlockTypes2["BambooTrapdoor"] = "minecraft:bamboo_trapdoor";
  MinecraftBlockTypes2["BambooWallSign"] = "minecraft:bamboo_wall_sign";
  MinecraftBlockTypes2["Barrel"] = "minecraft:barrel";
  MinecraftBlockTypes2["Barrier"] = "minecraft:barrier";
  MinecraftBlockTypes2["Basalt"] = "minecraft:basalt";
  MinecraftBlockTypes2["Beacon"] = "minecraft:beacon";
  MinecraftBlockTypes2["Bed"] = "minecraft:bed";
  MinecraftBlockTypes2["Bedrock"] = "minecraft:bedrock";
  MinecraftBlockTypes2["BeeNest"] = "minecraft:bee_nest";
  MinecraftBlockTypes2["Beehive"] = "minecraft:beehive";
  MinecraftBlockTypes2["Beetroot"] = "minecraft:beetroot";
  MinecraftBlockTypes2["Bell"] = "minecraft:bell";
  MinecraftBlockTypes2["BigDripleaf"] = "minecraft:big_dripleaf";
  MinecraftBlockTypes2["BirchButton"] = "minecraft:birch_button";
  MinecraftBlockTypes2["BirchDoor"] = "minecraft:birch_door";
  MinecraftBlockTypes2["BirchDoubleSlab"] = "minecraft:birch_double_slab";
  MinecraftBlockTypes2["BirchFence"] = "minecraft:birch_fence";
  MinecraftBlockTypes2["BirchFenceGate"] = "minecraft:birch_fence_gate";
  MinecraftBlockTypes2["BirchHangingSign"] = "minecraft:birch_hanging_sign";
  MinecraftBlockTypes2["BirchLeaves"] = "minecraft:birch_leaves";
  MinecraftBlockTypes2["BirchLog"] = "minecraft:birch_log";
  MinecraftBlockTypes2["BirchPlanks"] = "minecraft:birch_planks";
  MinecraftBlockTypes2["BirchPressurePlate"] = "minecraft:birch_pressure_plate";
  MinecraftBlockTypes2["BirchSapling"] = "minecraft:birch_sapling";
  MinecraftBlockTypes2["BirchShelf"] = "minecraft:birch_shelf";
  MinecraftBlockTypes2["BirchSlab"] = "minecraft:birch_slab";
  MinecraftBlockTypes2["BirchStairs"] = "minecraft:birch_stairs";
  MinecraftBlockTypes2["BirchStandingSign"] = "minecraft:birch_standing_sign";
  MinecraftBlockTypes2["BirchTrapdoor"] = "minecraft:birch_trapdoor";
  MinecraftBlockTypes2["BirchWallSign"] = "minecraft:birch_wall_sign";
  MinecraftBlockTypes2["BirchWood"] = "minecraft:birch_wood";
  MinecraftBlockTypes2["BlackCandle"] = "minecraft:black_candle";
  MinecraftBlockTypes2["BlackCandleCake"] = "minecraft:black_candle_cake";
  MinecraftBlockTypes2["BlackCarpet"] = "minecraft:black_carpet";
  MinecraftBlockTypes2["BlackConcrete"] = "minecraft:black_concrete";
  MinecraftBlockTypes2["BlackConcretePowder"] = "minecraft:black_concrete_powder";
  MinecraftBlockTypes2["BlackGlazedTerracotta"] = "minecraft:black_glazed_terracotta";
  MinecraftBlockTypes2["BlackShulkerBox"] = "minecraft:black_shulker_box";
  MinecraftBlockTypes2["BlackStainedGlass"] = "minecraft:black_stained_glass";
  MinecraftBlockTypes2["BlackStainedGlassPane"] = "minecraft:black_stained_glass_pane";
  MinecraftBlockTypes2["BlackTerracotta"] = "minecraft:black_terracotta";
  MinecraftBlockTypes2["BlackWool"] = "minecraft:black_wool";
  MinecraftBlockTypes2["Blackstone"] = "minecraft:blackstone";
  MinecraftBlockTypes2["BlackstoneDoubleSlab"] = "minecraft:blackstone_double_slab";
  MinecraftBlockTypes2["BlackstoneSlab"] = "minecraft:blackstone_slab";
  MinecraftBlockTypes2["BlackstoneStairs"] = "minecraft:blackstone_stairs";
  MinecraftBlockTypes2["BlackstoneWall"] = "minecraft:blackstone_wall";
  MinecraftBlockTypes2["BlastFurnace"] = "minecraft:blast_furnace";
  MinecraftBlockTypes2["BlueCandle"] = "minecraft:blue_candle";
  MinecraftBlockTypes2["BlueCandleCake"] = "minecraft:blue_candle_cake";
  MinecraftBlockTypes2["BlueCarpet"] = "minecraft:blue_carpet";
  MinecraftBlockTypes2["BlueConcrete"] = "minecraft:blue_concrete";
  MinecraftBlockTypes2["BlueConcretePowder"] = "minecraft:blue_concrete_powder";
  MinecraftBlockTypes2["BlueGlazedTerracotta"] = "minecraft:blue_glazed_terracotta";
  MinecraftBlockTypes2["BlueIce"] = "minecraft:blue_ice";
  MinecraftBlockTypes2["BlueOrchid"] = "minecraft:blue_orchid";
  MinecraftBlockTypes2["BlueShulkerBox"] = "minecraft:blue_shulker_box";
  MinecraftBlockTypes2["BlueStainedGlass"] = "minecraft:blue_stained_glass";
  MinecraftBlockTypes2["BlueStainedGlassPane"] = "minecraft:blue_stained_glass_pane";
  MinecraftBlockTypes2["BlueTerracotta"] = "minecraft:blue_terracotta";
  MinecraftBlockTypes2["BlueWool"] = "minecraft:blue_wool";
  MinecraftBlockTypes2["BoneBlock"] = "minecraft:bone_block";
  MinecraftBlockTypes2["Bookshelf"] = "minecraft:bookshelf";
  MinecraftBlockTypes2["BorderBlock"] = "minecraft:border_block";
  MinecraftBlockTypes2["BrainCoral"] = "minecraft:brain_coral";
  MinecraftBlockTypes2["BrainCoralBlock"] = "minecraft:brain_coral_block";
  MinecraftBlockTypes2["BrainCoralFan"] = "minecraft:brain_coral_fan";
  MinecraftBlockTypes2["BrainCoralWallFan"] = "minecraft:brain_coral_wall_fan";
  MinecraftBlockTypes2["BrewingStand"] = "minecraft:brewing_stand";
  MinecraftBlockTypes2["BrickBlock"] = "minecraft:brick_block";
  MinecraftBlockTypes2["BrickDoubleSlab"] = "minecraft:brick_double_slab";
  MinecraftBlockTypes2["BrickSlab"] = "minecraft:brick_slab";
  MinecraftBlockTypes2["BrickStairs"] = "minecraft:brick_stairs";
  MinecraftBlockTypes2["BrickWall"] = "minecraft:brick_wall";
  MinecraftBlockTypes2["BrownCandle"] = "minecraft:brown_candle";
  MinecraftBlockTypes2["BrownCandleCake"] = "minecraft:brown_candle_cake";
  MinecraftBlockTypes2["BrownCarpet"] = "minecraft:brown_carpet";
  MinecraftBlockTypes2["BrownConcrete"] = "minecraft:brown_concrete";
  MinecraftBlockTypes2["BrownConcretePowder"] = "minecraft:brown_concrete_powder";
  MinecraftBlockTypes2["BrownGlazedTerracotta"] = "minecraft:brown_glazed_terracotta";
  MinecraftBlockTypes2["BrownMushroom"] = "minecraft:brown_mushroom";
  MinecraftBlockTypes2["BrownMushroomBlock"] = "minecraft:brown_mushroom_block";
  MinecraftBlockTypes2["BrownShulkerBox"] = "minecraft:brown_shulker_box";
  MinecraftBlockTypes2["BrownStainedGlass"] = "minecraft:brown_stained_glass";
  MinecraftBlockTypes2["BrownStainedGlassPane"] = "minecraft:brown_stained_glass_pane";
  MinecraftBlockTypes2["BrownTerracotta"] = "minecraft:brown_terracotta";
  MinecraftBlockTypes2["BrownWool"] = "minecraft:brown_wool";
  MinecraftBlockTypes2["BubbleColumn"] = "minecraft:bubble_column";
  MinecraftBlockTypes2["BubbleCoral"] = "minecraft:bubble_coral";
  MinecraftBlockTypes2["BubbleCoralBlock"] = "minecraft:bubble_coral_block";
  MinecraftBlockTypes2["BubbleCoralFan"] = "minecraft:bubble_coral_fan";
  MinecraftBlockTypes2["BubbleCoralWallFan"] = "minecraft:bubble_coral_wall_fan";
  MinecraftBlockTypes2["BuddingAmethyst"] = "minecraft:budding_amethyst";
  MinecraftBlockTypes2["Bush"] = "minecraft:bush";
  MinecraftBlockTypes2["Cactus"] = "minecraft:cactus";
  MinecraftBlockTypes2["CactusFlower"] = "minecraft:cactus_flower";
  MinecraftBlockTypes2["Cake"] = "minecraft:cake";
  MinecraftBlockTypes2["Calcite"] = "minecraft:calcite";
  MinecraftBlockTypes2["CalibratedSculkSensor"] = "minecraft:calibrated_sculk_sensor";
  MinecraftBlockTypes2["Camera"] = "minecraft:camera";
  MinecraftBlockTypes2["Campfire"] = "minecraft:campfire";
  MinecraftBlockTypes2["Candle"] = "minecraft:candle";
  MinecraftBlockTypes2["CandleCake"] = "minecraft:candle_cake";
  MinecraftBlockTypes2["Carrots"] = "minecraft:carrots";
  MinecraftBlockTypes2["CartographyTable"] = "minecraft:cartography_table";
  MinecraftBlockTypes2["CarvedPumpkin"] = "minecraft:carved_pumpkin";
  MinecraftBlockTypes2["Cauldron"] = "minecraft:cauldron";
  MinecraftBlockTypes2["CaveVines"] = "minecraft:cave_vines";
  MinecraftBlockTypes2["CaveVinesBodyWithBerries"] = "minecraft:cave_vines_body_with_berries";
  MinecraftBlockTypes2["CaveVinesHeadWithBerries"] = "minecraft:cave_vines_head_with_berries";
  MinecraftBlockTypes2["ChainCommandBlock"] = "minecraft:chain_command_block";
  MinecraftBlockTypes2["ChemicalHeat"] = "minecraft:chemical_heat";
  MinecraftBlockTypes2["CherryButton"] = "minecraft:cherry_button";
  MinecraftBlockTypes2["CherryDoor"] = "minecraft:cherry_door";
  MinecraftBlockTypes2["CherryDoubleSlab"] = "minecraft:cherry_double_slab";
  MinecraftBlockTypes2["CherryFence"] = "minecraft:cherry_fence";
  MinecraftBlockTypes2["CherryFenceGate"] = "minecraft:cherry_fence_gate";
  MinecraftBlockTypes2["CherryHangingSign"] = "minecraft:cherry_hanging_sign";
  MinecraftBlockTypes2["CherryLeaves"] = "minecraft:cherry_leaves";
  MinecraftBlockTypes2["CherryLog"] = "minecraft:cherry_log";
  MinecraftBlockTypes2["CherryPlanks"] = "minecraft:cherry_planks";
  MinecraftBlockTypes2["CherryPressurePlate"] = "minecraft:cherry_pressure_plate";
  MinecraftBlockTypes2["CherrySapling"] = "minecraft:cherry_sapling";
  MinecraftBlockTypes2["CherryShelf"] = "minecraft:cherry_shelf";
  MinecraftBlockTypes2["CherrySlab"] = "minecraft:cherry_slab";
  MinecraftBlockTypes2["CherryStairs"] = "minecraft:cherry_stairs";
  MinecraftBlockTypes2["CherryStandingSign"] = "minecraft:cherry_standing_sign";
  MinecraftBlockTypes2["CherryTrapdoor"] = "minecraft:cherry_trapdoor";
  MinecraftBlockTypes2["CherryWallSign"] = "minecraft:cherry_wall_sign";
  MinecraftBlockTypes2["CherryWood"] = "minecraft:cherry_wood";
  MinecraftBlockTypes2["Chest"] = "minecraft:chest";
  MinecraftBlockTypes2["ChippedAnvil"] = "minecraft:chipped_anvil";
  MinecraftBlockTypes2["ChiseledBookshelf"] = "minecraft:chiseled_bookshelf";
  MinecraftBlockTypes2["ChiseledCinnabar"] = "minecraft:chiseled_cinnabar";
  MinecraftBlockTypes2["ChiseledCopper"] = "minecraft:chiseled_copper";
  MinecraftBlockTypes2["ChiseledDeepslate"] = "minecraft:chiseled_deepslate";
  MinecraftBlockTypes2["ChiseledNetherBricks"] = "minecraft:chiseled_nether_bricks";
  MinecraftBlockTypes2["ChiseledPolishedBlackstone"] = "minecraft:chiseled_polished_blackstone";
  MinecraftBlockTypes2["ChiseledQuartzBlock"] = "minecraft:chiseled_quartz_block";
  MinecraftBlockTypes2["ChiseledRedSandstone"] = "minecraft:chiseled_red_sandstone";
  MinecraftBlockTypes2["ChiseledResinBricks"] = "minecraft:chiseled_resin_bricks";
  MinecraftBlockTypes2["ChiseledSandstone"] = "minecraft:chiseled_sandstone";
  MinecraftBlockTypes2["ChiseledStoneBricks"] = "minecraft:chiseled_stone_bricks";
  MinecraftBlockTypes2["ChiseledSulfur"] = "minecraft:chiseled_sulfur";
  MinecraftBlockTypes2["ChiseledTuff"] = "minecraft:chiseled_tuff";
  MinecraftBlockTypes2["ChiseledTuffBricks"] = "minecraft:chiseled_tuff_bricks";
  MinecraftBlockTypes2["ChorusFlower"] = "minecraft:chorus_flower";
  MinecraftBlockTypes2["ChorusPlant"] = "minecraft:chorus_plant";
  MinecraftBlockTypes2["Cinnabar"] = "minecraft:cinnabar";
  MinecraftBlockTypes2["CinnabarBrickDoubleSlab"] = "minecraft:cinnabar_brick_double_slab";
  MinecraftBlockTypes2["CinnabarBrickSlab"] = "minecraft:cinnabar_brick_slab";
  MinecraftBlockTypes2["CinnabarBrickStairs"] = "minecraft:cinnabar_brick_stairs";
  MinecraftBlockTypes2["CinnabarBrickWall"] = "minecraft:cinnabar_brick_wall";
  MinecraftBlockTypes2["CinnabarBricks"] = "minecraft:cinnabar_bricks";
  MinecraftBlockTypes2["CinnabarDoubleSlab"] = "minecraft:cinnabar_double_slab";
  MinecraftBlockTypes2["CinnabarSlab"] = "minecraft:cinnabar_slab";
  MinecraftBlockTypes2["CinnabarStairs"] = "minecraft:cinnabar_stairs";
  MinecraftBlockTypes2["CinnabarWall"] = "minecraft:cinnabar_wall";
  MinecraftBlockTypes2["Clay"] = "minecraft:clay";
  MinecraftBlockTypes2["ClosedEyeblossom"] = "minecraft:closed_eyeblossom";
  MinecraftBlockTypes2["CoalBlock"] = "minecraft:coal_block";
  MinecraftBlockTypes2["CoalOre"] = "minecraft:coal_ore";
  MinecraftBlockTypes2["CoarseDirt"] = "minecraft:coarse_dirt";
  MinecraftBlockTypes2["CobbledDeepslate"] = "minecraft:cobbled_deepslate";
  MinecraftBlockTypes2["CobbledDeepslateDoubleSlab"] = "minecraft:cobbled_deepslate_double_slab";
  MinecraftBlockTypes2["CobbledDeepslateSlab"] = "minecraft:cobbled_deepslate_slab";
  MinecraftBlockTypes2["CobbledDeepslateStairs"] = "minecraft:cobbled_deepslate_stairs";
  MinecraftBlockTypes2["CobbledDeepslateWall"] = "minecraft:cobbled_deepslate_wall";
  MinecraftBlockTypes2["Cobblestone"] = "minecraft:cobblestone";
  MinecraftBlockTypes2["CobblestoneDoubleSlab"] = "minecraft:cobblestone_double_slab";
  MinecraftBlockTypes2["CobblestoneSlab"] = "minecraft:cobblestone_slab";
  MinecraftBlockTypes2["CobblestoneWall"] = "minecraft:cobblestone_wall";
  MinecraftBlockTypes2["Cocoa"] = "minecraft:cocoa";
  MinecraftBlockTypes2["ColoredTorchBlue"] = "minecraft:colored_torch_blue";
  MinecraftBlockTypes2["ColoredTorchGreen"] = "minecraft:colored_torch_green";
  MinecraftBlockTypes2["ColoredTorchPurple"] = "minecraft:colored_torch_purple";
  MinecraftBlockTypes2["ColoredTorchRed"] = "minecraft:colored_torch_red";
  MinecraftBlockTypes2["CommandBlock"] = "minecraft:command_block";
  MinecraftBlockTypes2["Composter"] = "minecraft:composter";
  MinecraftBlockTypes2["CompoundCreator"] = "minecraft:compound_creator";
  MinecraftBlockTypes2["Conduit"] = "minecraft:conduit";
  MinecraftBlockTypes2["CopperBars"] = "minecraft:copper_bars";
  MinecraftBlockTypes2["CopperBlock"] = "minecraft:copper_block";
  MinecraftBlockTypes2["CopperBulb"] = "minecraft:copper_bulb";
  MinecraftBlockTypes2["CopperChain"] = "minecraft:copper_chain";
  MinecraftBlockTypes2["CopperChest"] = "minecraft:copper_chest";
  MinecraftBlockTypes2["CopperDoor"] = "minecraft:copper_door";
  MinecraftBlockTypes2["CopperGolemStatue"] = "minecraft:copper_golem_statue";
  MinecraftBlockTypes2["CopperGrate"] = "minecraft:copper_grate";
  MinecraftBlockTypes2["CopperLantern"] = "minecraft:copper_lantern";
  MinecraftBlockTypes2["CopperOre"] = "minecraft:copper_ore";
  MinecraftBlockTypes2["CopperTorch"] = "minecraft:copper_torch";
  MinecraftBlockTypes2["CopperTrapdoor"] = "minecraft:copper_trapdoor";
  MinecraftBlockTypes2["Cornflower"] = "minecraft:cornflower";
  MinecraftBlockTypes2["CrackedDeepslateBricks"] = "minecraft:cracked_deepslate_bricks";
  MinecraftBlockTypes2["CrackedDeepslateTiles"] = "minecraft:cracked_deepslate_tiles";
  MinecraftBlockTypes2["CrackedNetherBricks"] = "minecraft:cracked_nether_bricks";
  MinecraftBlockTypes2["CrackedPolishedBlackstoneBricks"] = "minecraft:cracked_polished_blackstone_bricks";
  MinecraftBlockTypes2["CrackedStoneBricks"] = "minecraft:cracked_stone_bricks";
  MinecraftBlockTypes2["Crafter"] = "minecraft:crafter";
  MinecraftBlockTypes2["CraftingTable"] = "minecraft:crafting_table";
  MinecraftBlockTypes2["CreakingHeart"] = "minecraft:creaking_heart";
  MinecraftBlockTypes2["CreeperHead"] = "minecraft:creeper_head";
  MinecraftBlockTypes2["CrimsonButton"] = "minecraft:crimson_button";
  MinecraftBlockTypes2["CrimsonDoor"] = "minecraft:crimson_door";
  MinecraftBlockTypes2["CrimsonDoubleSlab"] = "minecraft:crimson_double_slab";
  MinecraftBlockTypes2["CrimsonFence"] = "minecraft:crimson_fence";
  MinecraftBlockTypes2["CrimsonFenceGate"] = "minecraft:crimson_fence_gate";
  MinecraftBlockTypes2["CrimsonFungus"] = "minecraft:crimson_fungus";
  MinecraftBlockTypes2["CrimsonHangingSign"] = "minecraft:crimson_hanging_sign";
  MinecraftBlockTypes2["CrimsonHyphae"] = "minecraft:crimson_hyphae";
  MinecraftBlockTypes2["CrimsonNylium"] = "minecraft:crimson_nylium";
  MinecraftBlockTypes2["CrimsonPlanks"] = "minecraft:crimson_planks";
  MinecraftBlockTypes2["CrimsonPressurePlate"] = "minecraft:crimson_pressure_plate";
  MinecraftBlockTypes2["CrimsonRoots"] = "minecraft:crimson_roots";
  MinecraftBlockTypes2["CrimsonShelf"] = "minecraft:crimson_shelf";
  MinecraftBlockTypes2["CrimsonSlab"] = "minecraft:crimson_slab";
  MinecraftBlockTypes2["CrimsonStairs"] = "minecraft:crimson_stairs";
  MinecraftBlockTypes2["CrimsonStandingSign"] = "minecraft:crimson_standing_sign";
  MinecraftBlockTypes2["CrimsonStem"] = "minecraft:crimson_stem";
  MinecraftBlockTypes2["CrimsonTrapdoor"] = "minecraft:crimson_trapdoor";
  MinecraftBlockTypes2["CrimsonWallSign"] = "minecraft:crimson_wall_sign";
  MinecraftBlockTypes2["CryingObsidian"] = "minecraft:crying_obsidian";
  MinecraftBlockTypes2["CutCopper"] = "minecraft:cut_copper";
  MinecraftBlockTypes2["CutCopperSlab"] = "minecraft:cut_copper_slab";
  MinecraftBlockTypes2["CutCopperStairs"] = "minecraft:cut_copper_stairs";
  MinecraftBlockTypes2["CutRedSandstone"] = "minecraft:cut_red_sandstone";
  MinecraftBlockTypes2["CutRedSandstoneDoubleSlab"] = "minecraft:cut_red_sandstone_double_slab";
  MinecraftBlockTypes2["CutRedSandstoneSlab"] = "minecraft:cut_red_sandstone_slab";
  MinecraftBlockTypes2["CutSandstone"] = "minecraft:cut_sandstone";
  MinecraftBlockTypes2["CutSandstoneDoubleSlab"] = "minecraft:cut_sandstone_double_slab";
  MinecraftBlockTypes2["CutSandstoneSlab"] = "minecraft:cut_sandstone_slab";
  MinecraftBlockTypes2["CyanCandle"] = "minecraft:cyan_candle";
  MinecraftBlockTypes2["CyanCandleCake"] = "minecraft:cyan_candle_cake";
  MinecraftBlockTypes2["CyanCarpet"] = "minecraft:cyan_carpet";
  MinecraftBlockTypes2["CyanConcrete"] = "minecraft:cyan_concrete";
  MinecraftBlockTypes2["CyanConcretePowder"] = "minecraft:cyan_concrete_powder";
  MinecraftBlockTypes2["CyanGlazedTerracotta"] = "minecraft:cyan_glazed_terracotta";
  MinecraftBlockTypes2["CyanShulkerBox"] = "minecraft:cyan_shulker_box";
  MinecraftBlockTypes2["CyanStainedGlass"] = "minecraft:cyan_stained_glass";
  MinecraftBlockTypes2["CyanStainedGlassPane"] = "minecraft:cyan_stained_glass_pane";
  MinecraftBlockTypes2["CyanTerracotta"] = "minecraft:cyan_terracotta";
  MinecraftBlockTypes2["CyanWool"] = "minecraft:cyan_wool";
  MinecraftBlockTypes2["DamagedAnvil"] = "minecraft:damaged_anvil";
  MinecraftBlockTypes2["Dandelion"] = "minecraft:dandelion";
  MinecraftBlockTypes2["DarkOakButton"] = "minecraft:dark_oak_button";
  MinecraftBlockTypes2["DarkOakDoor"] = "minecraft:dark_oak_door";
  MinecraftBlockTypes2["DarkOakDoubleSlab"] = "minecraft:dark_oak_double_slab";
  MinecraftBlockTypes2["DarkOakFence"] = "minecraft:dark_oak_fence";
  MinecraftBlockTypes2["DarkOakFenceGate"] = "minecraft:dark_oak_fence_gate";
  MinecraftBlockTypes2["DarkOakHangingSign"] = "minecraft:dark_oak_hanging_sign";
  MinecraftBlockTypes2["DarkOakLeaves"] = "minecraft:dark_oak_leaves";
  MinecraftBlockTypes2["DarkOakLog"] = "minecraft:dark_oak_log";
  MinecraftBlockTypes2["DarkOakPlanks"] = "minecraft:dark_oak_planks";
  MinecraftBlockTypes2["DarkOakPressurePlate"] = "minecraft:dark_oak_pressure_plate";
  MinecraftBlockTypes2["DarkOakSapling"] = "minecraft:dark_oak_sapling";
  MinecraftBlockTypes2["DarkOakShelf"] = "minecraft:dark_oak_shelf";
  MinecraftBlockTypes2["DarkOakSlab"] = "minecraft:dark_oak_slab";
  MinecraftBlockTypes2["DarkOakStairs"] = "minecraft:dark_oak_stairs";
  MinecraftBlockTypes2["DarkOakTrapdoor"] = "minecraft:dark_oak_trapdoor";
  MinecraftBlockTypes2["DarkOakWood"] = "minecraft:dark_oak_wood";
  MinecraftBlockTypes2["DarkPrismarine"] = "minecraft:dark_prismarine";
  MinecraftBlockTypes2["DarkPrismarineDoubleSlab"] = "minecraft:dark_prismarine_double_slab";
  MinecraftBlockTypes2["DarkPrismarineSlab"] = "minecraft:dark_prismarine_slab";
  MinecraftBlockTypes2["DarkPrismarineStairs"] = "minecraft:dark_prismarine_stairs";
  MinecraftBlockTypes2["DarkoakStandingSign"] = "minecraft:darkoak_standing_sign";
  MinecraftBlockTypes2["DarkoakWallSign"] = "minecraft:darkoak_wall_sign";
  MinecraftBlockTypes2["DaylightDetector"] = "minecraft:daylight_detector";
  MinecraftBlockTypes2["DaylightDetectorInverted"] = "minecraft:daylight_detector_inverted";
  MinecraftBlockTypes2["DeadBrainCoral"] = "minecraft:dead_brain_coral";
  MinecraftBlockTypes2["DeadBrainCoralBlock"] = "minecraft:dead_brain_coral_block";
  MinecraftBlockTypes2["DeadBrainCoralFan"] = "minecraft:dead_brain_coral_fan";
  MinecraftBlockTypes2["DeadBrainCoralWallFan"] = "minecraft:dead_brain_coral_wall_fan";
  MinecraftBlockTypes2["DeadBubbleCoral"] = "minecraft:dead_bubble_coral";
  MinecraftBlockTypes2["DeadBubbleCoralBlock"] = "minecraft:dead_bubble_coral_block";
  MinecraftBlockTypes2["DeadBubbleCoralFan"] = "minecraft:dead_bubble_coral_fan";
  MinecraftBlockTypes2["DeadBubbleCoralWallFan"] = "minecraft:dead_bubble_coral_wall_fan";
  MinecraftBlockTypes2["DeadFireCoral"] = "minecraft:dead_fire_coral";
  MinecraftBlockTypes2["DeadFireCoralBlock"] = "minecraft:dead_fire_coral_block";
  MinecraftBlockTypes2["DeadFireCoralFan"] = "minecraft:dead_fire_coral_fan";
  MinecraftBlockTypes2["DeadFireCoralWallFan"] = "minecraft:dead_fire_coral_wall_fan";
  MinecraftBlockTypes2["DeadHornCoral"] = "minecraft:dead_horn_coral";
  MinecraftBlockTypes2["DeadHornCoralBlock"] = "minecraft:dead_horn_coral_block";
  MinecraftBlockTypes2["DeadHornCoralFan"] = "minecraft:dead_horn_coral_fan";
  MinecraftBlockTypes2["DeadHornCoralWallFan"] = "minecraft:dead_horn_coral_wall_fan";
  MinecraftBlockTypes2["DeadTubeCoral"] = "minecraft:dead_tube_coral";
  MinecraftBlockTypes2["DeadTubeCoralBlock"] = "minecraft:dead_tube_coral_block";
  MinecraftBlockTypes2["DeadTubeCoralFan"] = "minecraft:dead_tube_coral_fan";
  MinecraftBlockTypes2["DeadTubeCoralWallFan"] = "minecraft:dead_tube_coral_wall_fan";
  MinecraftBlockTypes2["Deadbush"] = "minecraft:deadbush";
  MinecraftBlockTypes2["DecoratedPot"] = "minecraft:decorated_pot";
  MinecraftBlockTypes2["Deepslate"] = "minecraft:deepslate";
  MinecraftBlockTypes2["DeepslateBrickDoubleSlab"] = "minecraft:deepslate_brick_double_slab";
  MinecraftBlockTypes2["DeepslateBrickSlab"] = "minecraft:deepslate_brick_slab";
  MinecraftBlockTypes2["DeepslateBrickStairs"] = "minecraft:deepslate_brick_stairs";
  MinecraftBlockTypes2["DeepslateBrickWall"] = "minecraft:deepslate_brick_wall";
  MinecraftBlockTypes2["DeepslateBricks"] = "minecraft:deepslate_bricks";
  MinecraftBlockTypes2["DeepslateCoalOre"] = "minecraft:deepslate_coal_ore";
  MinecraftBlockTypes2["DeepslateCopperOre"] = "minecraft:deepslate_copper_ore";
  MinecraftBlockTypes2["DeepslateDiamondOre"] = "minecraft:deepslate_diamond_ore";
  MinecraftBlockTypes2["DeepslateEmeraldOre"] = "minecraft:deepslate_emerald_ore";
  MinecraftBlockTypes2["DeepslateGoldOre"] = "minecraft:deepslate_gold_ore";
  MinecraftBlockTypes2["DeepslateIronOre"] = "minecraft:deepslate_iron_ore";
  MinecraftBlockTypes2["DeepslateLapisOre"] = "minecraft:deepslate_lapis_ore";
  MinecraftBlockTypes2["DeepslateRedstoneOre"] = "minecraft:deepslate_redstone_ore";
  MinecraftBlockTypes2["DeepslateTileDoubleSlab"] = "minecraft:deepslate_tile_double_slab";
  MinecraftBlockTypes2["DeepslateTileSlab"] = "minecraft:deepslate_tile_slab";
  MinecraftBlockTypes2["DeepslateTileStairs"] = "minecraft:deepslate_tile_stairs";
  MinecraftBlockTypes2["DeepslateTileWall"] = "minecraft:deepslate_tile_wall";
  MinecraftBlockTypes2["DeepslateTiles"] = "minecraft:deepslate_tiles";
  MinecraftBlockTypes2["Deny"] = "minecraft:deny";
  MinecraftBlockTypes2["DetectorRail"] = "minecraft:detector_rail";
  MinecraftBlockTypes2["DiamondBlock"] = "minecraft:diamond_block";
  MinecraftBlockTypes2["DiamondOre"] = "minecraft:diamond_ore";
  MinecraftBlockTypes2["Diorite"] = "minecraft:diorite";
  MinecraftBlockTypes2["DioriteDoubleSlab"] = "minecraft:diorite_double_slab";
  MinecraftBlockTypes2["DioriteSlab"] = "minecraft:diorite_slab";
  MinecraftBlockTypes2["DioriteStairs"] = "minecraft:diorite_stairs";
  MinecraftBlockTypes2["DioriteWall"] = "minecraft:diorite_wall";
  MinecraftBlockTypes2["Dirt"] = "minecraft:dirt";
  MinecraftBlockTypes2["DirtWithRoots"] = "minecraft:dirt_with_roots";
  MinecraftBlockTypes2["Dispenser"] = "minecraft:dispenser";
  MinecraftBlockTypes2["DoubleCutCopperSlab"] = "minecraft:double_cut_copper_slab";
  MinecraftBlockTypes2["DragonEgg"] = "minecraft:dragon_egg";
  MinecraftBlockTypes2["DragonHead"] = "minecraft:dragon_head";
  MinecraftBlockTypes2["DriedGhast"] = "minecraft:dried_ghast";
  MinecraftBlockTypes2["DriedKelpBlock"] = "minecraft:dried_kelp_block";
  MinecraftBlockTypes2["DripstoneBlock"] = "minecraft:dripstone_block";
  MinecraftBlockTypes2["Dropper"] = "minecraft:dropper";
  MinecraftBlockTypes2["Element0"] = "minecraft:element_0";
  MinecraftBlockTypes2["Element1"] = "minecraft:element_1";
  MinecraftBlockTypes2["Element10"] = "minecraft:element_10";
  MinecraftBlockTypes2["Element100"] = "minecraft:element_100";
  MinecraftBlockTypes2["Element101"] = "minecraft:element_101";
  MinecraftBlockTypes2["Element102"] = "minecraft:element_102";
  MinecraftBlockTypes2["Element103"] = "minecraft:element_103";
  MinecraftBlockTypes2["Element104"] = "minecraft:element_104";
  MinecraftBlockTypes2["Element105"] = "minecraft:element_105";
  MinecraftBlockTypes2["Element106"] = "minecraft:element_106";
  MinecraftBlockTypes2["Element107"] = "minecraft:element_107";
  MinecraftBlockTypes2["Element108"] = "minecraft:element_108";
  MinecraftBlockTypes2["Element109"] = "minecraft:element_109";
  MinecraftBlockTypes2["Element11"] = "minecraft:element_11";
  MinecraftBlockTypes2["Element110"] = "minecraft:element_110";
  MinecraftBlockTypes2["Element111"] = "minecraft:element_111";
  MinecraftBlockTypes2["Element112"] = "minecraft:element_112";
  MinecraftBlockTypes2["Element113"] = "minecraft:element_113";
  MinecraftBlockTypes2["Element114"] = "minecraft:element_114";
  MinecraftBlockTypes2["Element115"] = "minecraft:element_115";
  MinecraftBlockTypes2["Element116"] = "minecraft:element_116";
  MinecraftBlockTypes2["Element117"] = "minecraft:element_117";
  MinecraftBlockTypes2["Element118"] = "minecraft:element_118";
  MinecraftBlockTypes2["Element12"] = "minecraft:element_12";
  MinecraftBlockTypes2["Element13"] = "minecraft:element_13";
  MinecraftBlockTypes2["Element14"] = "minecraft:element_14";
  MinecraftBlockTypes2["Element15"] = "minecraft:element_15";
  MinecraftBlockTypes2["Element16"] = "minecraft:element_16";
  MinecraftBlockTypes2["Element17"] = "minecraft:element_17";
  MinecraftBlockTypes2["Element18"] = "minecraft:element_18";
  MinecraftBlockTypes2["Element19"] = "minecraft:element_19";
  MinecraftBlockTypes2["Element2"] = "minecraft:element_2";
  MinecraftBlockTypes2["Element20"] = "minecraft:element_20";
  MinecraftBlockTypes2["Element21"] = "minecraft:element_21";
  MinecraftBlockTypes2["Element22"] = "minecraft:element_22";
  MinecraftBlockTypes2["Element23"] = "minecraft:element_23";
  MinecraftBlockTypes2["Element24"] = "minecraft:element_24";
  MinecraftBlockTypes2["Element25"] = "minecraft:element_25";
  MinecraftBlockTypes2["Element26"] = "minecraft:element_26";
  MinecraftBlockTypes2["Element27"] = "minecraft:element_27";
  MinecraftBlockTypes2["Element28"] = "minecraft:element_28";
  MinecraftBlockTypes2["Element29"] = "minecraft:element_29";
  MinecraftBlockTypes2["Element3"] = "minecraft:element_3";
  MinecraftBlockTypes2["Element30"] = "minecraft:element_30";
  MinecraftBlockTypes2["Element31"] = "minecraft:element_31";
  MinecraftBlockTypes2["Element32"] = "minecraft:element_32";
  MinecraftBlockTypes2["Element33"] = "minecraft:element_33";
  MinecraftBlockTypes2["Element34"] = "minecraft:element_34";
  MinecraftBlockTypes2["Element35"] = "minecraft:element_35";
  MinecraftBlockTypes2["Element36"] = "minecraft:element_36";
  MinecraftBlockTypes2["Element37"] = "minecraft:element_37";
  MinecraftBlockTypes2["Element38"] = "minecraft:element_38";
  MinecraftBlockTypes2["Element39"] = "minecraft:element_39";
  MinecraftBlockTypes2["Element4"] = "minecraft:element_4";
  MinecraftBlockTypes2["Element40"] = "minecraft:element_40";
  MinecraftBlockTypes2["Element41"] = "minecraft:element_41";
  MinecraftBlockTypes2["Element42"] = "minecraft:element_42";
  MinecraftBlockTypes2["Element43"] = "minecraft:element_43";
  MinecraftBlockTypes2["Element44"] = "minecraft:element_44";
  MinecraftBlockTypes2["Element45"] = "minecraft:element_45";
  MinecraftBlockTypes2["Element46"] = "minecraft:element_46";
  MinecraftBlockTypes2["Element47"] = "minecraft:element_47";
  MinecraftBlockTypes2["Element48"] = "minecraft:element_48";
  MinecraftBlockTypes2["Element49"] = "minecraft:element_49";
  MinecraftBlockTypes2["Element5"] = "minecraft:element_5";
  MinecraftBlockTypes2["Element50"] = "minecraft:element_50";
  MinecraftBlockTypes2["Element51"] = "minecraft:element_51";
  MinecraftBlockTypes2["Element52"] = "minecraft:element_52";
  MinecraftBlockTypes2["Element53"] = "minecraft:element_53";
  MinecraftBlockTypes2["Element54"] = "minecraft:element_54";
  MinecraftBlockTypes2["Element55"] = "minecraft:element_55";
  MinecraftBlockTypes2["Element56"] = "minecraft:element_56";
  MinecraftBlockTypes2["Element57"] = "minecraft:element_57";
  MinecraftBlockTypes2["Element58"] = "minecraft:element_58";
  MinecraftBlockTypes2["Element59"] = "minecraft:element_59";
  MinecraftBlockTypes2["Element6"] = "minecraft:element_6";
  MinecraftBlockTypes2["Element60"] = "minecraft:element_60";
  MinecraftBlockTypes2["Element61"] = "minecraft:element_61";
  MinecraftBlockTypes2["Element62"] = "minecraft:element_62";
  MinecraftBlockTypes2["Element63"] = "minecraft:element_63";
  MinecraftBlockTypes2["Element64"] = "minecraft:element_64";
  MinecraftBlockTypes2["Element65"] = "minecraft:element_65";
  MinecraftBlockTypes2["Element66"] = "minecraft:element_66";
  MinecraftBlockTypes2["Element67"] = "minecraft:element_67";
  MinecraftBlockTypes2["Element68"] = "minecraft:element_68";
  MinecraftBlockTypes2["Element69"] = "minecraft:element_69";
  MinecraftBlockTypes2["Element7"] = "minecraft:element_7";
  MinecraftBlockTypes2["Element70"] = "minecraft:element_70";
  MinecraftBlockTypes2["Element71"] = "minecraft:element_71";
  MinecraftBlockTypes2["Element72"] = "minecraft:element_72";
  MinecraftBlockTypes2["Element73"] = "minecraft:element_73";
  MinecraftBlockTypes2["Element74"] = "minecraft:element_74";
  MinecraftBlockTypes2["Element75"] = "minecraft:element_75";
  MinecraftBlockTypes2["Element76"] = "minecraft:element_76";
  MinecraftBlockTypes2["Element77"] = "minecraft:element_77";
  MinecraftBlockTypes2["Element78"] = "minecraft:element_78";
  MinecraftBlockTypes2["Element79"] = "minecraft:element_79";
  MinecraftBlockTypes2["Element8"] = "minecraft:element_8";
  MinecraftBlockTypes2["Element80"] = "minecraft:element_80";
  MinecraftBlockTypes2["Element81"] = "minecraft:element_81";
  MinecraftBlockTypes2["Element82"] = "minecraft:element_82";
  MinecraftBlockTypes2["Element83"] = "minecraft:element_83";
  MinecraftBlockTypes2["Element84"] = "minecraft:element_84";
  MinecraftBlockTypes2["Element85"] = "minecraft:element_85";
  MinecraftBlockTypes2["Element86"] = "minecraft:element_86";
  MinecraftBlockTypes2["Element87"] = "minecraft:element_87";
  MinecraftBlockTypes2["Element88"] = "minecraft:element_88";
  MinecraftBlockTypes2["Element89"] = "minecraft:element_89";
  MinecraftBlockTypes2["Element9"] = "minecraft:element_9";
  MinecraftBlockTypes2["Element90"] = "minecraft:element_90";
  MinecraftBlockTypes2["Element91"] = "minecraft:element_91";
  MinecraftBlockTypes2["Element92"] = "minecraft:element_92";
  MinecraftBlockTypes2["Element93"] = "minecraft:element_93";
  MinecraftBlockTypes2["Element94"] = "minecraft:element_94";
  MinecraftBlockTypes2["Element95"] = "minecraft:element_95";
  MinecraftBlockTypes2["Element96"] = "minecraft:element_96";
  MinecraftBlockTypes2["Element97"] = "minecraft:element_97";
  MinecraftBlockTypes2["Element98"] = "minecraft:element_98";
  MinecraftBlockTypes2["Element99"] = "minecraft:element_99";
  MinecraftBlockTypes2["ElementConstructor"] = "minecraft:element_constructor";
  MinecraftBlockTypes2["EmeraldBlock"] = "minecraft:emerald_block";
  MinecraftBlockTypes2["EmeraldOre"] = "minecraft:emerald_ore";
  MinecraftBlockTypes2["EnchantingTable"] = "minecraft:enchanting_table";
  MinecraftBlockTypes2["EndBrickStairs"] = "minecraft:end_brick_stairs";
  MinecraftBlockTypes2["EndBricks"] = "minecraft:end_bricks";
  MinecraftBlockTypes2["EndPortal"] = "minecraft:end_portal";
  MinecraftBlockTypes2["EndPortalFrame"] = "minecraft:end_portal_frame";
  MinecraftBlockTypes2["EndRod"] = "minecraft:end_rod";
  MinecraftBlockTypes2["EndStone"] = "minecraft:end_stone";
  MinecraftBlockTypes2["EndStoneBrickDoubleSlab"] = "minecraft:end_stone_brick_double_slab";
  MinecraftBlockTypes2["EndStoneBrickSlab"] = "minecraft:end_stone_brick_slab";
  MinecraftBlockTypes2["EndStoneBrickWall"] = "minecraft:end_stone_brick_wall";
  MinecraftBlockTypes2["EnderChest"] = "minecraft:ender_chest";
  MinecraftBlockTypes2["ExposedChiseledCopper"] = "minecraft:exposed_chiseled_copper";
  MinecraftBlockTypes2["ExposedCopper"] = "minecraft:exposed_copper";
  MinecraftBlockTypes2["ExposedCopperBars"] = "minecraft:exposed_copper_bars";
  MinecraftBlockTypes2["ExposedCopperBulb"] = "minecraft:exposed_copper_bulb";
  MinecraftBlockTypes2["ExposedCopperChain"] = "minecraft:exposed_copper_chain";
  MinecraftBlockTypes2["ExposedCopperChest"] = "minecraft:exposed_copper_chest";
  MinecraftBlockTypes2["ExposedCopperDoor"] = "minecraft:exposed_copper_door";
  MinecraftBlockTypes2["ExposedCopperGolemStatue"] = "minecraft:exposed_copper_golem_statue";
  MinecraftBlockTypes2["ExposedCopperGrate"] = "minecraft:exposed_copper_grate";
  MinecraftBlockTypes2["ExposedCopperLantern"] = "minecraft:exposed_copper_lantern";
  MinecraftBlockTypes2["ExposedCopperTrapdoor"] = "minecraft:exposed_copper_trapdoor";
  MinecraftBlockTypes2["ExposedCutCopper"] = "minecraft:exposed_cut_copper";
  MinecraftBlockTypes2["ExposedCutCopperSlab"] = "minecraft:exposed_cut_copper_slab";
  MinecraftBlockTypes2["ExposedCutCopperStairs"] = "minecraft:exposed_cut_copper_stairs";
  MinecraftBlockTypes2["ExposedDoubleCutCopperSlab"] = "minecraft:exposed_double_cut_copper_slab";
  MinecraftBlockTypes2["ExposedLightningRod"] = "minecraft:exposed_lightning_rod";
  MinecraftBlockTypes2["Farmland"] = "minecraft:farmland";
  MinecraftBlockTypes2["FenceGate"] = "minecraft:fence_gate";
  MinecraftBlockTypes2["Fern"] = "minecraft:fern";
  MinecraftBlockTypes2["Fire"] = "minecraft:fire";
  MinecraftBlockTypes2["FireCoral"] = "minecraft:fire_coral";
  MinecraftBlockTypes2["FireCoralBlock"] = "minecraft:fire_coral_block";
  MinecraftBlockTypes2["FireCoralFan"] = "minecraft:fire_coral_fan";
  MinecraftBlockTypes2["FireCoralWallFan"] = "minecraft:fire_coral_wall_fan";
  MinecraftBlockTypes2["FireflyBush"] = "minecraft:firefly_bush";
  MinecraftBlockTypes2["FletchingTable"] = "minecraft:fletching_table";
  MinecraftBlockTypes2["FlowerPot"] = "minecraft:flower_pot";
  MinecraftBlockTypes2["FloweringAzalea"] = "minecraft:flowering_azalea";
  MinecraftBlockTypes2["FlowingLava"] = "minecraft:flowing_lava";
  MinecraftBlockTypes2["FlowingWater"] = "minecraft:flowing_water";
  MinecraftBlockTypes2["Frame"] = "minecraft:frame";
  MinecraftBlockTypes2["FrogSpawn"] = "minecraft:frog_spawn";
  MinecraftBlockTypes2["FrostedIce"] = "minecraft:frosted_ice";
  MinecraftBlockTypes2["Furnace"] = "minecraft:furnace";
  MinecraftBlockTypes2["GildedBlackstone"] = "minecraft:gilded_blackstone";
  MinecraftBlockTypes2["Glass"] = "minecraft:glass";
  MinecraftBlockTypes2["GlassPane"] = "minecraft:glass_pane";
  MinecraftBlockTypes2["GlowFrame"] = "minecraft:glow_frame";
  MinecraftBlockTypes2["GlowLichen"] = "minecraft:glow_lichen";
  MinecraftBlockTypes2["Glowstone"] = "minecraft:glowstone";
  MinecraftBlockTypes2["GoldBlock"] = "minecraft:gold_block";
  MinecraftBlockTypes2["GoldOre"] = "minecraft:gold_ore";
  MinecraftBlockTypes2["GoldenDandelion"] = "minecraft:golden_dandelion";
  MinecraftBlockTypes2["GoldenRail"] = "minecraft:golden_rail";
  MinecraftBlockTypes2["Granite"] = "minecraft:granite";
  MinecraftBlockTypes2["GraniteDoubleSlab"] = "minecraft:granite_double_slab";
  MinecraftBlockTypes2["GraniteSlab"] = "minecraft:granite_slab";
  MinecraftBlockTypes2["GraniteStairs"] = "minecraft:granite_stairs";
  MinecraftBlockTypes2["GraniteWall"] = "minecraft:granite_wall";
  MinecraftBlockTypes2["GrassBlock"] = "minecraft:grass_block";
  MinecraftBlockTypes2["GrassPath"] = "minecraft:grass_path";
  MinecraftBlockTypes2["Gravel"] = "minecraft:gravel";
  MinecraftBlockTypes2["GrayCandle"] = "minecraft:gray_candle";
  MinecraftBlockTypes2["GrayCandleCake"] = "minecraft:gray_candle_cake";
  MinecraftBlockTypes2["GrayCarpet"] = "minecraft:gray_carpet";
  MinecraftBlockTypes2["GrayConcrete"] = "minecraft:gray_concrete";
  MinecraftBlockTypes2["GrayConcretePowder"] = "minecraft:gray_concrete_powder";
  MinecraftBlockTypes2["GrayGlazedTerracotta"] = "minecraft:gray_glazed_terracotta";
  MinecraftBlockTypes2["GrayShulkerBox"] = "minecraft:gray_shulker_box";
  MinecraftBlockTypes2["GrayStainedGlass"] = "minecraft:gray_stained_glass";
  MinecraftBlockTypes2["GrayStainedGlassPane"] = "minecraft:gray_stained_glass_pane";
  MinecraftBlockTypes2["GrayTerracotta"] = "minecraft:gray_terracotta";
  MinecraftBlockTypes2["GrayWool"] = "minecraft:gray_wool";
  MinecraftBlockTypes2["GreenCandle"] = "minecraft:green_candle";
  MinecraftBlockTypes2["GreenCandleCake"] = "minecraft:green_candle_cake";
  MinecraftBlockTypes2["GreenCarpet"] = "minecraft:green_carpet";
  MinecraftBlockTypes2["GreenConcrete"] = "minecraft:green_concrete";
  MinecraftBlockTypes2["GreenConcretePowder"] = "minecraft:green_concrete_powder";
  MinecraftBlockTypes2["GreenGlazedTerracotta"] = "minecraft:green_glazed_terracotta";
  MinecraftBlockTypes2["GreenShulkerBox"] = "minecraft:green_shulker_box";
  MinecraftBlockTypes2["GreenStainedGlass"] = "minecraft:green_stained_glass";
  MinecraftBlockTypes2["GreenStainedGlassPane"] = "minecraft:green_stained_glass_pane";
  MinecraftBlockTypes2["GreenTerracotta"] = "minecraft:green_terracotta";
  MinecraftBlockTypes2["GreenWool"] = "minecraft:green_wool";
  MinecraftBlockTypes2["Grindstone"] = "minecraft:grindstone";
  MinecraftBlockTypes2["HangingRoots"] = "minecraft:hanging_roots";
  MinecraftBlockTypes2["HardBlackStainedGlass"] = "minecraft:hard_black_stained_glass";
  MinecraftBlockTypes2["HardBlackStainedGlassPane"] = "minecraft:hard_black_stained_glass_pane";
  MinecraftBlockTypes2["HardBlueStainedGlass"] = "minecraft:hard_blue_stained_glass";
  MinecraftBlockTypes2["HardBlueStainedGlassPane"] = "minecraft:hard_blue_stained_glass_pane";
  MinecraftBlockTypes2["HardBrownStainedGlass"] = "minecraft:hard_brown_stained_glass";
  MinecraftBlockTypes2["HardBrownStainedGlassPane"] = "minecraft:hard_brown_stained_glass_pane";
  MinecraftBlockTypes2["HardCyanStainedGlass"] = "minecraft:hard_cyan_stained_glass";
  MinecraftBlockTypes2["HardCyanStainedGlassPane"] = "minecraft:hard_cyan_stained_glass_pane";
  MinecraftBlockTypes2["HardGlass"] = "minecraft:hard_glass";
  MinecraftBlockTypes2["HardGlassPane"] = "minecraft:hard_glass_pane";
  MinecraftBlockTypes2["HardGrayStainedGlass"] = "minecraft:hard_gray_stained_glass";
  MinecraftBlockTypes2["HardGrayStainedGlassPane"] = "minecraft:hard_gray_stained_glass_pane";
  MinecraftBlockTypes2["HardGreenStainedGlass"] = "minecraft:hard_green_stained_glass";
  MinecraftBlockTypes2["HardGreenStainedGlassPane"] = "minecraft:hard_green_stained_glass_pane";
  MinecraftBlockTypes2["HardLightBlueStainedGlass"] = "minecraft:hard_light_blue_stained_glass";
  MinecraftBlockTypes2["HardLightBlueStainedGlassPane"] = "minecraft:hard_light_blue_stained_glass_pane";
  MinecraftBlockTypes2["HardLightGrayStainedGlass"] = "minecraft:hard_light_gray_stained_glass";
  MinecraftBlockTypes2["HardLightGrayStainedGlassPane"] = "minecraft:hard_light_gray_stained_glass_pane";
  MinecraftBlockTypes2["HardLimeStainedGlass"] = "minecraft:hard_lime_stained_glass";
  MinecraftBlockTypes2["HardLimeStainedGlassPane"] = "minecraft:hard_lime_stained_glass_pane";
  MinecraftBlockTypes2["HardMagentaStainedGlass"] = "minecraft:hard_magenta_stained_glass";
  MinecraftBlockTypes2["HardMagentaStainedGlassPane"] = "minecraft:hard_magenta_stained_glass_pane";
  MinecraftBlockTypes2["HardOrangeStainedGlass"] = "minecraft:hard_orange_stained_glass";
  MinecraftBlockTypes2["HardOrangeStainedGlassPane"] = "minecraft:hard_orange_stained_glass_pane";
  MinecraftBlockTypes2["HardPinkStainedGlass"] = "minecraft:hard_pink_stained_glass";
  MinecraftBlockTypes2["HardPinkStainedGlassPane"] = "minecraft:hard_pink_stained_glass_pane";
  MinecraftBlockTypes2["HardPurpleStainedGlass"] = "minecraft:hard_purple_stained_glass";
  MinecraftBlockTypes2["HardPurpleStainedGlassPane"] = "minecraft:hard_purple_stained_glass_pane";
  MinecraftBlockTypes2["HardRedStainedGlass"] = "minecraft:hard_red_stained_glass";
  MinecraftBlockTypes2["HardRedStainedGlassPane"] = "minecraft:hard_red_stained_glass_pane";
  MinecraftBlockTypes2["HardWhiteStainedGlass"] = "minecraft:hard_white_stained_glass";
  MinecraftBlockTypes2["HardWhiteStainedGlassPane"] = "minecraft:hard_white_stained_glass_pane";
  MinecraftBlockTypes2["HardYellowStainedGlass"] = "minecraft:hard_yellow_stained_glass";
  MinecraftBlockTypes2["HardYellowStainedGlassPane"] = "minecraft:hard_yellow_stained_glass_pane";
  MinecraftBlockTypes2["HardenedClay"] = "minecraft:hardened_clay";
  MinecraftBlockTypes2["HayBlock"] = "minecraft:hay_block";
  MinecraftBlockTypes2["HeavyCore"] = "minecraft:heavy_core";
  MinecraftBlockTypes2["HeavyWeightedPressurePlate"] = "minecraft:heavy_weighted_pressure_plate";
  MinecraftBlockTypes2["HoneyBlock"] = "minecraft:honey_block";
  MinecraftBlockTypes2["HoneycombBlock"] = "minecraft:honeycomb_block";
  MinecraftBlockTypes2["Hopper"] = "minecraft:hopper";
  MinecraftBlockTypes2["HornCoral"] = "minecraft:horn_coral";
  MinecraftBlockTypes2["HornCoralBlock"] = "minecraft:horn_coral_block";
  MinecraftBlockTypes2["HornCoralFan"] = "minecraft:horn_coral_fan";
  MinecraftBlockTypes2["HornCoralWallFan"] = "minecraft:horn_coral_wall_fan";
  MinecraftBlockTypes2["Ice"] = "minecraft:ice";
  MinecraftBlockTypes2["InfestedChiseledStoneBricks"] = "minecraft:infested_chiseled_stone_bricks";
  MinecraftBlockTypes2["InfestedCobblestone"] = "minecraft:infested_cobblestone";
  MinecraftBlockTypes2["InfestedCrackedStoneBricks"] = "minecraft:infested_cracked_stone_bricks";
  MinecraftBlockTypes2["InfestedDeepslate"] = "minecraft:infested_deepslate";
  MinecraftBlockTypes2["InfestedMossyStoneBricks"] = "minecraft:infested_mossy_stone_bricks";
  MinecraftBlockTypes2["InfestedStone"] = "minecraft:infested_stone";
  MinecraftBlockTypes2["InfestedStoneBricks"] = "minecraft:infested_stone_bricks";
  MinecraftBlockTypes2["IronBars"] = "minecraft:iron_bars";
  MinecraftBlockTypes2["IronBlock"] = "minecraft:iron_block";
  MinecraftBlockTypes2["IronChain"] = "minecraft:iron_chain";
  MinecraftBlockTypes2["IronDoor"] = "minecraft:iron_door";
  MinecraftBlockTypes2["IronOre"] = "minecraft:iron_ore";
  MinecraftBlockTypes2["IronTrapdoor"] = "minecraft:iron_trapdoor";
  MinecraftBlockTypes2["Jigsaw"] = "minecraft:jigsaw";
  MinecraftBlockTypes2["Jukebox"] = "minecraft:jukebox";
  MinecraftBlockTypes2["JungleButton"] = "minecraft:jungle_button";
  MinecraftBlockTypes2["JungleDoor"] = "minecraft:jungle_door";
  MinecraftBlockTypes2["JungleDoubleSlab"] = "minecraft:jungle_double_slab";
  MinecraftBlockTypes2["JungleFence"] = "minecraft:jungle_fence";
  MinecraftBlockTypes2["JungleFenceGate"] = "minecraft:jungle_fence_gate";
  MinecraftBlockTypes2["JungleHangingSign"] = "minecraft:jungle_hanging_sign";
  MinecraftBlockTypes2["JungleLeaves"] = "minecraft:jungle_leaves";
  MinecraftBlockTypes2["JungleLog"] = "minecraft:jungle_log";
  MinecraftBlockTypes2["JunglePlanks"] = "minecraft:jungle_planks";
  MinecraftBlockTypes2["JunglePressurePlate"] = "minecraft:jungle_pressure_plate";
  MinecraftBlockTypes2["JungleSapling"] = "minecraft:jungle_sapling";
  MinecraftBlockTypes2["JungleShelf"] = "minecraft:jungle_shelf";
  MinecraftBlockTypes2["JungleSlab"] = "minecraft:jungle_slab";
  MinecraftBlockTypes2["JungleStairs"] = "minecraft:jungle_stairs";
  MinecraftBlockTypes2["JungleStandingSign"] = "minecraft:jungle_standing_sign";
  MinecraftBlockTypes2["JungleTrapdoor"] = "minecraft:jungle_trapdoor";
  MinecraftBlockTypes2["JungleWallSign"] = "minecraft:jungle_wall_sign";
  MinecraftBlockTypes2["JungleWood"] = "minecraft:jungle_wood";
  MinecraftBlockTypes2["Kelp"] = "minecraft:kelp";
  MinecraftBlockTypes2["LabTable"] = "minecraft:lab_table";
  MinecraftBlockTypes2["Ladder"] = "minecraft:ladder";
  MinecraftBlockTypes2["Lantern"] = "minecraft:lantern";
  MinecraftBlockTypes2["LapisBlock"] = "minecraft:lapis_block";
  MinecraftBlockTypes2["LapisOre"] = "minecraft:lapis_ore";
  MinecraftBlockTypes2["LargeAmethystBud"] = "minecraft:large_amethyst_bud";
  MinecraftBlockTypes2["LargeFern"] = "minecraft:large_fern";
  MinecraftBlockTypes2["Lava"] = "minecraft:lava";
  MinecraftBlockTypes2["LeafLitter"] = "minecraft:leaf_litter";
  MinecraftBlockTypes2["Lectern"] = "minecraft:lectern";
  MinecraftBlockTypes2["Lever"] = "minecraft:lever";
  MinecraftBlockTypes2["LightBlock0"] = "minecraft:light_block_0";
  MinecraftBlockTypes2["LightBlock1"] = "minecraft:light_block_1";
  MinecraftBlockTypes2["LightBlock10"] = "minecraft:light_block_10";
  MinecraftBlockTypes2["LightBlock11"] = "minecraft:light_block_11";
  MinecraftBlockTypes2["LightBlock12"] = "minecraft:light_block_12";
  MinecraftBlockTypes2["LightBlock13"] = "minecraft:light_block_13";
  MinecraftBlockTypes2["LightBlock14"] = "minecraft:light_block_14";
  MinecraftBlockTypes2["LightBlock15"] = "minecraft:light_block_15";
  MinecraftBlockTypes2["LightBlock2"] = "minecraft:light_block_2";
  MinecraftBlockTypes2["LightBlock3"] = "minecraft:light_block_3";
  MinecraftBlockTypes2["LightBlock4"] = "minecraft:light_block_4";
  MinecraftBlockTypes2["LightBlock5"] = "minecraft:light_block_5";
  MinecraftBlockTypes2["LightBlock6"] = "minecraft:light_block_6";
  MinecraftBlockTypes2["LightBlock7"] = "minecraft:light_block_7";
  MinecraftBlockTypes2["LightBlock8"] = "minecraft:light_block_8";
  MinecraftBlockTypes2["LightBlock9"] = "minecraft:light_block_9";
  MinecraftBlockTypes2["LightBlueCandle"] = "minecraft:light_blue_candle";
  MinecraftBlockTypes2["LightBlueCandleCake"] = "minecraft:light_blue_candle_cake";
  MinecraftBlockTypes2["LightBlueCarpet"] = "minecraft:light_blue_carpet";
  MinecraftBlockTypes2["LightBlueConcrete"] = "minecraft:light_blue_concrete";
  MinecraftBlockTypes2["LightBlueConcretePowder"] = "minecraft:light_blue_concrete_powder";
  MinecraftBlockTypes2["LightBlueGlazedTerracotta"] = "minecraft:light_blue_glazed_terracotta";
  MinecraftBlockTypes2["LightBlueShulkerBox"] = "minecraft:light_blue_shulker_box";
  MinecraftBlockTypes2["LightBlueStainedGlass"] = "minecraft:light_blue_stained_glass";
  MinecraftBlockTypes2["LightBlueStainedGlassPane"] = "minecraft:light_blue_stained_glass_pane";
  MinecraftBlockTypes2["LightBlueTerracotta"] = "minecraft:light_blue_terracotta";
  MinecraftBlockTypes2["LightBlueWool"] = "minecraft:light_blue_wool";
  MinecraftBlockTypes2["LightGrayCandle"] = "minecraft:light_gray_candle";
  MinecraftBlockTypes2["LightGrayCandleCake"] = "minecraft:light_gray_candle_cake";
  MinecraftBlockTypes2["LightGrayCarpet"] = "minecraft:light_gray_carpet";
  MinecraftBlockTypes2["LightGrayConcrete"] = "minecraft:light_gray_concrete";
  MinecraftBlockTypes2["LightGrayConcretePowder"] = "minecraft:light_gray_concrete_powder";
  MinecraftBlockTypes2["LightGrayShulkerBox"] = "minecraft:light_gray_shulker_box";
  MinecraftBlockTypes2["LightGrayStainedGlass"] = "minecraft:light_gray_stained_glass";
  MinecraftBlockTypes2["LightGrayStainedGlassPane"] = "minecraft:light_gray_stained_glass_pane";
  MinecraftBlockTypes2["LightGrayTerracotta"] = "minecraft:light_gray_terracotta";
  MinecraftBlockTypes2["LightGrayWool"] = "minecraft:light_gray_wool";
  MinecraftBlockTypes2["LightWeightedPressurePlate"] = "minecraft:light_weighted_pressure_plate";
  MinecraftBlockTypes2["LightningRod"] = "minecraft:lightning_rod";
  MinecraftBlockTypes2["Lilac"] = "minecraft:lilac";
  MinecraftBlockTypes2["LilyOfTheValley"] = "minecraft:lily_of_the_valley";
  MinecraftBlockTypes2["LimeCandle"] = "minecraft:lime_candle";
  MinecraftBlockTypes2["LimeCandleCake"] = "minecraft:lime_candle_cake";
  MinecraftBlockTypes2["LimeCarpet"] = "minecraft:lime_carpet";
  MinecraftBlockTypes2["LimeConcrete"] = "minecraft:lime_concrete";
  MinecraftBlockTypes2["LimeConcretePowder"] = "minecraft:lime_concrete_powder";
  MinecraftBlockTypes2["LimeGlazedTerracotta"] = "minecraft:lime_glazed_terracotta";
  MinecraftBlockTypes2["LimeShulkerBox"] = "minecraft:lime_shulker_box";
  MinecraftBlockTypes2["LimeStainedGlass"] = "minecraft:lime_stained_glass";
  MinecraftBlockTypes2["LimeStainedGlassPane"] = "minecraft:lime_stained_glass_pane";
  MinecraftBlockTypes2["LimeTerracotta"] = "minecraft:lime_terracotta";
  MinecraftBlockTypes2["LimeWool"] = "minecraft:lime_wool";
  MinecraftBlockTypes2["LitBlastFurnace"] = "minecraft:lit_blast_furnace";
  MinecraftBlockTypes2["LitDeepslateRedstoneOre"] = "minecraft:lit_deepslate_redstone_ore";
  MinecraftBlockTypes2["LitFurnace"] = "minecraft:lit_furnace";
  MinecraftBlockTypes2["LitPumpkin"] = "minecraft:lit_pumpkin";
  MinecraftBlockTypes2["LitRedstoneLamp"] = "minecraft:lit_redstone_lamp";
  MinecraftBlockTypes2["LitRedstoneOre"] = "minecraft:lit_redstone_ore";
  MinecraftBlockTypes2["LitSmoker"] = "minecraft:lit_smoker";
  MinecraftBlockTypes2["Lodestone"] = "minecraft:lodestone";
  MinecraftBlockTypes2["Loom"] = "minecraft:loom";
  MinecraftBlockTypes2["MagentaCandle"] = "minecraft:magenta_candle";
  MinecraftBlockTypes2["MagentaCandleCake"] = "minecraft:magenta_candle_cake";
  MinecraftBlockTypes2["MagentaCarpet"] = "minecraft:magenta_carpet";
  MinecraftBlockTypes2["MagentaConcrete"] = "minecraft:magenta_concrete";
  MinecraftBlockTypes2["MagentaConcretePowder"] = "minecraft:magenta_concrete_powder";
  MinecraftBlockTypes2["MagentaGlazedTerracotta"] = "minecraft:magenta_glazed_terracotta";
  MinecraftBlockTypes2["MagentaShulkerBox"] = "minecraft:magenta_shulker_box";
  MinecraftBlockTypes2["MagentaStainedGlass"] = "minecraft:magenta_stained_glass";
  MinecraftBlockTypes2["MagentaStainedGlassPane"] = "minecraft:magenta_stained_glass_pane";
  MinecraftBlockTypes2["MagentaTerracotta"] = "minecraft:magenta_terracotta";
  MinecraftBlockTypes2["MagentaWool"] = "minecraft:magenta_wool";
  MinecraftBlockTypes2["Magma"] = "minecraft:magma";
  MinecraftBlockTypes2["MangroveButton"] = "minecraft:mangrove_button";
  MinecraftBlockTypes2["MangroveDoor"] = "minecraft:mangrove_door";
  MinecraftBlockTypes2["MangroveDoubleSlab"] = "minecraft:mangrove_double_slab";
  MinecraftBlockTypes2["MangroveFence"] = "minecraft:mangrove_fence";
  MinecraftBlockTypes2["MangroveFenceGate"] = "minecraft:mangrove_fence_gate";
  MinecraftBlockTypes2["MangroveHangingSign"] = "minecraft:mangrove_hanging_sign";
  MinecraftBlockTypes2["MangroveLeaves"] = "minecraft:mangrove_leaves";
  MinecraftBlockTypes2["MangroveLog"] = "minecraft:mangrove_log";
  MinecraftBlockTypes2["MangrovePlanks"] = "minecraft:mangrove_planks";
  MinecraftBlockTypes2["MangrovePressurePlate"] = "minecraft:mangrove_pressure_plate";
  MinecraftBlockTypes2["MangrovePropagule"] = "minecraft:mangrove_propagule";
  MinecraftBlockTypes2["MangroveRoots"] = "minecraft:mangrove_roots";
  MinecraftBlockTypes2["MangroveShelf"] = "minecraft:mangrove_shelf";
  MinecraftBlockTypes2["MangroveSlab"] = "minecraft:mangrove_slab";
  MinecraftBlockTypes2["MangroveStairs"] = "minecraft:mangrove_stairs";
  MinecraftBlockTypes2["MangroveStandingSign"] = "minecraft:mangrove_standing_sign";
  MinecraftBlockTypes2["MangroveTrapdoor"] = "minecraft:mangrove_trapdoor";
  MinecraftBlockTypes2["MangroveWallSign"] = "minecraft:mangrove_wall_sign";
  MinecraftBlockTypes2["MangroveWood"] = "minecraft:mangrove_wood";
  MinecraftBlockTypes2["MaterialReducer"] = "minecraft:material_reducer";
  MinecraftBlockTypes2["MediumAmethystBud"] = "minecraft:medium_amethyst_bud";
  MinecraftBlockTypes2["MelonBlock"] = "minecraft:melon_block";
  MinecraftBlockTypes2["MelonStem"] = "minecraft:melon_stem";
  MinecraftBlockTypes2["MobSpawner"] = "minecraft:mob_spawner";
  MinecraftBlockTypes2["MossBlock"] = "minecraft:moss_block";
  MinecraftBlockTypes2["MossCarpet"] = "minecraft:moss_carpet";
  MinecraftBlockTypes2["MossyCobblestone"] = "minecraft:mossy_cobblestone";
  MinecraftBlockTypes2["MossyCobblestoneDoubleSlab"] = "minecraft:mossy_cobblestone_double_slab";
  MinecraftBlockTypes2["MossyCobblestoneSlab"] = "minecraft:mossy_cobblestone_slab";
  MinecraftBlockTypes2["MossyCobblestoneStairs"] = "minecraft:mossy_cobblestone_stairs";
  MinecraftBlockTypes2["MossyCobblestoneWall"] = "minecraft:mossy_cobblestone_wall";
  MinecraftBlockTypes2["MossyStoneBrickDoubleSlab"] = "minecraft:mossy_stone_brick_double_slab";
  MinecraftBlockTypes2["MossyStoneBrickSlab"] = "minecraft:mossy_stone_brick_slab";
  MinecraftBlockTypes2["MossyStoneBrickStairs"] = "minecraft:mossy_stone_brick_stairs";
  MinecraftBlockTypes2["MossyStoneBrickWall"] = "minecraft:mossy_stone_brick_wall";
  MinecraftBlockTypes2["MossyStoneBricks"] = "minecraft:mossy_stone_bricks";
  MinecraftBlockTypes2["Mud"] = "minecraft:mud";
  MinecraftBlockTypes2["MudBrickDoubleSlab"] = "minecraft:mud_brick_double_slab";
  MinecraftBlockTypes2["MudBrickSlab"] = "minecraft:mud_brick_slab";
  MinecraftBlockTypes2["MudBrickStairs"] = "minecraft:mud_brick_stairs";
  MinecraftBlockTypes2["MudBrickWall"] = "minecraft:mud_brick_wall";
  MinecraftBlockTypes2["MudBricks"] = "minecraft:mud_bricks";
  MinecraftBlockTypes2["MuddyMangroveRoots"] = "minecraft:muddy_mangrove_roots";
  MinecraftBlockTypes2["MushroomStem"] = "minecraft:mushroom_stem";
  MinecraftBlockTypes2["Mycelium"] = "minecraft:mycelium";
  MinecraftBlockTypes2["NetherBrick"] = "minecraft:nether_brick";
  MinecraftBlockTypes2["NetherBrickDoubleSlab"] = "minecraft:nether_brick_double_slab";
  MinecraftBlockTypes2["NetherBrickFence"] = "minecraft:nether_brick_fence";
  MinecraftBlockTypes2["NetherBrickSlab"] = "minecraft:nether_brick_slab";
  MinecraftBlockTypes2["NetherBrickStairs"] = "minecraft:nether_brick_stairs";
  MinecraftBlockTypes2["NetherBrickWall"] = "minecraft:nether_brick_wall";
  MinecraftBlockTypes2["NetherGoldOre"] = "minecraft:nether_gold_ore";
  MinecraftBlockTypes2["NetherSprouts"] = "minecraft:nether_sprouts";
  MinecraftBlockTypes2["NetherWart"] = "minecraft:nether_wart";
  MinecraftBlockTypes2["NetherWartBlock"] = "minecraft:nether_wart_block";
  MinecraftBlockTypes2["NetheriteBlock"] = "minecraft:netherite_block";
  MinecraftBlockTypes2["Netherrack"] = "minecraft:netherrack";
  MinecraftBlockTypes2["NormalStoneDoubleSlab"] = "minecraft:normal_stone_double_slab";
  MinecraftBlockTypes2["NormalStoneSlab"] = "minecraft:normal_stone_slab";
  MinecraftBlockTypes2["NormalStoneStairs"] = "minecraft:normal_stone_stairs";
  MinecraftBlockTypes2["Noteblock"] = "minecraft:noteblock";
  MinecraftBlockTypes2["OakDoubleSlab"] = "minecraft:oak_double_slab";
  MinecraftBlockTypes2["OakFence"] = "minecraft:oak_fence";
  MinecraftBlockTypes2["OakHangingSign"] = "minecraft:oak_hanging_sign";
  MinecraftBlockTypes2["OakLeaves"] = "minecraft:oak_leaves";
  MinecraftBlockTypes2["OakLog"] = "minecraft:oak_log";
  MinecraftBlockTypes2["OakPlanks"] = "minecraft:oak_planks";
  MinecraftBlockTypes2["OakSapling"] = "minecraft:oak_sapling";
  MinecraftBlockTypes2["OakShelf"] = "minecraft:oak_shelf";
  MinecraftBlockTypes2["OakSlab"] = "minecraft:oak_slab";
  MinecraftBlockTypes2["OakStairs"] = "minecraft:oak_stairs";
  MinecraftBlockTypes2["OakWood"] = "minecraft:oak_wood";
  MinecraftBlockTypes2["Observer"] = "minecraft:observer";
  MinecraftBlockTypes2["Obsidian"] = "minecraft:obsidian";
  MinecraftBlockTypes2["OchreFroglight"] = "minecraft:ochre_froglight";
  MinecraftBlockTypes2["OpenEyeblossom"] = "minecraft:open_eyeblossom";
  MinecraftBlockTypes2["OrangeCandle"] = "minecraft:orange_candle";
  MinecraftBlockTypes2["OrangeCandleCake"] = "minecraft:orange_candle_cake";
  MinecraftBlockTypes2["OrangeCarpet"] = "minecraft:orange_carpet";
  MinecraftBlockTypes2["OrangeConcrete"] = "minecraft:orange_concrete";
  MinecraftBlockTypes2["OrangeConcretePowder"] = "minecraft:orange_concrete_powder";
  MinecraftBlockTypes2["OrangeGlazedTerracotta"] = "minecraft:orange_glazed_terracotta";
  MinecraftBlockTypes2["OrangeShulkerBox"] = "minecraft:orange_shulker_box";
  MinecraftBlockTypes2["OrangeStainedGlass"] = "minecraft:orange_stained_glass";
  MinecraftBlockTypes2["OrangeStainedGlassPane"] = "minecraft:orange_stained_glass_pane";
  MinecraftBlockTypes2["OrangeTerracotta"] = "minecraft:orange_terracotta";
  MinecraftBlockTypes2["OrangeTulip"] = "minecraft:orange_tulip";
  MinecraftBlockTypes2["OrangeWool"] = "minecraft:orange_wool";
  MinecraftBlockTypes2["OxeyeDaisy"] = "minecraft:oxeye_daisy";
  MinecraftBlockTypes2["OxidizedChiseledCopper"] = "minecraft:oxidized_chiseled_copper";
  MinecraftBlockTypes2["OxidizedCopper"] = "minecraft:oxidized_copper";
  MinecraftBlockTypes2["OxidizedCopperBars"] = "minecraft:oxidized_copper_bars";
  MinecraftBlockTypes2["OxidizedCopperBulb"] = "minecraft:oxidized_copper_bulb";
  MinecraftBlockTypes2["OxidizedCopperChain"] = "minecraft:oxidized_copper_chain";
  MinecraftBlockTypes2["OxidizedCopperChest"] = "minecraft:oxidized_copper_chest";
  MinecraftBlockTypes2["OxidizedCopperDoor"] = "minecraft:oxidized_copper_door";
  MinecraftBlockTypes2["OxidizedCopperGolemStatue"] = "minecraft:oxidized_copper_golem_statue";
  MinecraftBlockTypes2["OxidizedCopperGrate"] = "minecraft:oxidized_copper_grate";
  MinecraftBlockTypes2["OxidizedCopperLantern"] = "minecraft:oxidized_copper_lantern";
  MinecraftBlockTypes2["OxidizedCopperTrapdoor"] = "minecraft:oxidized_copper_trapdoor";
  MinecraftBlockTypes2["OxidizedCutCopper"] = "minecraft:oxidized_cut_copper";
  MinecraftBlockTypes2["OxidizedCutCopperSlab"] = "minecraft:oxidized_cut_copper_slab";
  MinecraftBlockTypes2["OxidizedCutCopperStairs"] = "minecraft:oxidized_cut_copper_stairs";
  MinecraftBlockTypes2["OxidizedDoubleCutCopperSlab"] = "minecraft:oxidized_double_cut_copper_slab";
  MinecraftBlockTypes2["OxidizedLightningRod"] = "minecraft:oxidized_lightning_rod";
  MinecraftBlockTypes2["PackedIce"] = "minecraft:packed_ice";
  MinecraftBlockTypes2["PackedMud"] = "minecraft:packed_mud";
  MinecraftBlockTypes2["PaleHangingMoss"] = "minecraft:pale_hanging_moss";
  MinecraftBlockTypes2["PaleMossBlock"] = "minecraft:pale_moss_block";
  MinecraftBlockTypes2["PaleMossCarpet"] = "minecraft:pale_moss_carpet";
  MinecraftBlockTypes2["PaleOakButton"] = "minecraft:pale_oak_button";
  MinecraftBlockTypes2["PaleOakDoor"] = "minecraft:pale_oak_door";
  MinecraftBlockTypes2["PaleOakDoubleSlab"] = "minecraft:pale_oak_double_slab";
  MinecraftBlockTypes2["PaleOakFence"] = "minecraft:pale_oak_fence";
  MinecraftBlockTypes2["PaleOakFenceGate"] = "minecraft:pale_oak_fence_gate";
  MinecraftBlockTypes2["PaleOakHangingSign"] = "minecraft:pale_oak_hanging_sign";
  MinecraftBlockTypes2["PaleOakLeaves"] = "minecraft:pale_oak_leaves";
  MinecraftBlockTypes2["PaleOakLog"] = "minecraft:pale_oak_log";
  MinecraftBlockTypes2["PaleOakPlanks"] = "minecraft:pale_oak_planks";
  MinecraftBlockTypes2["PaleOakPressurePlate"] = "minecraft:pale_oak_pressure_plate";
  MinecraftBlockTypes2["PaleOakSapling"] = "minecraft:pale_oak_sapling";
  MinecraftBlockTypes2["PaleOakShelf"] = "minecraft:pale_oak_shelf";
  MinecraftBlockTypes2["PaleOakSlab"] = "minecraft:pale_oak_slab";
  MinecraftBlockTypes2["PaleOakStairs"] = "minecraft:pale_oak_stairs";
  MinecraftBlockTypes2["PaleOakStandingSign"] = "minecraft:pale_oak_standing_sign";
  MinecraftBlockTypes2["PaleOakTrapdoor"] = "minecraft:pale_oak_trapdoor";
  MinecraftBlockTypes2["PaleOakWallSign"] = "minecraft:pale_oak_wall_sign";
  MinecraftBlockTypes2["PaleOakWood"] = "minecraft:pale_oak_wood";
  MinecraftBlockTypes2["PearlescentFroglight"] = "minecraft:pearlescent_froglight";
  MinecraftBlockTypes2["Peony"] = "minecraft:peony";
  MinecraftBlockTypes2["PetrifiedOakDoubleSlab"] = "minecraft:petrified_oak_double_slab";
  MinecraftBlockTypes2["PetrifiedOakSlab"] = "minecraft:petrified_oak_slab";
  MinecraftBlockTypes2["PiglinHead"] = "minecraft:piglin_head";
  MinecraftBlockTypes2["PinkCandle"] = "minecraft:pink_candle";
  MinecraftBlockTypes2["PinkCandleCake"] = "minecraft:pink_candle_cake";
  MinecraftBlockTypes2["PinkCarpet"] = "minecraft:pink_carpet";
  MinecraftBlockTypes2["PinkConcrete"] = "minecraft:pink_concrete";
  MinecraftBlockTypes2["PinkConcretePowder"] = "minecraft:pink_concrete_powder";
  MinecraftBlockTypes2["PinkGlazedTerracotta"] = "minecraft:pink_glazed_terracotta";
  MinecraftBlockTypes2["PinkPetals"] = "minecraft:pink_petals";
  MinecraftBlockTypes2["PinkShulkerBox"] = "minecraft:pink_shulker_box";
  MinecraftBlockTypes2["PinkStainedGlass"] = "minecraft:pink_stained_glass";
  MinecraftBlockTypes2["PinkStainedGlassPane"] = "minecraft:pink_stained_glass_pane";
  MinecraftBlockTypes2["PinkTerracotta"] = "minecraft:pink_terracotta";
  MinecraftBlockTypes2["PinkTulip"] = "minecraft:pink_tulip";
  MinecraftBlockTypes2["PinkWool"] = "minecraft:pink_wool";
  MinecraftBlockTypes2["Piston"] = "minecraft:piston";
  MinecraftBlockTypes2["PistonArmCollision"] = "minecraft:piston_arm_collision";
  MinecraftBlockTypes2["PitcherCrop"] = "minecraft:pitcher_crop";
  MinecraftBlockTypes2["PitcherPlant"] = "minecraft:pitcher_plant";
  MinecraftBlockTypes2["PlayerHead"] = "minecraft:player_head";
  MinecraftBlockTypes2["Podzol"] = "minecraft:podzol";
  MinecraftBlockTypes2["PointedDripstone"] = "minecraft:pointed_dripstone";
  MinecraftBlockTypes2["PolishedAndesite"] = "minecraft:polished_andesite";
  MinecraftBlockTypes2["PolishedAndesiteDoubleSlab"] = "minecraft:polished_andesite_double_slab";
  MinecraftBlockTypes2["PolishedAndesiteSlab"] = "minecraft:polished_andesite_slab";
  MinecraftBlockTypes2["PolishedAndesiteStairs"] = "minecraft:polished_andesite_stairs";
  MinecraftBlockTypes2["PolishedBasalt"] = "minecraft:polished_basalt";
  MinecraftBlockTypes2["PolishedBlackstone"] = "minecraft:polished_blackstone";
  MinecraftBlockTypes2["PolishedBlackstoneBrickDoubleSlab"] = "minecraft:polished_blackstone_brick_double_slab";
  MinecraftBlockTypes2["PolishedBlackstoneBrickSlab"] = "minecraft:polished_blackstone_brick_slab";
  MinecraftBlockTypes2["PolishedBlackstoneBrickStairs"] = "minecraft:polished_blackstone_brick_stairs";
  MinecraftBlockTypes2["PolishedBlackstoneBrickWall"] = "minecraft:polished_blackstone_brick_wall";
  MinecraftBlockTypes2["PolishedBlackstoneBricks"] = "minecraft:polished_blackstone_bricks";
  MinecraftBlockTypes2["PolishedBlackstoneButton"] = "minecraft:polished_blackstone_button";
  MinecraftBlockTypes2["PolishedBlackstoneDoubleSlab"] = "minecraft:polished_blackstone_double_slab";
  MinecraftBlockTypes2["PolishedBlackstonePressurePlate"] = "minecraft:polished_blackstone_pressure_plate";
  MinecraftBlockTypes2["PolishedBlackstoneSlab"] = "minecraft:polished_blackstone_slab";
  MinecraftBlockTypes2["PolishedBlackstoneStairs"] = "minecraft:polished_blackstone_stairs";
  MinecraftBlockTypes2["PolishedBlackstoneWall"] = "minecraft:polished_blackstone_wall";
  MinecraftBlockTypes2["PolishedCinnabar"] = "minecraft:polished_cinnabar";
  MinecraftBlockTypes2["PolishedCinnabarDoubleSlab"] = "minecraft:polished_cinnabar_double_slab";
  MinecraftBlockTypes2["PolishedCinnabarSlab"] = "minecraft:polished_cinnabar_slab";
  MinecraftBlockTypes2["PolishedCinnabarStairs"] = "minecraft:polished_cinnabar_stairs";
  MinecraftBlockTypes2["PolishedCinnabarWall"] = "minecraft:polished_cinnabar_wall";
  MinecraftBlockTypes2["PolishedDeepslate"] = "minecraft:polished_deepslate";
  MinecraftBlockTypes2["PolishedDeepslateDoubleSlab"] = "minecraft:polished_deepslate_double_slab";
  MinecraftBlockTypes2["PolishedDeepslateSlab"] = "minecraft:polished_deepslate_slab";
  MinecraftBlockTypes2["PolishedDeepslateStairs"] = "minecraft:polished_deepslate_stairs";
  MinecraftBlockTypes2["PolishedDeepslateWall"] = "minecraft:polished_deepslate_wall";
  MinecraftBlockTypes2["PolishedDiorite"] = "minecraft:polished_diorite";
  MinecraftBlockTypes2["PolishedDioriteDoubleSlab"] = "minecraft:polished_diorite_double_slab";
  MinecraftBlockTypes2["PolishedDioriteSlab"] = "minecraft:polished_diorite_slab";
  MinecraftBlockTypes2["PolishedDioriteStairs"] = "minecraft:polished_diorite_stairs";
  MinecraftBlockTypes2["PolishedGranite"] = "minecraft:polished_granite";
  MinecraftBlockTypes2["PolishedGraniteDoubleSlab"] = "minecraft:polished_granite_double_slab";
  MinecraftBlockTypes2["PolishedGraniteSlab"] = "minecraft:polished_granite_slab";
  MinecraftBlockTypes2["PolishedGraniteStairs"] = "minecraft:polished_granite_stairs";
  MinecraftBlockTypes2["PolishedSulfur"] = "minecraft:polished_sulfur";
  MinecraftBlockTypes2["PolishedSulfurDoubleSlab"] = "minecraft:polished_sulfur_double_slab";
  MinecraftBlockTypes2["PolishedSulfurSlab"] = "minecraft:polished_sulfur_slab";
  MinecraftBlockTypes2["PolishedSulfurStairs"] = "minecraft:polished_sulfur_stairs";
  MinecraftBlockTypes2["PolishedSulfurWall"] = "minecraft:polished_sulfur_wall";
  MinecraftBlockTypes2["PolishedTuff"] = "minecraft:polished_tuff";
  MinecraftBlockTypes2["PolishedTuffDoubleSlab"] = "minecraft:polished_tuff_double_slab";
  MinecraftBlockTypes2["PolishedTuffSlab"] = "minecraft:polished_tuff_slab";
  MinecraftBlockTypes2["PolishedTuffStairs"] = "minecraft:polished_tuff_stairs";
  MinecraftBlockTypes2["PolishedTuffWall"] = "minecraft:polished_tuff_wall";
  MinecraftBlockTypes2["Poppy"] = "minecraft:poppy";
  MinecraftBlockTypes2["Portal"] = "minecraft:portal";
  MinecraftBlockTypes2["Potatoes"] = "minecraft:potatoes";
  MinecraftBlockTypes2["PotentSulfur"] = "minecraft:potent_sulfur";
  MinecraftBlockTypes2["PowderSnow"] = "minecraft:powder_snow";
  MinecraftBlockTypes2["PoweredComparator"] = "minecraft:powered_comparator";
  MinecraftBlockTypes2["PoweredRepeater"] = "minecraft:powered_repeater";
  MinecraftBlockTypes2["Prismarine"] = "minecraft:prismarine";
  MinecraftBlockTypes2["PrismarineBrickDoubleSlab"] = "minecraft:prismarine_brick_double_slab";
  MinecraftBlockTypes2["PrismarineBrickSlab"] = "minecraft:prismarine_brick_slab";
  MinecraftBlockTypes2["PrismarineBricks"] = "minecraft:prismarine_bricks";
  MinecraftBlockTypes2["PrismarineBricksStairs"] = "minecraft:prismarine_bricks_stairs";
  MinecraftBlockTypes2["PrismarineDoubleSlab"] = "minecraft:prismarine_double_slab";
  MinecraftBlockTypes2["PrismarineSlab"] = "minecraft:prismarine_slab";
  MinecraftBlockTypes2["PrismarineStairs"] = "minecraft:prismarine_stairs";
  MinecraftBlockTypes2["PrismarineWall"] = "minecraft:prismarine_wall";
  MinecraftBlockTypes2["Pumpkin"] = "minecraft:pumpkin";
  MinecraftBlockTypes2["PumpkinStem"] = "minecraft:pumpkin_stem";
  MinecraftBlockTypes2["PurpleCandle"] = "minecraft:purple_candle";
  MinecraftBlockTypes2["PurpleCandleCake"] = "minecraft:purple_candle_cake";
  MinecraftBlockTypes2["PurpleCarpet"] = "minecraft:purple_carpet";
  MinecraftBlockTypes2["PurpleConcrete"] = "minecraft:purple_concrete";
  MinecraftBlockTypes2["PurpleConcretePowder"] = "minecraft:purple_concrete_powder";
  MinecraftBlockTypes2["PurpleGlazedTerracotta"] = "minecraft:purple_glazed_terracotta";
  MinecraftBlockTypes2["PurpleShulkerBox"] = "minecraft:purple_shulker_box";
  MinecraftBlockTypes2["PurpleStainedGlass"] = "minecraft:purple_stained_glass";
  MinecraftBlockTypes2["PurpleStainedGlassPane"] = "minecraft:purple_stained_glass_pane";
  MinecraftBlockTypes2["PurpleTerracotta"] = "minecraft:purple_terracotta";
  MinecraftBlockTypes2["PurpleWool"] = "minecraft:purple_wool";
  MinecraftBlockTypes2["PurpurBlock"] = "minecraft:purpur_block";
  MinecraftBlockTypes2["PurpurDoubleSlab"] = "minecraft:purpur_double_slab";
  MinecraftBlockTypes2["PurpurPillar"] = "minecraft:purpur_pillar";
  MinecraftBlockTypes2["PurpurSlab"] = "minecraft:purpur_slab";
  MinecraftBlockTypes2["PurpurStairs"] = "minecraft:purpur_stairs";
  MinecraftBlockTypes2["QuartzBlock"] = "minecraft:quartz_block";
  MinecraftBlockTypes2["QuartzBricks"] = "minecraft:quartz_bricks";
  MinecraftBlockTypes2["QuartzDoubleSlab"] = "minecraft:quartz_double_slab";
  MinecraftBlockTypes2["QuartzOre"] = "minecraft:quartz_ore";
  MinecraftBlockTypes2["QuartzPillar"] = "minecraft:quartz_pillar";
  MinecraftBlockTypes2["QuartzSlab"] = "minecraft:quartz_slab";
  MinecraftBlockTypes2["QuartzStairs"] = "minecraft:quartz_stairs";
  MinecraftBlockTypes2["Rail"] = "minecraft:rail";
  MinecraftBlockTypes2["RawCopperBlock"] = "minecraft:raw_copper_block";
  MinecraftBlockTypes2["RawGoldBlock"] = "minecraft:raw_gold_block";
  MinecraftBlockTypes2["RawIronBlock"] = "minecraft:raw_iron_block";
  MinecraftBlockTypes2["RedCandle"] = "minecraft:red_candle";
  MinecraftBlockTypes2["RedCandleCake"] = "minecraft:red_candle_cake";
  MinecraftBlockTypes2["RedCarpet"] = "minecraft:red_carpet";
  MinecraftBlockTypes2["RedConcrete"] = "minecraft:red_concrete";
  MinecraftBlockTypes2["RedConcretePowder"] = "minecraft:red_concrete_powder";
  MinecraftBlockTypes2["RedGlazedTerracotta"] = "minecraft:red_glazed_terracotta";
  MinecraftBlockTypes2["RedMushroom"] = "minecraft:red_mushroom";
  MinecraftBlockTypes2["RedMushroomBlock"] = "minecraft:red_mushroom_block";
  MinecraftBlockTypes2["RedNetherBrick"] = "minecraft:red_nether_brick";
  MinecraftBlockTypes2["RedNetherBrickDoubleSlab"] = "minecraft:red_nether_brick_double_slab";
  MinecraftBlockTypes2["RedNetherBrickSlab"] = "minecraft:red_nether_brick_slab";
  MinecraftBlockTypes2["RedNetherBrickStairs"] = "minecraft:red_nether_brick_stairs";
  MinecraftBlockTypes2["RedNetherBrickWall"] = "minecraft:red_nether_brick_wall";
  MinecraftBlockTypes2["RedSand"] = "minecraft:red_sand";
  MinecraftBlockTypes2["RedSandstone"] = "minecraft:red_sandstone";
  MinecraftBlockTypes2["RedSandstoneDoubleSlab"] = "minecraft:red_sandstone_double_slab";
  MinecraftBlockTypes2["RedSandstoneSlab"] = "minecraft:red_sandstone_slab";
  MinecraftBlockTypes2["RedSandstoneStairs"] = "minecraft:red_sandstone_stairs";
  MinecraftBlockTypes2["RedSandstoneWall"] = "minecraft:red_sandstone_wall";
  MinecraftBlockTypes2["RedShulkerBox"] = "minecraft:red_shulker_box";
  MinecraftBlockTypes2["RedStainedGlass"] = "minecraft:red_stained_glass";
  MinecraftBlockTypes2["RedStainedGlassPane"] = "minecraft:red_stained_glass_pane";
  MinecraftBlockTypes2["RedTerracotta"] = "minecraft:red_terracotta";
  MinecraftBlockTypes2["RedTulip"] = "minecraft:red_tulip";
  MinecraftBlockTypes2["RedWool"] = "minecraft:red_wool";
  MinecraftBlockTypes2["RedstoneBlock"] = "minecraft:redstone_block";
  MinecraftBlockTypes2["RedstoneLamp"] = "minecraft:redstone_lamp";
  MinecraftBlockTypes2["RedstoneOre"] = "minecraft:redstone_ore";
  MinecraftBlockTypes2["RedstoneTorch"] = "minecraft:redstone_torch";
  MinecraftBlockTypes2["RedstoneWire"] = "minecraft:redstone_wire";
  MinecraftBlockTypes2["Reeds"] = "minecraft:reeds";
  MinecraftBlockTypes2["ReinforcedDeepslate"] = "minecraft:reinforced_deepslate";
  MinecraftBlockTypes2["RepeatingCommandBlock"] = "minecraft:repeating_command_block";
  MinecraftBlockTypes2["ResinBlock"] = "minecraft:resin_block";
  MinecraftBlockTypes2["ResinBrickDoubleSlab"] = "minecraft:resin_brick_double_slab";
  MinecraftBlockTypes2["ResinBrickSlab"] = "minecraft:resin_brick_slab";
  MinecraftBlockTypes2["ResinBrickStairs"] = "minecraft:resin_brick_stairs";
  MinecraftBlockTypes2["ResinBrickWall"] = "minecraft:resin_brick_wall";
  MinecraftBlockTypes2["ResinBricks"] = "minecraft:resin_bricks";
  MinecraftBlockTypes2["ResinClump"] = "minecraft:resin_clump";
  MinecraftBlockTypes2["RespawnAnchor"] = "minecraft:respawn_anchor";
  MinecraftBlockTypes2["RoseBush"] = "minecraft:rose_bush";
  MinecraftBlockTypes2["Sand"] = "minecraft:sand";
  MinecraftBlockTypes2["Sandstone"] = "minecraft:sandstone";
  MinecraftBlockTypes2["SandstoneDoubleSlab"] = "minecraft:sandstone_double_slab";
  MinecraftBlockTypes2["SandstoneSlab"] = "minecraft:sandstone_slab";
  MinecraftBlockTypes2["SandstoneStairs"] = "minecraft:sandstone_stairs";
  MinecraftBlockTypes2["SandstoneWall"] = "minecraft:sandstone_wall";
  MinecraftBlockTypes2["Scaffolding"] = "minecraft:scaffolding";
  MinecraftBlockTypes2["Sculk"] = "minecraft:sculk";
  MinecraftBlockTypes2["SculkCatalyst"] = "minecraft:sculk_catalyst";
  MinecraftBlockTypes2["SculkSensor"] = "minecraft:sculk_sensor";
  MinecraftBlockTypes2["SculkShrieker"] = "minecraft:sculk_shrieker";
  MinecraftBlockTypes2["SculkVein"] = "minecraft:sculk_vein";
  MinecraftBlockTypes2["SeaLantern"] = "minecraft:sea_lantern";
  MinecraftBlockTypes2["SeaPickle"] = "minecraft:sea_pickle";
  MinecraftBlockTypes2["Seagrass"] = "minecraft:seagrass";
  MinecraftBlockTypes2["ShortDryGrass"] = "minecraft:short_dry_grass";
  MinecraftBlockTypes2["ShortGrass"] = "minecraft:short_grass";
  MinecraftBlockTypes2["Shroomlight"] = "minecraft:shroomlight";
  MinecraftBlockTypes2["SilverGlazedTerracotta"] = "minecraft:silver_glazed_terracotta";
  MinecraftBlockTypes2["SkeletonSkull"] = "minecraft:skeleton_skull";
  MinecraftBlockTypes2["Slime"] = "minecraft:slime";
  MinecraftBlockTypes2["SmallAmethystBud"] = "minecraft:small_amethyst_bud";
  MinecraftBlockTypes2["SmallDripleafBlock"] = "minecraft:small_dripleaf_block";
  MinecraftBlockTypes2["SmithingTable"] = "minecraft:smithing_table";
  MinecraftBlockTypes2["Smoker"] = "minecraft:smoker";
  MinecraftBlockTypes2["SmoothBasalt"] = "minecraft:smooth_basalt";
  MinecraftBlockTypes2["SmoothQuartz"] = "minecraft:smooth_quartz";
  MinecraftBlockTypes2["SmoothQuartzDoubleSlab"] = "minecraft:smooth_quartz_double_slab";
  MinecraftBlockTypes2["SmoothQuartzSlab"] = "minecraft:smooth_quartz_slab";
  MinecraftBlockTypes2["SmoothQuartzStairs"] = "minecraft:smooth_quartz_stairs";
  MinecraftBlockTypes2["SmoothRedSandstone"] = "minecraft:smooth_red_sandstone";
  MinecraftBlockTypes2["SmoothRedSandstoneDoubleSlab"] = "minecraft:smooth_red_sandstone_double_slab";
  MinecraftBlockTypes2["SmoothRedSandstoneSlab"] = "minecraft:smooth_red_sandstone_slab";
  MinecraftBlockTypes2["SmoothRedSandstoneStairs"] = "minecraft:smooth_red_sandstone_stairs";
  MinecraftBlockTypes2["SmoothSandstone"] = "minecraft:smooth_sandstone";
  MinecraftBlockTypes2["SmoothSandstoneDoubleSlab"] = "minecraft:smooth_sandstone_double_slab";
  MinecraftBlockTypes2["SmoothSandstoneSlab"] = "minecraft:smooth_sandstone_slab";
  MinecraftBlockTypes2["SmoothSandstoneStairs"] = "minecraft:smooth_sandstone_stairs";
  MinecraftBlockTypes2["SmoothStone"] = "minecraft:smooth_stone";
  MinecraftBlockTypes2["SmoothStoneDoubleSlab"] = "minecraft:smooth_stone_double_slab";
  MinecraftBlockTypes2["SmoothStoneSlab"] = "minecraft:smooth_stone_slab";
  MinecraftBlockTypes2["SnifferEgg"] = "minecraft:sniffer_egg";
  MinecraftBlockTypes2["Snow"] = "minecraft:snow";
  MinecraftBlockTypes2["SnowLayer"] = "minecraft:snow_layer";
  MinecraftBlockTypes2["SoulCampfire"] = "minecraft:soul_campfire";
  MinecraftBlockTypes2["SoulFire"] = "minecraft:soul_fire";
  MinecraftBlockTypes2["SoulLantern"] = "minecraft:soul_lantern";
  MinecraftBlockTypes2["SoulSand"] = "minecraft:soul_sand";
  MinecraftBlockTypes2["SoulSoil"] = "minecraft:soul_soil";
  MinecraftBlockTypes2["SoulTorch"] = "minecraft:soul_torch";
  MinecraftBlockTypes2["Sponge"] = "minecraft:sponge";
  MinecraftBlockTypes2["SporeBlossom"] = "minecraft:spore_blossom";
  MinecraftBlockTypes2["SpruceButton"] = "minecraft:spruce_button";
  MinecraftBlockTypes2["SpruceDoor"] = "minecraft:spruce_door";
  MinecraftBlockTypes2["SpruceDoubleSlab"] = "minecraft:spruce_double_slab";
  MinecraftBlockTypes2["SpruceFence"] = "minecraft:spruce_fence";
  MinecraftBlockTypes2["SpruceFenceGate"] = "minecraft:spruce_fence_gate";
  MinecraftBlockTypes2["SpruceHangingSign"] = "minecraft:spruce_hanging_sign";
  MinecraftBlockTypes2["SpruceLeaves"] = "minecraft:spruce_leaves";
  MinecraftBlockTypes2["SpruceLog"] = "minecraft:spruce_log";
  MinecraftBlockTypes2["SprucePlanks"] = "minecraft:spruce_planks";
  MinecraftBlockTypes2["SprucePressurePlate"] = "minecraft:spruce_pressure_plate";
  MinecraftBlockTypes2["SpruceSapling"] = "minecraft:spruce_sapling";
  MinecraftBlockTypes2["SpruceShelf"] = "minecraft:spruce_shelf";
  MinecraftBlockTypes2["SpruceSlab"] = "minecraft:spruce_slab";
  MinecraftBlockTypes2["SpruceStairs"] = "minecraft:spruce_stairs";
  MinecraftBlockTypes2["SpruceStandingSign"] = "minecraft:spruce_standing_sign";
  MinecraftBlockTypes2["SpruceTrapdoor"] = "minecraft:spruce_trapdoor";
  MinecraftBlockTypes2["SpruceWallSign"] = "minecraft:spruce_wall_sign";
  MinecraftBlockTypes2["SpruceWood"] = "minecraft:spruce_wood";
  MinecraftBlockTypes2["StandingBanner"] = "minecraft:standing_banner";
  MinecraftBlockTypes2["StandingSign"] = "minecraft:standing_sign";
  MinecraftBlockTypes2["StickyPiston"] = "minecraft:sticky_piston";
  MinecraftBlockTypes2["StickyPistonArmCollision"] = "minecraft:sticky_piston_arm_collision";
  MinecraftBlockTypes2["Stone"] = "minecraft:stone";
  MinecraftBlockTypes2["StoneBrickDoubleSlab"] = "minecraft:stone_brick_double_slab";
  MinecraftBlockTypes2["StoneBrickSlab"] = "minecraft:stone_brick_slab";
  MinecraftBlockTypes2["StoneBrickStairs"] = "minecraft:stone_brick_stairs";
  MinecraftBlockTypes2["StoneBrickWall"] = "minecraft:stone_brick_wall";
  MinecraftBlockTypes2["StoneBricks"] = "minecraft:stone_bricks";
  MinecraftBlockTypes2["StoneButton"] = "minecraft:stone_button";
  MinecraftBlockTypes2["StonePressurePlate"] = "minecraft:stone_pressure_plate";
  MinecraftBlockTypes2["StoneStairs"] = "minecraft:stone_stairs";
  MinecraftBlockTypes2["StonecutterBlock"] = "minecraft:stonecutter_block";
  MinecraftBlockTypes2["StrippedAcaciaLog"] = "minecraft:stripped_acacia_log";
  MinecraftBlockTypes2["StrippedAcaciaWood"] = "minecraft:stripped_acacia_wood";
  MinecraftBlockTypes2["StrippedBambooBlock"] = "minecraft:stripped_bamboo_block";
  MinecraftBlockTypes2["StrippedBirchLog"] = "minecraft:stripped_birch_log";
  MinecraftBlockTypes2["StrippedBirchWood"] = "minecraft:stripped_birch_wood";
  MinecraftBlockTypes2["StrippedCherryLog"] = "minecraft:stripped_cherry_log";
  MinecraftBlockTypes2["StrippedCherryWood"] = "minecraft:stripped_cherry_wood";
  MinecraftBlockTypes2["StrippedCrimsonHyphae"] = "minecraft:stripped_crimson_hyphae";
  MinecraftBlockTypes2["StrippedCrimsonStem"] = "minecraft:stripped_crimson_stem";
  MinecraftBlockTypes2["StrippedDarkOakLog"] = "minecraft:stripped_dark_oak_log";
  MinecraftBlockTypes2["StrippedDarkOakWood"] = "minecraft:stripped_dark_oak_wood";
  MinecraftBlockTypes2["StrippedJungleLog"] = "minecraft:stripped_jungle_log";
  MinecraftBlockTypes2["StrippedJungleWood"] = "minecraft:stripped_jungle_wood";
  MinecraftBlockTypes2["StrippedMangroveLog"] = "minecraft:stripped_mangrove_log";
  MinecraftBlockTypes2["StrippedMangroveWood"] = "minecraft:stripped_mangrove_wood";
  MinecraftBlockTypes2["StrippedOakLog"] = "minecraft:stripped_oak_log";
  MinecraftBlockTypes2["StrippedOakWood"] = "minecraft:stripped_oak_wood";
  MinecraftBlockTypes2["StrippedPaleOakLog"] = "minecraft:stripped_pale_oak_log";
  MinecraftBlockTypes2["StrippedPaleOakWood"] = "minecraft:stripped_pale_oak_wood";
  MinecraftBlockTypes2["StrippedSpruceLog"] = "minecraft:stripped_spruce_log";
  MinecraftBlockTypes2["StrippedSpruceWood"] = "minecraft:stripped_spruce_wood";
  MinecraftBlockTypes2["StrippedWarpedHyphae"] = "minecraft:stripped_warped_hyphae";
  MinecraftBlockTypes2["StrippedWarpedStem"] = "minecraft:stripped_warped_stem";
  MinecraftBlockTypes2["StructureBlock"] = "minecraft:structure_block";
  MinecraftBlockTypes2["StructureVoid"] = "minecraft:structure_void";
  MinecraftBlockTypes2["Sulfur"] = "minecraft:sulfur";
  MinecraftBlockTypes2["SulfurBrickDoubleSlab"] = "minecraft:sulfur_brick_double_slab";
  MinecraftBlockTypes2["SulfurBrickSlab"] = "minecraft:sulfur_brick_slab";
  MinecraftBlockTypes2["SulfurBrickStairs"] = "minecraft:sulfur_brick_stairs";
  MinecraftBlockTypes2["SulfurBrickWall"] = "minecraft:sulfur_brick_wall";
  MinecraftBlockTypes2["SulfurBricks"] = "minecraft:sulfur_bricks";
  MinecraftBlockTypes2["SulfurDoubleSlab"] = "minecraft:sulfur_double_slab";
  MinecraftBlockTypes2["SulfurSlab"] = "minecraft:sulfur_slab";
  MinecraftBlockTypes2["SulfurSpike"] = "minecraft:sulfur_spike";
  MinecraftBlockTypes2["SulfurStairs"] = "minecraft:sulfur_stairs";
  MinecraftBlockTypes2["SulfurWall"] = "minecraft:sulfur_wall";
  MinecraftBlockTypes2["Sunflower"] = "minecraft:sunflower";
  MinecraftBlockTypes2["SuspiciousGravel"] = "minecraft:suspicious_gravel";
  MinecraftBlockTypes2["SuspiciousSand"] = "minecraft:suspicious_sand";
  MinecraftBlockTypes2["SweetBerryBush"] = "minecraft:sweet_berry_bush";
  MinecraftBlockTypes2["TallDryGrass"] = "minecraft:tall_dry_grass";
  MinecraftBlockTypes2["TallGrass"] = "minecraft:tall_grass";
  MinecraftBlockTypes2["Target"] = "minecraft:target";
  MinecraftBlockTypes2["TintedGlass"] = "minecraft:tinted_glass";
  MinecraftBlockTypes2["Tnt"] = "minecraft:tnt";
  MinecraftBlockTypes2["Torch"] = "minecraft:torch";
  MinecraftBlockTypes2["Torchflower"] = "minecraft:torchflower";
  MinecraftBlockTypes2["TorchflowerCrop"] = "minecraft:torchflower_crop";
  MinecraftBlockTypes2["Trapdoor"] = "minecraft:trapdoor";
  MinecraftBlockTypes2["TrappedChest"] = "minecraft:trapped_chest";
  MinecraftBlockTypes2["TrialSpawner"] = "minecraft:trial_spawner";
  MinecraftBlockTypes2["TripWire"] = "minecraft:trip_wire";
  MinecraftBlockTypes2["TripwireHook"] = "minecraft:tripwire_hook";
  MinecraftBlockTypes2["TubeCoral"] = "minecraft:tube_coral";
  MinecraftBlockTypes2["TubeCoralBlock"] = "minecraft:tube_coral_block";
  MinecraftBlockTypes2["TubeCoralFan"] = "minecraft:tube_coral_fan";
  MinecraftBlockTypes2["TubeCoralWallFan"] = "minecraft:tube_coral_wall_fan";
  MinecraftBlockTypes2["Tuff"] = "minecraft:tuff";
  MinecraftBlockTypes2["TuffBrickDoubleSlab"] = "minecraft:tuff_brick_double_slab";
  MinecraftBlockTypes2["TuffBrickSlab"] = "minecraft:tuff_brick_slab";
  MinecraftBlockTypes2["TuffBrickStairs"] = "minecraft:tuff_brick_stairs";
  MinecraftBlockTypes2["TuffBrickWall"] = "minecraft:tuff_brick_wall";
  MinecraftBlockTypes2["TuffBricks"] = "minecraft:tuff_bricks";
  MinecraftBlockTypes2["TuffDoubleSlab"] = "minecraft:tuff_double_slab";
  MinecraftBlockTypes2["TuffSlab"] = "minecraft:tuff_slab";
  MinecraftBlockTypes2["TuffStairs"] = "minecraft:tuff_stairs";
  MinecraftBlockTypes2["TuffWall"] = "minecraft:tuff_wall";
  MinecraftBlockTypes2["TurtleEgg"] = "minecraft:turtle_egg";
  MinecraftBlockTypes2["TwistingVines"] = "minecraft:twisting_vines";
  MinecraftBlockTypes2["UnderwaterTnt"] = "minecraft:underwater_tnt";
  MinecraftBlockTypes2["UnderwaterTorch"] = "minecraft:underwater_torch";
  MinecraftBlockTypes2["UndyedShulkerBox"] = "minecraft:undyed_shulker_box";
  MinecraftBlockTypes2["Unknown"] = "minecraft:unknown";
  MinecraftBlockTypes2["UnlitRedstoneTorch"] = "minecraft:unlit_redstone_torch";
  MinecraftBlockTypes2["UnpoweredComparator"] = "minecraft:unpowered_comparator";
  MinecraftBlockTypes2["UnpoweredRepeater"] = "minecraft:unpowered_repeater";
  MinecraftBlockTypes2["Vault"] = "minecraft:vault";
  MinecraftBlockTypes2["VerdantFroglight"] = "minecraft:verdant_froglight";
  MinecraftBlockTypes2["Vine"] = "minecraft:vine";
  MinecraftBlockTypes2["WallBanner"] = "minecraft:wall_banner";
  MinecraftBlockTypes2["WallSign"] = "minecraft:wall_sign";
  MinecraftBlockTypes2["WarpedButton"] = "minecraft:warped_button";
  MinecraftBlockTypes2["WarpedDoor"] = "minecraft:warped_door";
  MinecraftBlockTypes2["WarpedDoubleSlab"] = "minecraft:warped_double_slab";
  MinecraftBlockTypes2["WarpedFence"] = "minecraft:warped_fence";
  MinecraftBlockTypes2["WarpedFenceGate"] = "minecraft:warped_fence_gate";
  MinecraftBlockTypes2["WarpedFungus"] = "minecraft:warped_fungus";
  MinecraftBlockTypes2["WarpedHangingSign"] = "minecraft:warped_hanging_sign";
  MinecraftBlockTypes2["WarpedHyphae"] = "minecraft:warped_hyphae";
  MinecraftBlockTypes2["WarpedNylium"] = "minecraft:warped_nylium";
  MinecraftBlockTypes2["WarpedPlanks"] = "minecraft:warped_planks";
  MinecraftBlockTypes2["WarpedPressurePlate"] = "minecraft:warped_pressure_plate";
  MinecraftBlockTypes2["WarpedRoots"] = "minecraft:warped_roots";
  MinecraftBlockTypes2["WarpedShelf"] = "minecraft:warped_shelf";
  MinecraftBlockTypes2["WarpedSlab"] = "minecraft:warped_slab";
  MinecraftBlockTypes2["WarpedStairs"] = "minecraft:warped_stairs";
  MinecraftBlockTypes2["WarpedStandingSign"] = "minecraft:warped_standing_sign";
  MinecraftBlockTypes2["WarpedStem"] = "minecraft:warped_stem";
  MinecraftBlockTypes2["WarpedTrapdoor"] = "minecraft:warped_trapdoor";
  MinecraftBlockTypes2["WarpedWallSign"] = "minecraft:warped_wall_sign";
  MinecraftBlockTypes2["WarpedWartBlock"] = "minecraft:warped_wart_block";
  MinecraftBlockTypes2["Water"] = "minecraft:water";
  MinecraftBlockTypes2["Waterlily"] = "minecraft:waterlily";
  MinecraftBlockTypes2["WaxedChiseledCopper"] = "minecraft:waxed_chiseled_copper";
  MinecraftBlockTypes2["WaxedCopper"] = "minecraft:waxed_copper";
  MinecraftBlockTypes2["WaxedCopperBars"] = "minecraft:waxed_copper_bars";
  MinecraftBlockTypes2["WaxedCopperBulb"] = "minecraft:waxed_copper_bulb";
  MinecraftBlockTypes2["WaxedCopperChain"] = "minecraft:waxed_copper_chain";
  MinecraftBlockTypes2["WaxedCopperChest"] = "minecraft:waxed_copper_chest";
  MinecraftBlockTypes2["WaxedCopperDoor"] = "minecraft:waxed_copper_door";
  MinecraftBlockTypes2["WaxedCopperGolemStatue"] = "minecraft:waxed_copper_golem_statue";
  MinecraftBlockTypes2["WaxedCopperGrate"] = "minecraft:waxed_copper_grate";
  MinecraftBlockTypes2["WaxedCopperLantern"] = "minecraft:waxed_copper_lantern";
  MinecraftBlockTypes2["WaxedCopperTrapdoor"] = "minecraft:waxed_copper_trapdoor";
  MinecraftBlockTypes2["WaxedCutCopper"] = "minecraft:waxed_cut_copper";
  MinecraftBlockTypes2["WaxedCutCopperSlab"] = "minecraft:waxed_cut_copper_slab";
  MinecraftBlockTypes2["WaxedCutCopperStairs"] = "minecraft:waxed_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedDoubleCutCopperSlab"] = "minecraft:waxed_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedExposedChiseledCopper"] = "minecraft:waxed_exposed_chiseled_copper";
  MinecraftBlockTypes2["WaxedExposedCopper"] = "minecraft:waxed_exposed_copper";
  MinecraftBlockTypes2["WaxedExposedCopperBars"] = "minecraft:waxed_exposed_copper_bars";
  MinecraftBlockTypes2["WaxedExposedCopperBulb"] = "minecraft:waxed_exposed_copper_bulb";
  MinecraftBlockTypes2["WaxedExposedCopperChain"] = "minecraft:waxed_exposed_copper_chain";
  MinecraftBlockTypes2["WaxedExposedCopperChest"] = "minecraft:waxed_exposed_copper_chest";
  MinecraftBlockTypes2["WaxedExposedCopperDoor"] = "minecraft:waxed_exposed_copper_door";
  MinecraftBlockTypes2["WaxedExposedCopperGolemStatue"] = "minecraft:waxed_exposed_copper_golem_statue";
  MinecraftBlockTypes2["WaxedExposedCopperGrate"] = "minecraft:waxed_exposed_copper_grate";
  MinecraftBlockTypes2["WaxedExposedCopperLantern"] = "minecraft:waxed_exposed_copper_lantern";
  MinecraftBlockTypes2["WaxedExposedCopperTrapdoor"] = "minecraft:waxed_exposed_copper_trapdoor";
  MinecraftBlockTypes2["WaxedExposedCutCopper"] = "minecraft:waxed_exposed_cut_copper";
  MinecraftBlockTypes2["WaxedExposedCutCopperSlab"] = "minecraft:waxed_exposed_cut_copper_slab";
  MinecraftBlockTypes2["WaxedExposedCutCopperStairs"] = "minecraft:waxed_exposed_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedExposedDoubleCutCopperSlab"] = "minecraft:waxed_exposed_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedExposedLightningRod"] = "minecraft:waxed_exposed_lightning_rod";
  MinecraftBlockTypes2["WaxedLightningRod"] = "minecraft:waxed_lightning_rod";
  MinecraftBlockTypes2["WaxedOxidizedChiseledCopper"] = "minecraft:waxed_oxidized_chiseled_copper";
  MinecraftBlockTypes2["WaxedOxidizedCopper"] = "minecraft:waxed_oxidized_copper";
  MinecraftBlockTypes2["WaxedOxidizedCopperBars"] = "minecraft:waxed_oxidized_copper_bars";
  MinecraftBlockTypes2["WaxedOxidizedCopperBulb"] = "minecraft:waxed_oxidized_copper_bulb";
  MinecraftBlockTypes2["WaxedOxidizedCopperChain"] = "minecraft:waxed_oxidized_copper_chain";
  MinecraftBlockTypes2["WaxedOxidizedCopperChest"] = "minecraft:waxed_oxidized_copper_chest";
  MinecraftBlockTypes2["WaxedOxidizedCopperDoor"] = "minecraft:waxed_oxidized_copper_door";
  MinecraftBlockTypes2["WaxedOxidizedCopperGolemStatue"] = "minecraft:waxed_oxidized_copper_golem_statue";
  MinecraftBlockTypes2["WaxedOxidizedCopperGrate"] = "minecraft:waxed_oxidized_copper_grate";
  MinecraftBlockTypes2["WaxedOxidizedCopperLantern"] = "minecraft:waxed_oxidized_copper_lantern";
  MinecraftBlockTypes2["WaxedOxidizedCopperTrapdoor"] = "minecraft:waxed_oxidized_copper_trapdoor";
  MinecraftBlockTypes2["WaxedOxidizedCutCopper"] = "minecraft:waxed_oxidized_cut_copper";
  MinecraftBlockTypes2["WaxedOxidizedCutCopperSlab"] = "minecraft:waxed_oxidized_cut_copper_slab";
  MinecraftBlockTypes2["WaxedOxidizedCutCopperStairs"] = "minecraft:waxed_oxidized_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedOxidizedDoubleCutCopperSlab"] = "minecraft:waxed_oxidized_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedOxidizedLightningRod"] = "minecraft:waxed_oxidized_lightning_rod";
  MinecraftBlockTypes2["WaxedWeatheredChiseledCopper"] = "minecraft:waxed_weathered_chiseled_copper";
  MinecraftBlockTypes2["WaxedWeatheredCopper"] = "minecraft:waxed_weathered_copper";
  MinecraftBlockTypes2["WaxedWeatheredCopperBars"] = "minecraft:waxed_weathered_copper_bars";
  MinecraftBlockTypes2["WaxedWeatheredCopperBulb"] = "minecraft:waxed_weathered_copper_bulb";
  MinecraftBlockTypes2["WaxedWeatheredCopperChain"] = "minecraft:waxed_weathered_copper_chain";
  MinecraftBlockTypes2["WaxedWeatheredCopperChest"] = "minecraft:waxed_weathered_copper_chest";
  MinecraftBlockTypes2["WaxedWeatheredCopperDoor"] = "minecraft:waxed_weathered_copper_door";
  MinecraftBlockTypes2["WaxedWeatheredCopperGolemStatue"] = "minecraft:waxed_weathered_copper_golem_statue";
  MinecraftBlockTypes2["WaxedWeatheredCopperGrate"] = "minecraft:waxed_weathered_copper_grate";
  MinecraftBlockTypes2["WaxedWeatheredCopperLantern"] = "minecraft:waxed_weathered_copper_lantern";
  MinecraftBlockTypes2["WaxedWeatheredCopperTrapdoor"] = "minecraft:waxed_weathered_copper_trapdoor";
  MinecraftBlockTypes2["WaxedWeatheredCutCopper"] = "minecraft:waxed_weathered_cut_copper";
  MinecraftBlockTypes2["WaxedWeatheredCutCopperSlab"] = "minecraft:waxed_weathered_cut_copper_slab";
  MinecraftBlockTypes2["WaxedWeatheredCutCopperStairs"] = "minecraft:waxed_weathered_cut_copper_stairs";
  MinecraftBlockTypes2["WaxedWeatheredDoubleCutCopperSlab"] = "minecraft:waxed_weathered_double_cut_copper_slab";
  MinecraftBlockTypes2["WaxedWeatheredLightningRod"] = "minecraft:waxed_weathered_lightning_rod";
  MinecraftBlockTypes2["WeatheredChiseledCopper"] = "minecraft:weathered_chiseled_copper";
  MinecraftBlockTypes2["WeatheredCopper"] = "minecraft:weathered_copper";
  MinecraftBlockTypes2["WeatheredCopperBars"] = "minecraft:weathered_copper_bars";
  MinecraftBlockTypes2["WeatheredCopperBulb"] = "minecraft:weathered_copper_bulb";
  MinecraftBlockTypes2["WeatheredCopperChain"] = "minecraft:weathered_copper_chain";
  MinecraftBlockTypes2["WeatheredCopperChest"] = "minecraft:weathered_copper_chest";
  MinecraftBlockTypes2["WeatheredCopperDoor"] = "minecraft:weathered_copper_door";
  MinecraftBlockTypes2["WeatheredCopperGolemStatue"] = "minecraft:weathered_copper_golem_statue";
  MinecraftBlockTypes2["WeatheredCopperGrate"] = "minecraft:weathered_copper_grate";
  MinecraftBlockTypes2["WeatheredCopperLantern"] = "minecraft:weathered_copper_lantern";
  MinecraftBlockTypes2["WeatheredCopperTrapdoor"] = "minecraft:weathered_copper_trapdoor";
  MinecraftBlockTypes2["WeatheredCutCopper"] = "minecraft:weathered_cut_copper";
  MinecraftBlockTypes2["WeatheredCutCopperSlab"] = "minecraft:weathered_cut_copper_slab";
  MinecraftBlockTypes2["WeatheredCutCopperStairs"] = "minecraft:weathered_cut_copper_stairs";
  MinecraftBlockTypes2["WeatheredDoubleCutCopperSlab"] = "minecraft:weathered_double_cut_copper_slab";
  MinecraftBlockTypes2["WeatheredLightningRod"] = "minecraft:weathered_lightning_rod";
  MinecraftBlockTypes2["Web"] = "minecraft:web";
  MinecraftBlockTypes2["WeepingVines"] = "minecraft:weeping_vines";
  MinecraftBlockTypes2["WetSponge"] = "minecraft:wet_sponge";
  MinecraftBlockTypes2["Wheat"] = "minecraft:wheat";
  MinecraftBlockTypes2["WhiteCandle"] = "minecraft:white_candle";
  MinecraftBlockTypes2["WhiteCandleCake"] = "minecraft:white_candle_cake";
  MinecraftBlockTypes2["WhiteCarpet"] = "minecraft:white_carpet";
  MinecraftBlockTypes2["WhiteConcrete"] = "minecraft:white_concrete";
  MinecraftBlockTypes2["WhiteConcretePowder"] = "minecraft:white_concrete_powder";
  MinecraftBlockTypes2["WhiteGlazedTerracotta"] = "minecraft:white_glazed_terracotta";
  MinecraftBlockTypes2["WhiteShulkerBox"] = "minecraft:white_shulker_box";
  MinecraftBlockTypes2["WhiteStainedGlass"] = "minecraft:white_stained_glass";
  MinecraftBlockTypes2["WhiteStainedGlassPane"] = "minecraft:white_stained_glass_pane";
  MinecraftBlockTypes2["WhiteTerracotta"] = "minecraft:white_terracotta";
  MinecraftBlockTypes2["WhiteTulip"] = "minecraft:white_tulip";
  MinecraftBlockTypes2["WhiteWool"] = "minecraft:white_wool";
  MinecraftBlockTypes2["Wildflowers"] = "minecraft:wildflowers";
  MinecraftBlockTypes2["WitherRose"] = "minecraft:wither_rose";
  MinecraftBlockTypes2["WitherSkeletonSkull"] = "minecraft:wither_skeleton_skull";
  MinecraftBlockTypes2["WoodenButton"] = "minecraft:wooden_button";
  MinecraftBlockTypes2["WoodenDoor"] = "minecraft:wooden_door";
  MinecraftBlockTypes2["WoodenPressurePlate"] = "minecraft:wooden_pressure_plate";
  MinecraftBlockTypes2["YellowCandle"] = "minecraft:yellow_candle";
  MinecraftBlockTypes2["YellowCandleCake"] = "minecraft:yellow_candle_cake";
  MinecraftBlockTypes2["YellowCarpet"] = "minecraft:yellow_carpet";
  MinecraftBlockTypes2["YellowConcrete"] = "minecraft:yellow_concrete";
  MinecraftBlockTypes2["YellowConcretePowder"] = "minecraft:yellow_concrete_powder";
  MinecraftBlockTypes2["YellowGlazedTerracotta"] = "minecraft:yellow_glazed_terracotta";
  MinecraftBlockTypes2["YellowShulkerBox"] = "minecraft:yellow_shulker_box";
  MinecraftBlockTypes2["YellowStainedGlass"] = "minecraft:yellow_stained_glass";
  MinecraftBlockTypes2["YellowStainedGlassPane"] = "minecraft:yellow_stained_glass_pane";
  MinecraftBlockTypes2["YellowTerracotta"] = "minecraft:yellow_terracotta";
  MinecraftBlockTypes2["YellowWool"] = "minecraft:yellow_wool";
  MinecraftBlockTypes2["ZombieHead"] = "minecraft:zombie_head";
  return MinecraftBlockTypes2;
})(MinecraftBlockTypes || {});
var MinecraftCameraPresetsTypes = ((MinecraftCameraPresetsTypes2) => {
  MinecraftCameraPresetsTypes2["ControlSchemeCamera"] = "minecraft:control_scheme_camera";
  MinecraftCameraPresetsTypes2["FirstPerson"] = "minecraft:first_person";
  MinecraftCameraPresetsTypes2["FixedBoom"] = "minecraft:fixed_boom";
  MinecraftCameraPresetsTypes2["FollowOrbit"] = "minecraft:follow_orbit";
  MinecraftCameraPresetsTypes2["Free"] = "minecraft:free";
  MinecraftCameraPresetsTypes2["ThirdPerson"] = "minecraft:third_person";
  MinecraftCameraPresetsTypes2["ThirdPersonFront"] = "minecraft:third_person_front";
  return MinecraftCameraPresetsTypes2;
})(MinecraftCameraPresetsTypes || {});
var MinecraftCooldownCategoryTypes = ((MinecraftCooldownCategoryTypes2) => {
  MinecraftCooldownCategoryTypes2["Chorusfruit"] = "minecraft:chorusfruit";
  MinecraftCooldownCategoryTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftCooldownCategoryTypes2["GoatHorn"] = "minecraft:goat_horn";
  MinecraftCooldownCategoryTypes2["Shield"] = "minecraft:shield";
  MinecraftCooldownCategoryTypes2["Spear"] = "minecraft:spear";
  MinecraftCooldownCategoryTypes2["WindCharge"] = "minecraft:wind_charge";
  return MinecraftCooldownCategoryTypes2;
})(MinecraftCooldownCategoryTypes || {});
var MinecraftDimensionTypes = ((MinecraftDimensionTypes2) => {
  MinecraftDimensionTypes2["Nether"] = "minecraft:nether";
  MinecraftDimensionTypes2["Overworld"] = "minecraft:overworld";
  MinecraftDimensionTypes2["TheEnd"] = "minecraft:the_end";
  return MinecraftDimensionTypes2;
})(MinecraftDimensionTypes || {});
var MinecraftEffectTypes = ((MinecraftEffectTypes2) => {
  MinecraftEffectTypes2["Absorption"] = "minecraft:absorption";
  MinecraftEffectTypes2["BadOmen"] = "minecraft:bad_omen";
  MinecraftEffectTypes2["Blindness"] = "minecraft:blindness";
  MinecraftEffectTypes2["BreathOfTheNautilus"] = "minecraft:breath_of_the_nautilus";
  MinecraftEffectTypes2["ConduitPower"] = "minecraft:conduit_power";
  MinecraftEffectTypes2["Darkness"] = "minecraft:darkness";
  MinecraftEffectTypes2["FatalPoison"] = "minecraft:fatal_poison";
  MinecraftEffectTypes2["FireResistance"] = "minecraft:fire_resistance";
  MinecraftEffectTypes2["Haste"] = "minecraft:haste";
  MinecraftEffectTypes2["HealthBoost"] = "minecraft:health_boost";
  MinecraftEffectTypes2["Hunger"] = "minecraft:hunger";
  MinecraftEffectTypes2["Infested"] = "minecraft:infested";
  MinecraftEffectTypes2["InstantDamage"] = "minecraft:instant_damage";
  MinecraftEffectTypes2["InstantHealth"] = "minecraft:instant_health";
  MinecraftEffectTypes2["Invisibility"] = "minecraft:invisibility";
  MinecraftEffectTypes2["JumpBoost"] = "minecraft:jump_boost";
  MinecraftEffectTypes2["Levitation"] = "minecraft:levitation";
  MinecraftEffectTypes2["MiningFatigue"] = "minecraft:mining_fatigue";
  MinecraftEffectTypes2["Nausea"] = "minecraft:nausea";
  MinecraftEffectTypes2["NightVision"] = "minecraft:night_vision";
  MinecraftEffectTypes2["Oozing"] = "minecraft:oozing";
  MinecraftEffectTypes2["Poison"] = "minecraft:poison";
  MinecraftEffectTypes2["RaidOmen"] = "minecraft:raid_omen";
  MinecraftEffectTypes2["Regeneration"] = "minecraft:regeneration";
  MinecraftEffectTypes2["Resistance"] = "minecraft:resistance";
  MinecraftEffectTypes2["Saturation"] = "minecraft:saturation";
  MinecraftEffectTypes2["SlowFalling"] = "minecraft:slow_falling";
  MinecraftEffectTypes2["Slowness"] = "minecraft:slowness";
  MinecraftEffectTypes2["Speed"] = "minecraft:speed";
  MinecraftEffectTypes2["Strength"] = "minecraft:strength";
  MinecraftEffectTypes2["TrialOmen"] = "minecraft:trial_omen";
  MinecraftEffectTypes2["VillageHero"] = "minecraft:village_hero";
  MinecraftEffectTypes2["WaterBreathing"] = "minecraft:water_breathing";
  MinecraftEffectTypes2["Weakness"] = "minecraft:weakness";
  MinecraftEffectTypes2["Weaving"] = "minecraft:weaving";
  MinecraftEffectTypes2["WindCharged"] = "minecraft:wind_charged";
  MinecraftEffectTypes2["Wither"] = "minecraft:wither";
  return MinecraftEffectTypes2;
})(MinecraftEffectTypes || {});
var MinecraftEnchantmentTypes = ((MinecraftEnchantmentTypes2) => {
  MinecraftEnchantmentTypes2["AquaAffinity"] = "minecraft:aqua_affinity";
  MinecraftEnchantmentTypes2["BaneOfArthropods"] = "minecraft:bane_of_arthropods";
  MinecraftEnchantmentTypes2["Binding"] = "minecraft:binding";
  MinecraftEnchantmentTypes2["BlastProtection"] = "minecraft:blast_protection";
  MinecraftEnchantmentTypes2["BowInfinity"] = "minecraft:infinity";
  MinecraftEnchantmentTypes2["Breach"] = "minecraft:breach";
  MinecraftEnchantmentTypes2["Channeling"] = "minecraft:channeling";
  MinecraftEnchantmentTypes2["Density"] = "minecraft:density";
  MinecraftEnchantmentTypes2["DepthStrider"] = "minecraft:depth_strider";
  MinecraftEnchantmentTypes2["Efficiency"] = "minecraft:efficiency";
  MinecraftEnchantmentTypes2["FeatherFalling"] = "minecraft:feather_falling";
  MinecraftEnchantmentTypes2["FireAspect"] = "minecraft:fire_aspect";
  MinecraftEnchantmentTypes2["FireProtection"] = "minecraft:fire_protection";
  MinecraftEnchantmentTypes2["Flame"] = "minecraft:flame";
  MinecraftEnchantmentTypes2["Fortune"] = "minecraft:fortune";
  MinecraftEnchantmentTypes2["FrostWalker"] = "minecraft:frost_walker";
  MinecraftEnchantmentTypes2["Impaling"] = "minecraft:impaling";
  MinecraftEnchantmentTypes2["Knockback"] = "minecraft:knockback";
  MinecraftEnchantmentTypes2["Looting"] = "minecraft:looting";
  MinecraftEnchantmentTypes2["Loyalty"] = "minecraft:loyalty";
  MinecraftEnchantmentTypes2["LuckOfTheSea"] = "minecraft:luck_of_the_sea";
  MinecraftEnchantmentTypes2["Lunge"] = "minecraft:lunge";
  MinecraftEnchantmentTypes2["Lure"] = "minecraft:lure";
  MinecraftEnchantmentTypes2["Mending"] = "minecraft:mending";
  MinecraftEnchantmentTypes2["Multishot"] = "minecraft:multishot";
  MinecraftEnchantmentTypes2["Piercing"] = "minecraft:piercing";
  MinecraftEnchantmentTypes2["Power"] = "minecraft:power";
  MinecraftEnchantmentTypes2["ProjectileProtection"] = "minecraft:projectile_protection";
  MinecraftEnchantmentTypes2["Protection"] = "minecraft:protection";
  MinecraftEnchantmentTypes2["Punch"] = "minecraft:punch";
  MinecraftEnchantmentTypes2["QuickCharge"] = "minecraft:quick_charge";
  MinecraftEnchantmentTypes2["Respiration"] = "minecraft:respiration";
  MinecraftEnchantmentTypes2["Riptide"] = "minecraft:riptide";
  MinecraftEnchantmentTypes2["Sharpness"] = "minecraft:sharpness";
  MinecraftEnchantmentTypes2["SilkTouch"] = "minecraft:silk_touch";
  MinecraftEnchantmentTypes2["Smite"] = "minecraft:smite";
  MinecraftEnchantmentTypes2["SoulSpeed"] = "minecraft:soul_speed";
  MinecraftEnchantmentTypes2["SwiftSneak"] = "minecraft:swift_sneak";
  MinecraftEnchantmentTypes2["Thorns"] = "minecraft:thorns";
  MinecraftEnchantmentTypes2["Unbreaking"] = "minecraft:unbreaking";
  MinecraftEnchantmentTypes2["Vanishing"] = "minecraft:vanishing";
  MinecraftEnchantmentTypes2["WindBurst"] = "minecraft:wind_burst";
  return MinecraftEnchantmentTypes2;
})(MinecraftEnchantmentTypes || {});
var MinecraftEntityTypes = ((MinecraftEntityTypes2) => {
  MinecraftEntityTypes2["Agent"] = "minecraft:agent";
  MinecraftEntityTypes2["Allay"] = "minecraft:allay";
  MinecraftEntityTypes2["AreaEffectCloud"] = "minecraft:area_effect_cloud";
  MinecraftEntityTypes2["Armadillo"] = "minecraft:armadillo";
  MinecraftEntityTypes2["ArmorStand"] = "minecraft:armor_stand";
  MinecraftEntityTypes2["Arrow"] = "minecraft:arrow";
  MinecraftEntityTypes2["Axolotl"] = "minecraft:axolotl";
  MinecraftEntityTypes2["Bat"] = "minecraft:bat";
  MinecraftEntityTypes2["Bee"] = "minecraft:bee";
  MinecraftEntityTypes2["Blaze"] = "minecraft:blaze";
  MinecraftEntityTypes2["Boat"] = "minecraft:boat";
  MinecraftEntityTypes2["Bogged"] = "minecraft:bogged";
  MinecraftEntityTypes2["Breeze"] = "minecraft:breeze";
  MinecraftEntityTypes2["BreezeWindChargeProjectile"] = "minecraft:breeze_wind_charge_projectile";
  MinecraftEntityTypes2["Camel"] = "minecraft:camel";
  MinecraftEntityTypes2["CamelHusk"] = "minecraft:camel_husk";
  MinecraftEntityTypes2["Cat"] = "minecraft:cat";
  MinecraftEntityTypes2["CaveSpider"] = "minecraft:cave_spider";
  MinecraftEntityTypes2["ChestBoat"] = "minecraft:chest_boat";
  MinecraftEntityTypes2["ChestMinecart"] = "minecraft:chest_minecart";
  MinecraftEntityTypes2["Chicken"] = "minecraft:chicken";
  MinecraftEntityTypes2["Cod"] = "minecraft:cod";
  MinecraftEntityTypes2["CommandBlockMinecart"] = "minecraft:command_block_minecart";
  MinecraftEntityTypes2["CopperGolem"] = "minecraft:copper_golem";
  MinecraftEntityTypes2["Cow"] = "minecraft:cow";
  MinecraftEntityTypes2["Creaking"] = "minecraft:creaking";
  MinecraftEntityTypes2["Creeper"] = "minecraft:creeper";
  MinecraftEntityTypes2["Dolphin"] = "minecraft:dolphin";
  MinecraftEntityTypes2["Donkey"] = "minecraft:donkey";
  MinecraftEntityTypes2["DragonFireball"] = "minecraft:dragon_fireball";
  MinecraftEntityTypes2["Drowned"] = "minecraft:drowned";
  MinecraftEntityTypes2["Egg"] = "minecraft:egg";
  MinecraftEntityTypes2["ElderGuardian"] = "minecraft:elder_guardian";
  MinecraftEntityTypes2["EnderCrystal"] = "minecraft:ender_crystal";
  MinecraftEntityTypes2["EnderDragon"] = "minecraft:ender_dragon";
  MinecraftEntityTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftEntityTypes2["Enderman"] = "minecraft:enderman";
  MinecraftEntityTypes2["Endermite"] = "minecraft:endermite";
  MinecraftEntityTypes2["EvocationIllager"] = "minecraft:evocation_illager";
  MinecraftEntityTypes2["EyeOfEnderSignal"] = "minecraft:eye_of_ender_signal";
  MinecraftEntityTypes2["Fireball"] = "minecraft:fireball";
  MinecraftEntityTypes2["FireworksRocket"] = "minecraft:fireworks_rocket";
  MinecraftEntityTypes2["FishingHook"] = "minecraft:fishing_hook";
  MinecraftEntityTypes2["Fox"] = "minecraft:fox";
  MinecraftEntityTypes2["Frog"] = "minecraft:frog";
  MinecraftEntityTypes2["Ghast"] = "minecraft:ghast";
  MinecraftEntityTypes2["GlowSquid"] = "minecraft:glow_squid";
  MinecraftEntityTypes2["Goat"] = "minecraft:goat";
  MinecraftEntityTypes2["Guardian"] = "minecraft:guardian";
  MinecraftEntityTypes2["HappyGhast"] = "minecraft:happy_ghast";
  MinecraftEntityTypes2["Hoglin"] = "minecraft:hoglin";
  MinecraftEntityTypes2["HopperMinecart"] = "minecraft:hopper_minecart";
  MinecraftEntityTypes2["Horse"] = "minecraft:horse";
  MinecraftEntityTypes2["Husk"] = "minecraft:husk";
  MinecraftEntityTypes2["IronGolem"] = "minecraft:iron_golem";
  MinecraftEntityTypes2["LightningBolt"] = "minecraft:lightning_bolt";
  MinecraftEntityTypes2["LingeringPotion"] = "minecraft:lingering_potion";
  MinecraftEntityTypes2["Llama"] = "minecraft:llama";
  MinecraftEntityTypes2["LlamaSpit"] = "minecraft:llama_spit";
  MinecraftEntityTypes2["MagmaCube"] = "minecraft:magma_cube";
  MinecraftEntityTypes2["Minecart"] = "minecraft:minecart";
  MinecraftEntityTypes2["Mooshroom"] = "minecraft:mooshroom";
  MinecraftEntityTypes2["Mule"] = "minecraft:mule";
  MinecraftEntityTypes2["Nautilus"] = "minecraft:nautilus";
  MinecraftEntityTypes2["Npc"] = "minecraft:npc";
  MinecraftEntityTypes2["Ocelot"] = "minecraft:ocelot";
  MinecraftEntityTypes2["OminousItemSpawner"] = "minecraft:ominous_item_spawner";
  MinecraftEntityTypes2["Panda"] = "minecraft:panda";
  MinecraftEntityTypes2["Parched"] = "minecraft:parched";
  MinecraftEntityTypes2["Parrot"] = "minecraft:parrot";
  MinecraftEntityTypes2["Phantom"] = "minecraft:phantom";
  MinecraftEntityTypes2["Pig"] = "minecraft:pig";
  MinecraftEntityTypes2["Piglin"] = "minecraft:piglin";
  MinecraftEntityTypes2["PiglinBrute"] = "minecraft:piglin_brute";
  MinecraftEntityTypes2["Pillager"] = "minecraft:pillager";
  MinecraftEntityTypes2["Player"] = "minecraft:player";
  MinecraftEntityTypes2["PolarBear"] = "minecraft:polar_bear";
  MinecraftEntityTypes2["Pufferfish"] = "minecraft:pufferfish";
  MinecraftEntityTypes2["Rabbit"] = "minecraft:rabbit";
  MinecraftEntityTypes2["Ravager"] = "minecraft:ravager";
  MinecraftEntityTypes2["Salmon"] = "minecraft:salmon";
  MinecraftEntityTypes2["Sheep"] = "minecraft:sheep";
  MinecraftEntityTypes2["Shulker"] = "minecraft:shulker";
  MinecraftEntityTypes2["ShulkerBullet"] = "minecraft:shulker_bullet";
  MinecraftEntityTypes2["Silverfish"] = "minecraft:silverfish";
  MinecraftEntityTypes2["Skeleton"] = "minecraft:skeleton";
  MinecraftEntityTypes2["SkeletonHorse"] = "minecraft:skeleton_horse";
  MinecraftEntityTypes2["Slime"] = "minecraft:slime";
  MinecraftEntityTypes2["SmallFireball"] = "minecraft:small_fireball";
  MinecraftEntityTypes2["Sniffer"] = "minecraft:sniffer";
  MinecraftEntityTypes2["SnowGolem"] = "minecraft:snow_golem";
  MinecraftEntityTypes2["Snowball"] = "minecraft:snowball";
  MinecraftEntityTypes2["Spider"] = "minecraft:spider";
  MinecraftEntityTypes2["SplashPotion"] = "minecraft:splash_potion";
  MinecraftEntityTypes2["Squid"] = "minecraft:squid";
  MinecraftEntityTypes2["Stray"] = "minecraft:stray";
  MinecraftEntityTypes2["Strider"] = "minecraft:strider";
  MinecraftEntityTypes2["SulfurCube"] = "minecraft:sulfur_cube";
  MinecraftEntityTypes2["Tadpole"] = "minecraft:tadpole";
  MinecraftEntityTypes2["ThrownTrident"] = "minecraft:thrown_trident";
  MinecraftEntityTypes2["Tnt"] = "minecraft:tnt";
  MinecraftEntityTypes2["TntMinecart"] = "minecraft:tnt_minecart";
  MinecraftEntityTypes2["TraderLlama"] = "minecraft:trader_llama";
  MinecraftEntityTypes2["TripodCamera"] = "minecraft:tripod_camera";
  MinecraftEntityTypes2["Tropicalfish"] = "minecraft:tropicalfish";
  MinecraftEntityTypes2["Turtle"] = "minecraft:turtle";
  MinecraftEntityTypes2["Vex"] = "minecraft:vex";
  MinecraftEntityTypes2["Villager"] = "minecraft:villager";
  MinecraftEntityTypes2["VillagerV2"] = "minecraft:villager_v2";
  MinecraftEntityTypes2["Vindicator"] = "minecraft:vindicator";
  MinecraftEntityTypes2["WanderingTrader"] = "minecraft:wandering_trader";
  MinecraftEntityTypes2["Warden"] = "minecraft:warden";
  MinecraftEntityTypes2["WindChargeProjectile"] = "minecraft:wind_charge_projectile";
  MinecraftEntityTypes2["Witch"] = "minecraft:witch";
  MinecraftEntityTypes2["Wither"] = "minecraft:wither";
  MinecraftEntityTypes2["WitherSkeleton"] = "minecraft:wither_skeleton";
  MinecraftEntityTypes2["WitherSkull"] = "minecraft:wither_skull";
  MinecraftEntityTypes2["WitherSkullDangerous"] = "minecraft:wither_skull_dangerous";
  MinecraftEntityTypes2["Wolf"] = "minecraft:wolf";
  MinecraftEntityTypes2["XpBottle"] = "minecraft:xp_bottle";
  MinecraftEntityTypes2["XpOrb"] = "minecraft:xp_orb";
  MinecraftEntityTypes2["Zoglin"] = "minecraft:zoglin";
  MinecraftEntityTypes2["Zombie"] = "minecraft:zombie";
  MinecraftEntityTypes2["ZombieHorse"] = "minecraft:zombie_horse";
  MinecraftEntityTypes2["ZombieNautilus"] = "minecraft:zombie_nautilus";
  MinecraftEntityTypes2["ZombiePigman"] = "minecraft:zombie_pigman";
  MinecraftEntityTypes2["ZombieVillager"] = "minecraft:zombie_villager";
  MinecraftEntityTypes2["ZombieVillagerV2"] = "minecraft:zombie_villager_v2";
  return MinecraftEntityTypes2;
})(MinecraftEntityTypes || {});
var MinecraftFeatureTypes = ((MinecraftFeatureTypes2) => {
  MinecraftFeatureTypes2["AncientCity"] = "minecraft:ancient_city";
  MinecraftFeatureTypes2["BastionRemnant"] = "minecraft:bastion_remnant";
  MinecraftFeatureTypes2["BuriedTreasure"] = "minecraft:buried_treasure";
  MinecraftFeatureTypes2["EndCity"] = "minecraft:end_city";
  MinecraftFeatureTypes2["Fortress"] = "minecraft:fortress";
  MinecraftFeatureTypes2["Mansion"] = "minecraft:mansion";
  MinecraftFeatureTypes2["Mineshaft"] = "minecraft:mineshaft";
  MinecraftFeatureTypes2["Monument"] = "minecraft:monument";
  MinecraftFeatureTypes2["PillagerOutpost"] = "minecraft:pillager_outpost";
  MinecraftFeatureTypes2["RuinedPortal"] = "minecraft:ruined_portal";
  MinecraftFeatureTypes2["Ruins"] = "minecraft:ruins";
  MinecraftFeatureTypes2["Shipwreck"] = "minecraft:shipwreck";
  MinecraftFeatureTypes2["Stronghold"] = "minecraft:stronghold";
  MinecraftFeatureTypes2["Temple"] = "minecraft:temple";
  MinecraftFeatureTypes2["TrailRuins"] = "minecraft:trail_ruins";
  MinecraftFeatureTypes2["TrialChambers"] = "minecraft:trial_chambers";
  MinecraftFeatureTypes2["Village"] = "minecraft:village";
  return MinecraftFeatureTypes2;
})(MinecraftFeatureTypes || {});
var MinecraftItemTypes = ((MinecraftItemTypes2) => {
  MinecraftItemTypes2["AcaciaBoat"] = "minecraft:acacia_boat";
  MinecraftItemTypes2["AcaciaButton"] = "minecraft:acacia_button";
  MinecraftItemTypes2["AcaciaChestBoat"] = "minecraft:acacia_chest_boat";
  MinecraftItemTypes2["AcaciaDoor"] = "minecraft:acacia_door";
  MinecraftItemTypes2["AcaciaFence"] = "minecraft:acacia_fence";
  MinecraftItemTypes2["AcaciaFenceGate"] = "minecraft:acacia_fence_gate";
  MinecraftItemTypes2["AcaciaHangingSign"] = "minecraft:acacia_hanging_sign";
  MinecraftItemTypes2["AcaciaLeaves"] = "minecraft:acacia_leaves";
  MinecraftItemTypes2["AcaciaLog"] = "minecraft:acacia_log";
  MinecraftItemTypes2["AcaciaPlanks"] = "minecraft:acacia_planks";
  MinecraftItemTypes2["AcaciaPressurePlate"] = "minecraft:acacia_pressure_plate";
  MinecraftItemTypes2["AcaciaSapling"] = "minecraft:acacia_sapling";
  MinecraftItemTypes2["AcaciaShelf"] = "minecraft:acacia_shelf";
  MinecraftItemTypes2["AcaciaSign"] = "minecraft:acacia_sign";
  MinecraftItemTypes2["AcaciaSlab"] = "minecraft:acacia_slab";
  MinecraftItemTypes2["AcaciaStairs"] = "minecraft:acacia_stairs";
  MinecraftItemTypes2["AcaciaTrapdoor"] = "minecraft:acacia_trapdoor";
  MinecraftItemTypes2["AcaciaWood"] = "minecraft:acacia_wood";
  MinecraftItemTypes2["ActivatorRail"] = "minecraft:activator_rail";
  MinecraftItemTypes2["AllaySpawnEgg"] = "minecraft:allay_spawn_egg";
  MinecraftItemTypes2["Allium"] = "minecraft:allium";
  MinecraftItemTypes2["Allow"] = "minecraft:allow";
  MinecraftItemTypes2["AmethystBlock"] = "minecraft:amethyst_block";
  MinecraftItemTypes2["AmethystCluster"] = "minecraft:amethyst_cluster";
  MinecraftItemTypes2["AmethystShard"] = "minecraft:amethyst_shard";
  MinecraftItemTypes2["AncientDebris"] = "minecraft:ancient_debris";
  MinecraftItemTypes2["Andesite"] = "minecraft:andesite";
  MinecraftItemTypes2["AndesiteSlab"] = "minecraft:andesite_slab";
  MinecraftItemTypes2["AndesiteStairs"] = "minecraft:andesite_stairs";
  MinecraftItemTypes2["AndesiteWall"] = "minecraft:andesite_wall";
  MinecraftItemTypes2["AnglerPotterySherd"] = "minecraft:angler_pottery_sherd";
  MinecraftItemTypes2["Anvil"] = "minecraft:anvil";
  MinecraftItemTypes2["Apple"] = "minecraft:apple";
  MinecraftItemTypes2["ArcherPotterySherd"] = "minecraft:archer_pottery_sherd";
  MinecraftItemTypes2["ArmadilloScute"] = "minecraft:armadillo_scute";
  MinecraftItemTypes2["ArmadilloSpawnEgg"] = "minecraft:armadillo_spawn_egg";
  MinecraftItemTypes2["ArmorStand"] = "minecraft:armor_stand";
  MinecraftItemTypes2["ArmsUpPotterySherd"] = "minecraft:arms_up_pottery_sherd";
  MinecraftItemTypes2["Arrow"] = "minecraft:arrow";
  MinecraftItemTypes2["AxolotlBucket"] = "minecraft:axolotl_bucket";
  MinecraftItemTypes2["AxolotlSpawnEgg"] = "minecraft:axolotl_spawn_egg";
  MinecraftItemTypes2["Azalea"] = "minecraft:azalea";
  MinecraftItemTypes2["AzaleaLeaves"] = "minecraft:azalea_leaves";
  MinecraftItemTypes2["AzaleaLeavesFlowered"] = "minecraft:azalea_leaves_flowered";
  MinecraftItemTypes2["AzureBluet"] = "minecraft:azure_bluet";
  MinecraftItemTypes2["BakedPotato"] = "minecraft:baked_potato";
  MinecraftItemTypes2["Bamboo"] = "minecraft:bamboo";
  MinecraftItemTypes2["BambooBlock"] = "minecraft:bamboo_block";
  MinecraftItemTypes2["BambooButton"] = "minecraft:bamboo_button";
  MinecraftItemTypes2["BambooChestRaft"] = "minecraft:bamboo_chest_raft";
  MinecraftItemTypes2["BambooDoor"] = "minecraft:bamboo_door";
  MinecraftItemTypes2["BambooFence"] = "minecraft:bamboo_fence";
  MinecraftItemTypes2["BambooFenceGate"] = "minecraft:bamboo_fence_gate";
  MinecraftItemTypes2["BambooHangingSign"] = "minecraft:bamboo_hanging_sign";
  MinecraftItemTypes2["BambooMosaic"] = "minecraft:bamboo_mosaic";
  MinecraftItemTypes2["BambooMosaicSlab"] = "minecraft:bamboo_mosaic_slab";
  MinecraftItemTypes2["BambooMosaicStairs"] = "minecraft:bamboo_mosaic_stairs";
  MinecraftItemTypes2["BambooPlanks"] = "minecraft:bamboo_planks";
  MinecraftItemTypes2["BambooPressurePlate"] = "minecraft:bamboo_pressure_plate";
  MinecraftItemTypes2["BambooRaft"] = "minecraft:bamboo_raft";
  MinecraftItemTypes2["BambooShelf"] = "minecraft:bamboo_shelf";
  MinecraftItemTypes2["BambooSign"] = "minecraft:bamboo_sign";
  MinecraftItemTypes2["BambooSlab"] = "minecraft:bamboo_slab";
  MinecraftItemTypes2["BambooStairs"] = "minecraft:bamboo_stairs";
  MinecraftItemTypes2["BambooTrapdoor"] = "minecraft:bamboo_trapdoor";
  MinecraftItemTypes2["Banner"] = "minecraft:banner";
  MinecraftItemTypes2["Barrel"] = "minecraft:barrel";
  MinecraftItemTypes2["Barrier"] = "minecraft:barrier";
  MinecraftItemTypes2["Basalt"] = "minecraft:basalt";
  MinecraftItemTypes2["BatSpawnEgg"] = "minecraft:bat_spawn_egg";
  MinecraftItemTypes2["Beacon"] = "minecraft:beacon";
  MinecraftItemTypes2["Bed"] = "minecraft:bed";
  MinecraftItemTypes2["Bedrock"] = "minecraft:bedrock";
  MinecraftItemTypes2["BeeNest"] = "minecraft:bee_nest";
  MinecraftItemTypes2["BeeSpawnEgg"] = "minecraft:bee_spawn_egg";
  MinecraftItemTypes2["Beef"] = "minecraft:beef";
  MinecraftItemTypes2["Beehive"] = "minecraft:beehive";
  MinecraftItemTypes2["Beetroot"] = "minecraft:beetroot";
  MinecraftItemTypes2["BeetrootSeeds"] = "minecraft:beetroot_seeds";
  MinecraftItemTypes2["BeetrootSoup"] = "minecraft:beetroot_soup";
  MinecraftItemTypes2["Bell"] = "minecraft:bell";
  MinecraftItemTypes2["BigDripleaf"] = "minecraft:big_dripleaf";
  MinecraftItemTypes2["BirchBoat"] = "minecraft:birch_boat";
  MinecraftItemTypes2["BirchButton"] = "minecraft:birch_button";
  MinecraftItemTypes2["BirchChestBoat"] = "minecraft:birch_chest_boat";
  MinecraftItemTypes2["BirchDoor"] = "minecraft:birch_door";
  MinecraftItemTypes2["BirchFence"] = "minecraft:birch_fence";
  MinecraftItemTypes2["BirchFenceGate"] = "minecraft:birch_fence_gate";
  MinecraftItemTypes2["BirchHangingSign"] = "minecraft:birch_hanging_sign";
  MinecraftItemTypes2["BirchLeaves"] = "minecraft:birch_leaves";
  MinecraftItemTypes2["BirchLog"] = "minecraft:birch_log";
  MinecraftItemTypes2["BirchPlanks"] = "minecraft:birch_planks";
  MinecraftItemTypes2["BirchPressurePlate"] = "minecraft:birch_pressure_plate";
  MinecraftItemTypes2["BirchSapling"] = "minecraft:birch_sapling";
  MinecraftItemTypes2["BirchShelf"] = "minecraft:birch_shelf";
  MinecraftItemTypes2["BirchSign"] = "minecraft:birch_sign";
  MinecraftItemTypes2["BirchSlab"] = "minecraft:birch_slab";
  MinecraftItemTypes2["BirchStairs"] = "minecraft:birch_stairs";
  MinecraftItemTypes2["BirchTrapdoor"] = "minecraft:birch_trapdoor";
  MinecraftItemTypes2["BirchWood"] = "minecraft:birch_wood";
  MinecraftItemTypes2["BlackBundle"] = "minecraft:black_bundle";
  MinecraftItemTypes2["BlackCandle"] = "minecraft:black_candle";
  MinecraftItemTypes2["BlackCarpet"] = "minecraft:black_carpet";
  MinecraftItemTypes2["BlackConcrete"] = "minecraft:black_concrete";
  MinecraftItemTypes2["BlackConcretePowder"] = "minecraft:black_concrete_powder";
  MinecraftItemTypes2["BlackDye"] = "minecraft:black_dye";
  MinecraftItemTypes2["BlackGlazedTerracotta"] = "minecraft:black_glazed_terracotta";
  MinecraftItemTypes2["BlackHarness"] = "minecraft:black_harness";
  MinecraftItemTypes2["BlackShulkerBox"] = "minecraft:black_shulker_box";
  MinecraftItemTypes2["BlackStainedGlass"] = "minecraft:black_stained_glass";
  MinecraftItemTypes2["BlackStainedGlassPane"] = "minecraft:black_stained_glass_pane";
  MinecraftItemTypes2["BlackTerracotta"] = "minecraft:black_terracotta";
  MinecraftItemTypes2["BlackWool"] = "minecraft:black_wool";
  MinecraftItemTypes2["Blackstone"] = "minecraft:blackstone";
  MinecraftItemTypes2["BlackstoneSlab"] = "minecraft:blackstone_slab";
  MinecraftItemTypes2["BlackstoneStairs"] = "minecraft:blackstone_stairs";
  MinecraftItemTypes2["BlackstoneWall"] = "minecraft:blackstone_wall";
  MinecraftItemTypes2["BladePotterySherd"] = "minecraft:blade_pottery_sherd";
  MinecraftItemTypes2["BlastFurnace"] = "minecraft:blast_furnace";
  MinecraftItemTypes2["BlazePowder"] = "minecraft:blaze_powder";
  MinecraftItemTypes2["BlazeRod"] = "minecraft:blaze_rod";
  MinecraftItemTypes2["BlazeSpawnEgg"] = "minecraft:blaze_spawn_egg";
  MinecraftItemTypes2["BlueBundle"] = "minecraft:blue_bundle";
  MinecraftItemTypes2["BlueCandle"] = "minecraft:blue_candle";
  MinecraftItemTypes2["BlueCarpet"] = "minecraft:blue_carpet";
  MinecraftItemTypes2["BlueConcrete"] = "minecraft:blue_concrete";
  MinecraftItemTypes2["BlueConcretePowder"] = "minecraft:blue_concrete_powder";
  MinecraftItemTypes2["BlueDye"] = "minecraft:blue_dye";
  MinecraftItemTypes2["BlueEgg"] = "minecraft:blue_egg";
  MinecraftItemTypes2["BlueGlazedTerracotta"] = "minecraft:blue_glazed_terracotta";
  MinecraftItemTypes2["BlueHarness"] = "minecraft:blue_harness";
  MinecraftItemTypes2["BlueIce"] = "minecraft:blue_ice";
  MinecraftItemTypes2["BlueOrchid"] = "minecraft:blue_orchid";
  MinecraftItemTypes2["BlueShulkerBox"] = "minecraft:blue_shulker_box";
  MinecraftItemTypes2["BlueStainedGlass"] = "minecraft:blue_stained_glass";
  MinecraftItemTypes2["BlueStainedGlassPane"] = "minecraft:blue_stained_glass_pane";
  MinecraftItemTypes2["BlueTerracotta"] = "minecraft:blue_terracotta";
  MinecraftItemTypes2["BlueWool"] = "minecraft:blue_wool";
  MinecraftItemTypes2["BoggedSpawnEgg"] = "minecraft:bogged_spawn_egg";
  MinecraftItemTypes2["BoltArmorTrimSmithingTemplate"] = "minecraft:bolt_armor_trim_smithing_template";
  MinecraftItemTypes2["Bone"] = "minecraft:bone";
  MinecraftItemTypes2["BoneBlock"] = "minecraft:bone_block";
  MinecraftItemTypes2["BoneMeal"] = "minecraft:bone_meal";
  MinecraftItemTypes2["Book"] = "minecraft:book";
  MinecraftItemTypes2["Bookshelf"] = "minecraft:bookshelf";
  MinecraftItemTypes2["BorderBlock"] = "minecraft:border_block";
  MinecraftItemTypes2["BordureIndentedBannerPattern"] = "minecraft:bordure_indented_banner_pattern";
  MinecraftItemTypes2["Bow"] = "minecraft:bow";
  MinecraftItemTypes2["Bowl"] = "minecraft:bowl";
  MinecraftItemTypes2["BrainCoral"] = "minecraft:brain_coral";
  MinecraftItemTypes2["BrainCoralBlock"] = "minecraft:brain_coral_block";
  MinecraftItemTypes2["BrainCoralFan"] = "minecraft:brain_coral_fan";
  MinecraftItemTypes2["Bread"] = "minecraft:bread";
  MinecraftItemTypes2["BreezeRod"] = "minecraft:breeze_rod";
  MinecraftItemTypes2["BreezeSpawnEgg"] = "minecraft:breeze_spawn_egg";
  MinecraftItemTypes2["BrewerPotterySherd"] = "minecraft:brewer_pottery_sherd";
  MinecraftItemTypes2["BrewingStand"] = "minecraft:brewing_stand";
  MinecraftItemTypes2["Brick"] = "minecraft:brick";
  MinecraftItemTypes2["BrickBlock"] = "minecraft:brick_block";
  MinecraftItemTypes2["BrickSlab"] = "minecraft:brick_slab";
  MinecraftItemTypes2["BrickStairs"] = "minecraft:brick_stairs";
  MinecraftItemTypes2["BrickWall"] = "minecraft:brick_wall";
  MinecraftItemTypes2["BrownBundle"] = "minecraft:brown_bundle";
  MinecraftItemTypes2["BrownCandle"] = "minecraft:brown_candle";
  MinecraftItemTypes2["BrownCarpet"] = "minecraft:brown_carpet";
  MinecraftItemTypes2["BrownConcrete"] = "minecraft:brown_concrete";
  MinecraftItemTypes2["BrownConcretePowder"] = "minecraft:brown_concrete_powder";
  MinecraftItemTypes2["BrownDye"] = "minecraft:brown_dye";
  MinecraftItemTypes2["BrownEgg"] = "minecraft:brown_egg";
  MinecraftItemTypes2["BrownGlazedTerracotta"] = "minecraft:brown_glazed_terracotta";
  MinecraftItemTypes2["BrownHarness"] = "minecraft:brown_harness";
  MinecraftItemTypes2["BrownMushroom"] = "minecraft:brown_mushroom";
  MinecraftItemTypes2["BrownMushroomBlock"] = "minecraft:brown_mushroom_block";
  MinecraftItemTypes2["BrownShulkerBox"] = "minecraft:brown_shulker_box";
  MinecraftItemTypes2["BrownStainedGlass"] = "minecraft:brown_stained_glass";
  MinecraftItemTypes2["BrownStainedGlassPane"] = "minecraft:brown_stained_glass_pane";
  MinecraftItemTypes2["BrownTerracotta"] = "minecraft:brown_terracotta";
  MinecraftItemTypes2["BrownWool"] = "minecraft:brown_wool";
  MinecraftItemTypes2["Brush"] = "minecraft:brush";
  MinecraftItemTypes2["BubbleCoral"] = "minecraft:bubble_coral";
  MinecraftItemTypes2["BubbleCoralBlock"] = "minecraft:bubble_coral_block";
  MinecraftItemTypes2["BubbleCoralFan"] = "minecraft:bubble_coral_fan";
  MinecraftItemTypes2["Bucket"] = "minecraft:bucket";
  MinecraftItemTypes2["BuddingAmethyst"] = "minecraft:budding_amethyst";
  MinecraftItemTypes2["Bundle"] = "minecraft:bundle";
  MinecraftItemTypes2["BurnPotterySherd"] = "minecraft:burn_pottery_sherd";
  MinecraftItemTypes2["Bush"] = "minecraft:bush";
  MinecraftItemTypes2["Cactus"] = "minecraft:cactus";
  MinecraftItemTypes2["CactusFlower"] = "minecraft:cactus_flower";
  MinecraftItemTypes2["Cake"] = "minecraft:cake";
  MinecraftItemTypes2["Calcite"] = "minecraft:calcite";
  MinecraftItemTypes2["CalibratedSculkSensor"] = "minecraft:calibrated_sculk_sensor";
  MinecraftItemTypes2["CamelHuskSpawnEgg"] = "minecraft:camel_husk_spawn_egg";
  MinecraftItemTypes2["CamelSpawnEgg"] = "minecraft:camel_spawn_egg";
  MinecraftItemTypes2["Campfire"] = "minecraft:campfire";
  MinecraftItemTypes2["Candle"] = "minecraft:candle";
  MinecraftItemTypes2["Carrot"] = "minecraft:carrot";
  MinecraftItemTypes2["CarrotOnAStick"] = "minecraft:carrot_on_a_stick";
  MinecraftItemTypes2["CartographyTable"] = "minecraft:cartography_table";
  MinecraftItemTypes2["CarvedPumpkin"] = "minecraft:carved_pumpkin";
  MinecraftItemTypes2["CatSpawnEgg"] = "minecraft:cat_spawn_egg";
  MinecraftItemTypes2["Cauldron"] = "minecraft:cauldron";
  MinecraftItemTypes2["CaveSpiderSpawnEgg"] = "minecraft:cave_spider_spawn_egg";
  MinecraftItemTypes2["ChainCommandBlock"] = "minecraft:chain_command_block";
  MinecraftItemTypes2["ChainmailBoots"] = "minecraft:chainmail_boots";
  MinecraftItemTypes2["ChainmailChestplate"] = "minecraft:chainmail_chestplate";
  MinecraftItemTypes2["ChainmailHelmet"] = "minecraft:chainmail_helmet";
  MinecraftItemTypes2["ChainmailLeggings"] = "minecraft:chainmail_leggings";
  MinecraftItemTypes2["Charcoal"] = "minecraft:charcoal";
  MinecraftItemTypes2["CherryBoat"] = "minecraft:cherry_boat";
  MinecraftItemTypes2["CherryButton"] = "minecraft:cherry_button";
  MinecraftItemTypes2["CherryChestBoat"] = "minecraft:cherry_chest_boat";
  MinecraftItemTypes2["CherryDoor"] = "minecraft:cherry_door";
  MinecraftItemTypes2["CherryFence"] = "minecraft:cherry_fence";
  MinecraftItemTypes2["CherryFenceGate"] = "minecraft:cherry_fence_gate";
  MinecraftItemTypes2["CherryHangingSign"] = "minecraft:cherry_hanging_sign";
  MinecraftItemTypes2["CherryLeaves"] = "minecraft:cherry_leaves";
  MinecraftItemTypes2["CherryLog"] = "minecraft:cherry_log";
  MinecraftItemTypes2["CherryPlanks"] = "minecraft:cherry_planks";
  MinecraftItemTypes2["CherryPressurePlate"] = "minecraft:cherry_pressure_plate";
  MinecraftItemTypes2["CherrySapling"] = "minecraft:cherry_sapling";
  MinecraftItemTypes2["CherryShelf"] = "minecraft:cherry_shelf";
  MinecraftItemTypes2["CherrySign"] = "minecraft:cherry_sign";
  MinecraftItemTypes2["CherrySlab"] = "minecraft:cherry_slab";
  MinecraftItemTypes2["CherryStairs"] = "minecraft:cherry_stairs";
  MinecraftItemTypes2["CherryTrapdoor"] = "minecraft:cherry_trapdoor";
  MinecraftItemTypes2["CherryWood"] = "minecraft:cherry_wood";
  MinecraftItemTypes2["Chest"] = "minecraft:chest";
  MinecraftItemTypes2["ChestMinecart"] = "minecraft:chest_minecart";
  MinecraftItemTypes2["Chicken"] = "minecraft:chicken";
  MinecraftItemTypes2["ChickenSpawnEgg"] = "minecraft:chicken_spawn_egg";
  MinecraftItemTypes2["ChippedAnvil"] = "minecraft:chipped_anvil";
  MinecraftItemTypes2["ChiseledBookshelf"] = "minecraft:chiseled_bookshelf";
  MinecraftItemTypes2["ChiseledCinnabar"] = "minecraft:chiseled_cinnabar";
  MinecraftItemTypes2["ChiseledCopper"] = "minecraft:chiseled_copper";
  MinecraftItemTypes2["ChiseledDeepslate"] = "minecraft:chiseled_deepslate";
  MinecraftItemTypes2["ChiseledNetherBricks"] = "minecraft:chiseled_nether_bricks";
  MinecraftItemTypes2["ChiseledPolishedBlackstone"] = "minecraft:chiseled_polished_blackstone";
  MinecraftItemTypes2["ChiseledQuartzBlock"] = "minecraft:chiseled_quartz_block";
  MinecraftItemTypes2["ChiseledRedSandstone"] = "minecraft:chiseled_red_sandstone";
  MinecraftItemTypes2["ChiseledResinBricks"] = "minecraft:chiseled_resin_bricks";
  MinecraftItemTypes2["ChiseledSandstone"] = "minecraft:chiseled_sandstone";
  MinecraftItemTypes2["ChiseledStoneBricks"] = "minecraft:chiseled_stone_bricks";
  MinecraftItemTypes2["ChiseledSulfur"] = "minecraft:chiseled_sulfur";
  MinecraftItemTypes2["ChiseledTuff"] = "minecraft:chiseled_tuff";
  MinecraftItemTypes2["ChiseledTuffBricks"] = "minecraft:chiseled_tuff_bricks";
  MinecraftItemTypes2["ChorusFlower"] = "minecraft:chorus_flower";
  MinecraftItemTypes2["ChorusFruit"] = "minecraft:chorus_fruit";
  MinecraftItemTypes2["ChorusPlant"] = "minecraft:chorus_plant";
  MinecraftItemTypes2["Cinnabar"] = "minecraft:cinnabar";
  MinecraftItemTypes2["CinnabarBrickSlab"] = "minecraft:cinnabar_brick_slab";
  MinecraftItemTypes2["CinnabarBrickStairs"] = "minecraft:cinnabar_brick_stairs";
  MinecraftItemTypes2["CinnabarBrickWall"] = "minecraft:cinnabar_brick_wall";
  MinecraftItemTypes2["CinnabarBricks"] = "minecraft:cinnabar_bricks";
  MinecraftItemTypes2["CinnabarSlab"] = "minecraft:cinnabar_slab";
  MinecraftItemTypes2["CinnabarStairs"] = "minecraft:cinnabar_stairs";
  MinecraftItemTypes2["CinnabarWall"] = "minecraft:cinnabar_wall";
  MinecraftItemTypes2["Clay"] = "minecraft:clay";
  MinecraftItemTypes2["ClayBall"] = "minecraft:clay_ball";
  MinecraftItemTypes2["Clock"] = "minecraft:clock";
  MinecraftItemTypes2["ClosedEyeblossom"] = "minecraft:closed_eyeblossom";
  MinecraftItemTypes2["Coal"] = "minecraft:coal";
  MinecraftItemTypes2["CoalBlock"] = "minecraft:coal_block";
  MinecraftItemTypes2["CoalOre"] = "minecraft:coal_ore";
  MinecraftItemTypes2["CoarseDirt"] = "minecraft:coarse_dirt";
  MinecraftItemTypes2["CoastArmorTrimSmithingTemplate"] = "minecraft:coast_armor_trim_smithing_template";
  MinecraftItemTypes2["CobbledDeepslate"] = "minecraft:cobbled_deepslate";
  MinecraftItemTypes2["CobbledDeepslateSlab"] = "minecraft:cobbled_deepslate_slab";
  MinecraftItemTypes2["CobbledDeepslateStairs"] = "minecraft:cobbled_deepslate_stairs";
  MinecraftItemTypes2["CobbledDeepslateWall"] = "minecraft:cobbled_deepslate_wall";
  MinecraftItemTypes2["Cobblestone"] = "minecraft:cobblestone";
  MinecraftItemTypes2["CobblestoneSlab"] = "minecraft:cobblestone_slab";
  MinecraftItemTypes2["CobblestoneWall"] = "minecraft:cobblestone_wall";
  MinecraftItemTypes2["CocoaBeans"] = "minecraft:cocoa_beans";
  MinecraftItemTypes2["Cod"] = "minecraft:cod";
  MinecraftItemTypes2["CodBucket"] = "minecraft:cod_bucket";
  MinecraftItemTypes2["CodSpawnEgg"] = "minecraft:cod_spawn_egg";
  MinecraftItemTypes2["CommandBlock"] = "minecraft:command_block";
  MinecraftItemTypes2["CommandBlockMinecart"] = "minecraft:command_block_minecart";
  MinecraftItemTypes2["Comparator"] = "minecraft:comparator";
  MinecraftItemTypes2["Compass"] = "minecraft:compass";
  MinecraftItemTypes2["Composter"] = "minecraft:composter";
  MinecraftItemTypes2["Conduit"] = "minecraft:conduit";
  MinecraftItemTypes2["CookedBeef"] = "minecraft:cooked_beef";
  MinecraftItemTypes2["CookedChicken"] = "minecraft:cooked_chicken";
  MinecraftItemTypes2["CookedCod"] = "minecraft:cooked_cod";
  MinecraftItemTypes2["CookedMutton"] = "minecraft:cooked_mutton";
  MinecraftItemTypes2["CookedPorkchop"] = "minecraft:cooked_porkchop";
  MinecraftItemTypes2["CookedRabbit"] = "minecraft:cooked_rabbit";
  MinecraftItemTypes2["CookedSalmon"] = "minecraft:cooked_salmon";
  MinecraftItemTypes2["Cookie"] = "minecraft:cookie";
  MinecraftItemTypes2["CopperAxe"] = "minecraft:copper_axe";
  MinecraftItemTypes2["CopperBars"] = "minecraft:copper_bars";
  MinecraftItemTypes2["CopperBlock"] = "minecraft:copper_block";
  MinecraftItemTypes2["CopperBoots"] = "minecraft:copper_boots";
  MinecraftItemTypes2["CopperBulb"] = "minecraft:copper_bulb";
  MinecraftItemTypes2["CopperChain"] = "minecraft:copper_chain";
  MinecraftItemTypes2["CopperChest"] = "minecraft:copper_chest";
  MinecraftItemTypes2["CopperChestplate"] = "minecraft:copper_chestplate";
  MinecraftItemTypes2["CopperDoor"] = "minecraft:copper_door";
  MinecraftItemTypes2["CopperGolemSpawnEgg"] = "minecraft:copper_golem_spawn_egg";
  MinecraftItemTypes2["CopperGolemStatue"] = "minecraft:copper_golem_statue";
  MinecraftItemTypes2["CopperGrate"] = "minecraft:copper_grate";
  MinecraftItemTypes2["CopperHelmet"] = "minecraft:copper_helmet";
  MinecraftItemTypes2["CopperHoe"] = "minecraft:copper_hoe";
  MinecraftItemTypes2["CopperHorseArmor"] = "minecraft:copper_horse_armor";
  MinecraftItemTypes2["CopperIngot"] = "minecraft:copper_ingot";
  MinecraftItemTypes2["CopperLantern"] = "minecraft:copper_lantern";
  MinecraftItemTypes2["CopperLeggings"] = "minecraft:copper_leggings";
  MinecraftItemTypes2["CopperNautilusArmor"] = "minecraft:copper_nautilus_armor";
  MinecraftItemTypes2["CopperNugget"] = "minecraft:copper_nugget";
  MinecraftItemTypes2["CopperOre"] = "minecraft:copper_ore";
  MinecraftItemTypes2["CopperPickaxe"] = "minecraft:copper_pickaxe";
  MinecraftItemTypes2["CopperShovel"] = "minecraft:copper_shovel";
  MinecraftItemTypes2["CopperSpear"] = "minecraft:copper_spear";
  MinecraftItemTypes2["CopperSword"] = "minecraft:copper_sword";
  MinecraftItemTypes2["CopperTorch"] = "minecraft:copper_torch";
  MinecraftItemTypes2["CopperTrapdoor"] = "minecraft:copper_trapdoor";
  MinecraftItemTypes2["Cornflower"] = "minecraft:cornflower";
  MinecraftItemTypes2["CowSpawnEgg"] = "minecraft:cow_spawn_egg";
  MinecraftItemTypes2["CrackedDeepslateBricks"] = "minecraft:cracked_deepslate_bricks";
  MinecraftItemTypes2["CrackedDeepslateTiles"] = "minecraft:cracked_deepslate_tiles";
  MinecraftItemTypes2["CrackedNetherBricks"] = "minecraft:cracked_nether_bricks";
  MinecraftItemTypes2["CrackedPolishedBlackstoneBricks"] = "minecraft:cracked_polished_blackstone_bricks";
  MinecraftItemTypes2["CrackedStoneBricks"] = "minecraft:cracked_stone_bricks";
  MinecraftItemTypes2["Crafter"] = "minecraft:crafter";
  MinecraftItemTypes2["CraftingTable"] = "minecraft:crafting_table";
  MinecraftItemTypes2["CreakingHeart"] = "minecraft:creaking_heart";
  MinecraftItemTypes2["CreakingSpawnEgg"] = "minecraft:creaking_spawn_egg";
  MinecraftItemTypes2["CreeperBannerPattern"] = "minecraft:creeper_banner_pattern";
  MinecraftItemTypes2["CreeperHead"] = "minecraft:creeper_head";
  MinecraftItemTypes2["CreeperSpawnEgg"] = "minecraft:creeper_spawn_egg";
  MinecraftItemTypes2["CrimsonButton"] = "minecraft:crimson_button";
  MinecraftItemTypes2["CrimsonDoor"] = "minecraft:crimson_door";
  MinecraftItemTypes2["CrimsonFence"] = "minecraft:crimson_fence";
  MinecraftItemTypes2["CrimsonFenceGate"] = "minecraft:crimson_fence_gate";
  MinecraftItemTypes2["CrimsonFungus"] = "minecraft:crimson_fungus";
  MinecraftItemTypes2["CrimsonHangingSign"] = "minecraft:crimson_hanging_sign";
  MinecraftItemTypes2["CrimsonHyphae"] = "minecraft:crimson_hyphae";
  MinecraftItemTypes2["CrimsonNylium"] = "minecraft:crimson_nylium";
  MinecraftItemTypes2["CrimsonPlanks"] = "minecraft:crimson_planks";
  MinecraftItemTypes2["CrimsonPressurePlate"] = "minecraft:crimson_pressure_plate";
  MinecraftItemTypes2["CrimsonRoots"] = "minecraft:crimson_roots";
  MinecraftItemTypes2["CrimsonShelf"] = "minecraft:crimson_shelf";
  MinecraftItemTypes2["CrimsonSign"] = "minecraft:crimson_sign";
  MinecraftItemTypes2["CrimsonSlab"] = "minecraft:crimson_slab";
  MinecraftItemTypes2["CrimsonStairs"] = "minecraft:crimson_stairs";
  MinecraftItemTypes2["CrimsonStem"] = "minecraft:crimson_stem";
  MinecraftItemTypes2["CrimsonTrapdoor"] = "minecraft:crimson_trapdoor";
  MinecraftItemTypes2["Crossbow"] = "minecraft:crossbow";
  MinecraftItemTypes2["CryingObsidian"] = "minecraft:crying_obsidian";
  MinecraftItemTypes2["CutCopper"] = "minecraft:cut_copper";
  MinecraftItemTypes2["CutCopperSlab"] = "minecraft:cut_copper_slab";
  MinecraftItemTypes2["CutCopperStairs"] = "minecraft:cut_copper_stairs";
  MinecraftItemTypes2["CutRedSandstone"] = "minecraft:cut_red_sandstone";
  MinecraftItemTypes2["CutRedSandstoneSlab"] = "minecraft:cut_red_sandstone_slab";
  MinecraftItemTypes2["CutSandstone"] = "minecraft:cut_sandstone";
  MinecraftItemTypes2["CutSandstoneSlab"] = "minecraft:cut_sandstone_slab";
  MinecraftItemTypes2["CyanBundle"] = "minecraft:cyan_bundle";
  MinecraftItemTypes2["CyanCandle"] = "minecraft:cyan_candle";
  MinecraftItemTypes2["CyanCarpet"] = "minecraft:cyan_carpet";
  MinecraftItemTypes2["CyanConcrete"] = "minecraft:cyan_concrete";
  MinecraftItemTypes2["CyanConcretePowder"] = "minecraft:cyan_concrete_powder";
  MinecraftItemTypes2["CyanDye"] = "minecraft:cyan_dye";
  MinecraftItemTypes2["CyanGlazedTerracotta"] = "minecraft:cyan_glazed_terracotta";
  MinecraftItemTypes2["CyanHarness"] = "minecraft:cyan_harness";
  MinecraftItemTypes2["CyanShulkerBox"] = "minecraft:cyan_shulker_box";
  MinecraftItemTypes2["CyanStainedGlass"] = "minecraft:cyan_stained_glass";
  MinecraftItemTypes2["CyanStainedGlassPane"] = "minecraft:cyan_stained_glass_pane";
  MinecraftItemTypes2["CyanTerracotta"] = "minecraft:cyan_terracotta";
  MinecraftItemTypes2["CyanWool"] = "minecraft:cyan_wool";
  MinecraftItemTypes2["DamagedAnvil"] = "minecraft:damaged_anvil";
  MinecraftItemTypes2["Dandelion"] = "minecraft:dandelion";
  MinecraftItemTypes2["DangerPotterySherd"] = "minecraft:danger_pottery_sherd";
  MinecraftItemTypes2["DarkOakBoat"] = "minecraft:dark_oak_boat";
  MinecraftItemTypes2["DarkOakButton"] = "minecraft:dark_oak_button";
  MinecraftItemTypes2["DarkOakChestBoat"] = "minecraft:dark_oak_chest_boat";
  MinecraftItemTypes2["DarkOakDoor"] = "minecraft:dark_oak_door";
  MinecraftItemTypes2["DarkOakFence"] = "minecraft:dark_oak_fence";
  MinecraftItemTypes2["DarkOakFenceGate"] = "minecraft:dark_oak_fence_gate";
  MinecraftItemTypes2["DarkOakHangingSign"] = "minecraft:dark_oak_hanging_sign";
  MinecraftItemTypes2["DarkOakLeaves"] = "minecraft:dark_oak_leaves";
  MinecraftItemTypes2["DarkOakLog"] = "minecraft:dark_oak_log";
  MinecraftItemTypes2["DarkOakPlanks"] = "minecraft:dark_oak_planks";
  MinecraftItemTypes2["DarkOakPressurePlate"] = "minecraft:dark_oak_pressure_plate";
  MinecraftItemTypes2["DarkOakSapling"] = "minecraft:dark_oak_sapling";
  MinecraftItemTypes2["DarkOakShelf"] = "minecraft:dark_oak_shelf";
  MinecraftItemTypes2["DarkOakSign"] = "minecraft:dark_oak_sign";
  MinecraftItemTypes2["DarkOakSlab"] = "minecraft:dark_oak_slab";
  MinecraftItemTypes2["DarkOakStairs"] = "minecraft:dark_oak_stairs";
  MinecraftItemTypes2["DarkOakTrapdoor"] = "minecraft:dark_oak_trapdoor";
  MinecraftItemTypes2["DarkOakWood"] = "minecraft:dark_oak_wood";
  MinecraftItemTypes2["DarkPrismarine"] = "minecraft:dark_prismarine";
  MinecraftItemTypes2["DarkPrismarineSlab"] = "minecraft:dark_prismarine_slab";
  MinecraftItemTypes2["DarkPrismarineStairs"] = "minecraft:dark_prismarine_stairs";
  MinecraftItemTypes2["DaylightDetector"] = "minecraft:daylight_detector";
  MinecraftItemTypes2["DeadBrainCoral"] = "minecraft:dead_brain_coral";
  MinecraftItemTypes2["DeadBrainCoralBlock"] = "minecraft:dead_brain_coral_block";
  MinecraftItemTypes2["DeadBrainCoralFan"] = "minecraft:dead_brain_coral_fan";
  MinecraftItemTypes2["DeadBubbleCoral"] = "minecraft:dead_bubble_coral";
  MinecraftItemTypes2["DeadBubbleCoralBlock"] = "minecraft:dead_bubble_coral_block";
  MinecraftItemTypes2["DeadBubbleCoralFan"] = "minecraft:dead_bubble_coral_fan";
  MinecraftItemTypes2["DeadFireCoral"] = "minecraft:dead_fire_coral";
  MinecraftItemTypes2["DeadFireCoralBlock"] = "minecraft:dead_fire_coral_block";
  MinecraftItemTypes2["DeadFireCoralFan"] = "minecraft:dead_fire_coral_fan";
  MinecraftItemTypes2["DeadHornCoral"] = "minecraft:dead_horn_coral";
  MinecraftItemTypes2["DeadHornCoralBlock"] = "minecraft:dead_horn_coral_block";
  MinecraftItemTypes2["DeadHornCoralFan"] = "minecraft:dead_horn_coral_fan";
  MinecraftItemTypes2["DeadTubeCoral"] = "minecraft:dead_tube_coral";
  MinecraftItemTypes2["DeadTubeCoralBlock"] = "minecraft:dead_tube_coral_block";
  MinecraftItemTypes2["DeadTubeCoralFan"] = "minecraft:dead_tube_coral_fan";
  MinecraftItemTypes2["Deadbush"] = "minecraft:deadbush";
  MinecraftItemTypes2["DecoratedPot"] = "minecraft:decorated_pot";
  MinecraftItemTypes2["Deepslate"] = "minecraft:deepslate";
  MinecraftItemTypes2["DeepslateBrickSlab"] = "minecraft:deepslate_brick_slab";
  MinecraftItemTypes2["DeepslateBrickStairs"] = "minecraft:deepslate_brick_stairs";
  MinecraftItemTypes2["DeepslateBrickWall"] = "minecraft:deepslate_brick_wall";
  MinecraftItemTypes2["DeepslateBricks"] = "minecraft:deepslate_bricks";
  MinecraftItemTypes2["DeepslateCoalOre"] = "minecraft:deepslate_coal_ore";
  MinecraftItemTypes2["DeepslateCopperOre"] = "minecraft:deepslate_copper_ore";
  MinecraftItemTypes2["DeepslateDiamondOre"] = "minecraft:deepslate_diamond_ore";
  MinecraftItemTypes2["DeepslateEmeraldOre"] = "minecraft:deepslate_emerald_ore";
  MinecraftItemTypes2["DeepslateGoldOre"] = "minecraft:deepslate_gold_ore";
  MinecraftItemTypes2["DeepslateIronOre"] = "minecraft:deepslate_iron_ore";
  MinecraftItemTypes2["DeepslateLapisOre"] = "minecraft:deepslate_lapis_ore";
  MinecraftItemTypes2["DeepslateRedstoneOre"] = "minecraft:deepslate_redstone_ore";
  MinecraftItemTypes2["DeepslateTileSlab"] = "minecraft:deepslate_tile_slab";
  MinecraftItemTypes2["DeepslateTileStairs"] = "minecraft:deepslate_tile_stairs";
  MinecraftItemTypes2["DeepslateTileWall"] = "minecraft:deepslate_tile_wall";
  MinecraftItemTypes2["DeepslateTiles"] = "minecraft:deepslate_tiles";
  MinecraftItemTypes2["Deny"] = "minecraft:deny";
  MinecraftItemTypes2["DetectorRail"] = "minecraft:detector_rail";
  MinecraftItemTypes2["Diamond"] = "minecraft:diamond";
  MinecraftItemTypes2["DiamondAxe"] = "minecraft:diamond_axe";
  MinecraftItemTypes2["DiamondBlock"] = "minecraft:diamond_block";
  MinecraftItemTypes2["DiamondBoots"] = "minecraft:diamond_boots";
  MinecraftItemTypes2["DiamondChestplate"] = "minecraft:diamond_chestplate";
  MinecraftItemTypes2["DiamondHelmet"] = "minecraft:diamond_helmet";
  MinecraftItemTypes2["DiamondHoe"] = "minecraft:diamond_hoe";
  MinecraftItemTypes2["DiamondHorseArmor"] = "minecraft:diamond_horse_armor";
  MinecraftItemTypes2["DiamondLeggings"] = "minecraft:diamond_leggings";
  MinecraftItemTypes2["DiamondNautilusArmor"] = "minecraft:diamond_nautilus_armor";
  MinecraftItemTypes2["DiamondOre"] = "minecraft:diamond_ore";
  MinecraftItemTypes2["DiamondPickaxe"] = "minecraft:diamond_pickaxe";
  MinecraftItemTypes2["DiamondShovel"] = "minecraft:diamond_shovel";
  MinecraftItemTypes2["DiamondSpear"] = "minecraft:diamond_spear";
  MinecraftItemTypes2["DiamondSword"] = "minecraft:diamond_sword";
  MinecraftItemTypes2["Diorite"] = "minecraft:diorite";
  MinecraftItemTypes2["DioriteSlab"] = "minecraft:diorite_slab";
  MinecraftItemTypes2["DioriteStairs"] = "minecraft:diorite_stairs";
  MinecraftItemTypes2["DioriteWall"] = "minecraft:diorite_wall";
  MinecraftItemTypes2["Dirt"] = "minecraft:dirt";
  MinecraftItemTypes2["DirtWithRoots"] = "minecraft:dirt_with_roots";
  MinecraftItemTypes2["DiscFragment5"] = "minecraft:disc_fragment_5";
  MinecraftItemTypes2["Dispenser"] = "minecraft:dispenser";
  MinecraftItemTypes2["DolphinSpawnEgg"] = "minecraft:dolphin_spawn_egg";
  MinecraftItemTypes2["DonkeySpawnEgg"] = "minecraft:donkey_spawn_egg";
  MinecraftItemTypes2["DragonBreath"] = "minecraft:dragon_breath";
  MinecraftItemTypes2["DragonEgg"] = "minecraft:dragon_egg";
  MinecraftItemTypes2["DragonHead"] = "minecraft:dragon_head";
  MinecraftItemTypes2["DriedGhast"] = "minecraft:dried_ghast";
  MinecraftItemTypes2["DriedKelp"] = "minecraft:dried_kelp";
  MinecraftItemTypes2["DriedKelpBlock"] = "minecraft:dried_kelp_block";
  MinecraftItemTypes2["DripstoneBlock"] = "minecraft:dripstone_block";
  MinecraftItemTypes2["Dropper"] = "minecraft:dropper";
  MinecraftItemTypes2["DrownedSpawnEgg"] = "minecraft:drowned_spawn_egg";
  MinecraftItemTypes2["DuneArmorTrimSmithingTemplate"] = "minecraft:dune_armor_trim_smithing_template";
  MinecraftItemTypes2["EchoShard"] = "minecraft:echo_shard";
  MinecraftItemTypes2["Egg"] = "minecraft:egg";
  MinecraftItemTypes2["ElderGuardianSpawnEgg"] = "minecraft:elder_guardian_spawn_egg";
  MinecraftItemTypes2["Elytra"] = "minecraft:elytra";
  MinecraftItemTypes2["Emerald"] = "minecraft:emerald";
  MinecraftItemTypes2["EmeraldBlock"] = "minecraft:emerald_block";
  MinecraftItemTypes2["EmeraldOre"] = "minecraft:emerald_ore";
  MinecraftItemTypes2["EmptyMap"] = "minecraft:empty_map";
  MinecraftItemTypes2["EnchantedBook"] = "minecraft:enchanted_book";
  MinecraftItemTypes2["EnchantedGoldenApple"] = "minecraft:enchanted_golden_apple";
  MinecraftItemTypes2["EnchantingTable"] = "minecraft:enchanting_table";
  MinecraftItemTypes2["EndBrickStairs"] = "minecraft:end_brick_stairs";
  MinecraftItemTypes2["EndBricks"] = "minecraft:end_bricks";
  MinecraftItemTypes2["EndCrystal"] = "minecraft:end_crystal";
  MinecraftItemTypes2["EndPortalFrame"] = "minecraft:end_portal_frame";
  MinecraftItemTypes2["EndRod"] = "minecraft:end_rod";
  MinecraftItemTypes2["EndStone"] = "minecraft:end_stone";
  MinecraftItemTypes2["EndStoneBrickSlab"] = "minecraft:end_stone_brick_slab";
  MinecraftItemTypes2["EndStoneBrickWall"] = "minecraft:end_stone_brick_wall";
  MinecraftItemTypes2["EnderChest"] = "minecraft:ender_chest";
  MinecraftItemTypes2["EnderDragonSpawnEgg"] = "minecraft:ender_dragon_spawn_egg";
  MinecraftItemTypes2["EnderEye"] = "minecraft:ender_eye";
  MinecraftItemTypes2["EnderPearl"] = "minecraft:ender_pearl";
  MinecraftItemTypes2["EndermanSpawnEgg"] = "minecraft:enderman_spawn_egg";
  MinecraftItemTypes2["EndermiteSpawnEgg"] = "minecraft:endermite_spawn_egg";
  MinecraftItemTypes2["EvokerSpawnEgg"] = "minecraft:evoker_spawn_egg";
  MinecraftItemTypes2["ExperienceBottle"] = "minecraft:experience_bottle";
  MinecraftItemTypes2["ExplorerPotterySherd"] = "minecraft:explorer_pottery_sherd";
  MinecraftItemTypes2["ExposedChiseledCopper"] = "minecraft:exposed_chiseled_copper";
  MinecraftItemTypes2["ExposedCopper"] = "minecraft:exposed_copper";
  MinecraftItemTypes2["ExposedCopperBars"] = "minecraft:exposed_copper_bars";
  MinecraftItemTypes2["ExposedCopperBulb"] = "minecraft:exposed_copper_bulb";
  MinecraftItemTypes2["ExposedCopperChain"] = "minecraft:exposed_copper_chain";
  MinecraftItemTypes2["ExposedCopperChest"] = "minecraft:exposed_copper_chest";
  MinecraftItemTypes2["ExposedCopperDoor"] = "minecraft:exposed_copper_door";
  MinecraftItemTypes2["ExposedCopperGolemStatue"] = "minecraft:exposed_copper_golem_statue";
  MinecraftItemTypes2["ExposedCopperGrate"] = "minecraft:exposed_copper_grate";
  MinecraftItemTypes2["ExposedCopperLantern"] = "minecraft:exposed_copper_lantern";
  MinecraftItemTypes2["ExposedCopperTrapdoor"] = "minecraft:exposed_copper_trapdoor";
  MinecraftItemTypes2["ExposedCutCopper"] = "minecraft:exposed_cut_copper";
  MinecraftItemTypes2["ExposedCutCopperSlab"] = "minecraft:exposed_cut_copper_slab";
  MinecraftItemTypes2["ExposedCutCopperStairs"] = "minecraft:exposed_cut_copper_stairs";
  MinecraftItemTypes2["ExposedLightningRod"] = "minecraft:exposed_lightning_rod";
  MinecraftItemTypes2["EyeArmorTrimSmithingTemplate"] = "minecraft:eye_armor_trim_smithing_template";
  MinecraftItemTypes2["Farmland"] = "minecraft:farmland";
  MinecraftItemTypes2["Feather"] = "minecraft:feather";
  MinecraftItemTypes2["FenceGate"] = "minecraft:fence_gate";
  MinecraftItemTypes2["FermentedSpiderEye"] = "minecraft:fermented_spider_eye";
  MinecraftItemTypes2["Fern"] = "minecraft:fern";
  MinecraftItemTypes2["FieldMasonedBannerPattern"] = "minecraft:field_masoned_banner_pattern";
  MinecraftItemTypes2["FilledMap"] = "minecraft:filled_map";
  MinecraftItemTypes2["FireCharge"] = "minecraft:fire_charge";
  MinecraftItemTypes2["FireCoral"] = "minecraft:fire_coral";
  MinecraftItemTypes2["FireCoralBlock"] = "minecraft:fire_coral_block";
  MinecraftItemTypes2["FireCoralFan"] = "minecraft:fire_coral_fan";
  MinecraftItemTypes2["FireflyBush"] = "minecraft:firefly_bush";
  MinecraftItemTypes2["FireworkRocket"] = "minecraft:firework_rocket";
  MinecraftItemTypes2["FireworkStar"] = "minecraft:firework_star";
  MinecraftItemTypes2["FishingRod"] = "minecraft:fishing_rod";
  MinecraftItemTypes2["FletchingTable"] = "minecraft:fletching_table";
  MinecraftItemTypes2["Flint"] = "minecraft:flint";
  MinecraftItemTypes2["FlintAndSteel"] = "minecraft:flint_and_steel";
  MinecraftItemTypes2["FlowArmorTrimSmithingTemplate"] = "minecraft:flow_armor_trim_smithing_template";
  MinecraftItemTypes2["FlowBannerPattern"] = "minecraft:flow_banner_pattern";
  MinecraftItemTypes2["FlowPotterySherd"] = "minecraft:flow_pottery_sherd";
  MinecraftItemTypes2["FlowerBannerPattern"] = "minecraft:flower_banner_pattern";
  MinecraftItemTypes2["FlowerPot"] = "minecraft:flower_pot";
  MinecraftItemTypes2["FloweringAzalea"] = "minecraft:flowering_azalea";
  MinecraftItemTypes2["FoxSpawnEgg"] = "minecraft:fox_spawn_egg";
  MinecraftItemTypes2["Frame"] = "minecraft:frame";
  MinecraftItemTypes2["FriendPotterySherd"] = "minecraft:friend_pottery_sherd";
  MinecraftItemTypes2["FrogSpawn"] = "minecraft:frog_spawn";
  MinecraftItemTypes2["FrogSpawnEgg"] = "minecraft:frog_spawn_egg";
  MinecraftItemTypes2["FrostedIce"] = "minecraft:frosted_ice";
  MinecraftItemTypes2["Furnace"] = "minecraft:furnace";
  MinecraftItemTypes2["GhastSpawnEgg"] = "minecraft:ghast_spawn_egg";
  MinecraftItemTypes2["GhastTear"] = "minecraft:ghast_tear";
  MinecraftItemTypes2["GildedBlackstone"] = "minecraft:gilded_blackstone";
  MinecraftItemTypes2["Glass"] = "minecraft:glass";
  MinecraftItemTypes2["GlassBottle"] = "minecraft:glass_bottle";
  MinecraftItemTypes2["GlassPane"] = "minecraft:glass_pane";
  MinecraftItemTypes2["GlisteringMelonSlice"] = "minecraft:glistering_melon_slice";
  MinecraftItemTypes2["GlobeBannerPattern"] = "minecraft:globe_banner_pattern";
  MinecraftItemTypes2["GlowBerries"] = "minecraft:glow_berries";
  MinecraftItemTypes2["GlowFrame"] = "minecraft:glow_frame";
  MinecraftItemTypes2["GlowInkSac"] = "minecraft:glow_ink_sac";
  MinecraftItemTypes2["GlowLichen"] = "minecraft:glow_lichen";
  MinecraftItemTypes2["GlowSquidSpawnEgg"] = "minecraft:glow_squid_spawn_egg";
  MinecraftItemTypes2["Glowstone"] = "minecraft:glowstone";
  MinecraftItemTypes2["GlowstoneDust"] = "minecraft:glowstone_dust";
  MinecraftItemTypes2["GoatHorn"] = "minecraft:goat_horn";
  MinecraftItemTypes2["GoatSpawnEgg"] = "minecraft:goat_spawn_egg";
  MinecraftItemTypes2["GoldBlock"] = "minecraft:gold_block";
  MinecraftItemTypes2["GoldIngot"] = "minecraft:gold_ingot";
  MinecraftItemTypes2["GoldNugget"] = "minecraft:gold_nugget";
  MinecraftItemTypes2["GoldOre"] = "minecraft:gold_ore";
  MinecraftItemTypes2["GoldenApple"] = "minecraft:golden_apple";
  MinecraftItemTypes2["GoldenAxe"] = "minecraft:golden_axe";
  MinecraftItemTypes2["GoldenBoots"] = "minecraft:golden_boots";
  MinecraftItemTypes2["GoldenCarrot"] = "minecraft:golden_carrot";
  MinecraftItemTypes2["GoldenChestplate"] = "minecraft:golden_chestplate";
  MinecraftItemTypes2["GoldenDandelion"] = "minecraft:golden_dandelion";
  MinecraftItemTypes2["GoldenHelmet"] = "minecraft:golden_helmet";
  MinecraftItemTypes2["GoldenHoe"] = "minecraft:golden_hoe";
  MinecraftItemTypes2["GoldenHorseArmor"] = "minecraft:golden_horse_armor";
  MinecraftItemTypes2["GoldenLeggings"] = "minecraft:golden_leggings";
  MinecraftItemTypes2["GoldenNautilusArmor"] = "minecraft:golden_nautilus_armor";
  MinecraftItemTypes2["GoldenPickaxe"] = "minecraft:golden_pickaxe";
  MinecraftItemTypes2["GoldenRail"] = "minecraft:golden_rail";
  MinecraftItemTypes2["GoldenShovel"] = "minecraft:golden_shovel";
  MinecraftItemTypes2["GoldenSpear"] = "minecraft:golden_spear";
  MinecraftItemTypes2["GoldenSword"] = "minecraft:golden_sword";
  MinecraftItemTypes2["Granite"] = "minecraft:granite";
  MinecraftItemTypes2["GraniteSlab"] = "minecraft:granite_slab";
  MinecraftItemTypes2["GraniteStairs"] = "minecraft:granite_stairs";
  MinecraftItemTypes2["GraniteWall"] = "minecraft:granite_wall";
  MinecraftItemTypes2["GrassBlock"] = "minecraft:grass_block";
  MinecraftItemTypes2["GrassPath"] = "minecraft:grass_path";
  MinecraftItemTypes2["Gravel"] = "minecraft:gravel";
  MinecraftItemTypes2["GrayBundle"] = "minecraft:gray_bundle";
  MinecraftItemTypes2["GrayCandle"] = "minecraft:gray_candle";
  MinecraftItemTypes2["GrayCarpet"] = "minecraft:gray_carpet";
  MinecraftItemTypes2["GrayConcrete"] = "minecraft:gray_concrete";
  MinecraftItemTypes2["GrayConcretePowder"] = "minecraft:gray_concrete_powder";
  MinecraftItemTypes2["GrayDye"] = "minecraft:gray_dye";
  MinecraftItemTypes2["GrayGlazedTerracotta"] = "minecraft:gray_glazed_terracotta";
  MinecraftItemTypes2["GrayHarness"] = "minecraft:gray_harness";
  MinecraftItemTypes2["GrayShulkerBox"] = "minecraft:gray_shulker_box";
  MinecraftItemTypes2["GrayStainedGlass"] = "minecraft:gray_stained_glass";
  MinecraftItemTypes2["GrayStainedGlassPane"] = "minecraft:gray_stained_glass_pane";
  MinecraftItemTypes2["GrayTerracotta"] = "minecraft:gray_terracotta";
  MinecraftItemTypes2["GrayWool"] = "minecraft:gray_wool";
  MinecraftItemTypes2["GreenBundle"] = "minecraft:green_bundle";
  MinecraftItemTypes2["GreenCandle"] = "minecraft:green_candle";
  MinecraftItemTypes2["GreenCarpet"] = "minecraft:green_carpet";
  MinecraftItemTypes2["GreenConcrete"] = "minecraft:green_concrete";
  MinecraftItemTypes2["GreenConcretePowder"] = "minecraft:green_concrete_powder";
  MinecraftItemTypes2["GreenDye"] = "minecraft:green_dye";
  MinecraftItemTypes2["GreenGlazedTerracotta"] = "minecraft:green_glazed_terracotta";
  MinecraftItemTypes2["GreenHarness"] = "minecraft:green_harness";
  MinecraftItemTypes2["GreenShulkerBox"] = "minecraft:green_shulker_box";
  MinecraftItemTypes2["GreenStainedGlass"] = "minecraft:green_stained_glass";
  MinecraftItemTypes2["GreenStainedGlassPane"] = "minecraft:green_stained_glass_pane";
  MinecraftItemTypes2["GreenTerracotta"] = "minecraft:green_terracotta";
  MinecraftItemTypes2["GreenWool"] = "minecraft:green_wool";
  MinecraftItemTypes2["Grindstone"] = "minecraft:grindstone";
  MinecraftItemTypes2["GuardianSpawnEgg"] = "minecraft:guardian_spawn_egg";
  MinecraftItemTypes2["Gunpowder"] = "minecraft:gunpowder";
  MinecraftItemTypes2["GusterBannerPattern"] = "minecraft:guster_banner_pattern";
  MinecraftItemTypes2["GusterPotterySherd"] = "minecraft:guster_pottery_sherd";
  MinecraftItemTypes2["HangingRoots"] = "minecraft:hanging_roots";
  MinecraftItemTypes2["HappyGhastSpawnEgg"] = "minecraft:happy_ghast_spawn_egg";
  MinecraftItemTypes2["HardenedClay"] = "minecraft:hardened_clay";
  MinecraftItemTypes2["HayBlock"] = "minecraft:hay_block";
  MinecraftItemTypes2["HeartOfTheSea"] = "minecraft:heart_of_the_sea";
  MinecraftItemTypes2["HeartPotterySherd"] = "minecraft:heart_pottery_sherd";
  MinecraftItemTypes2["HeartbreakPotterySherd"] = "minecraft:heartbreak_pottery_sherd";
  MinecraftItemTypes2["HeavyCore"] = "minecraft:heavy_core";
  MinecraftItemTypes2["HeavyWeightedPressurePlate"] = "minecraft:heavy_weighted_pressure_plate";
  MinecraftItemTypes2["HoglinSpawnEgg"] = "minecraft:hoglin_spawn_egg";
  MinecraftItemTypes2["HoneyBlock"] = "minecraft:honey_block";
  MinecraftItemTypes2["HoneyBottle"] = "minecraft:honey_bottle";
  MinecraftItemTypes2["Honeycomb"] = "minecraft:honeycomb";
  MinecraftItemTypes2["HoneycombBlock"] = "minecraft:honeycomb_block";
  MinecraftItemTypes2["Hopper"] = "minecraft:hopper";
  MinecraftItemTypes2["HopperMinecart"] = "minecraft:hopper_minecart";
  MinecraftItemTypes2["HornCoral"] = "minecraft:horn_coral";
  MinecraftItemTypes2["HornCoralBlock"] = "minecraft:horn_coral_block";
  MinecraftItemTypes2["HornCoralFan"] = "minecraft:horn_coral_fan";
  MinecraftItemTypes2["HorseSpawnEgg"] = "minecraft:horse_spawn_egg";
  MinecraftItemTypes2["HostArmorTrimSmithingTemplate"] = "minecraft:host_armor_trim_smithing_template";
  MinecraftItemTypes2["HowlPotterySherd"] = "minecraft:howl_pottery_sherd";
  MinecraftItemTypes2["HuskSpawnEgg"] = "minecraft:husk_spawn_egg";
  MinecraftItemTypes2["Ice"] = "minecraft:ice";
  MinecraftItemTypes2["InfestedChiseledStoneBricks"] = "minecraft:infested_chiseled_stone_bricks";
  MinecraftItemTypes2["InfestedCobblestone"] = "minecraft:infested_cobblestone";
  MinecraftItemTypes2["InfestedCrackedStoneBricks"] = "minecraft:infested_cracked_stone_bricks";
  MinecraftItemTypes2["InfestedDeepslate"] = "minecraft:infested_deepslate";
  MinecraftItemTypes2["InfestedMossyStoneBricks"] = "minecraft:infested_mossy_stone_bricks";
  MinecraftItemTypes2["InfestedStone"] = "minecraft:infested_stone";
  MinecraftItemTypes2["InfestedStoneBricks"] = "minecraft:infested_stone_bricks";
  MinecraftItemTypes2["InkSac"] = "minecraft:ink_sac";
  MinecraftItemTypes2["IronAxe"] = "minecraft:iron_axe";
  MinecraftItemTypes2["IronBars"] = "minecraft:iron_bars";
  MinecraftItemTypes2["IronBlock"] = "minecraft:iron_block";
  MinecraftItemTypes2["IronBoots"] = "minecraft:iron_boots";
  MinecraftItemTypes2["IronChain"] = "minecraft:iron_chain";
  MinecraftItemTypes2["IronChestplate"] = "minecraft:iron_chestplate";
  MinecraftItemTypes2["IronDoor"] = "minecraft:iron_door";
  MinecraftItemTypes2["IronGolemSpawnEgg"] = "minecraft:iron_golem_spawn_egg";
  MinecraftItemTypes2["IronHelmet"] = "minecraft:iron_helmet";
  MinecraftItemTypes2["IronHoe"] = "minecraft:iron_hoe";
  MinecraftItemTypes2["IronHorseArmor"] = "minecraft:iron_horse_armor";
  MinecraftItemTypes2["IronIngot"] = "minecraft:iron_ingot";
  MinecraftItemTypes2["IronLeggings"] = "minecraft:iron_leggings";
  MinecraftItemTypes2["IronNautilusArmor"] = "minecraft:iron_nautilus_armor";
  MinecraftItemTypes2["IronNugget"] = "minecraft:iron_nugget";
  MinecraftItemTypes2["IronOre"] = "minecraft:iron_ore";
  MinecraftItemTypes2["IronPickaxe"] = "minecraft:iron_pickaxe";
  MinecraftItemTypes2["IronShovel"] = "minecraft:iron_shovel";
  MinecraftItemTypes2["IronSpear"] = "minecraft:iron_spear";
  MinecraftItemTypes2["IronSword"] = "minecraft:iron_sword";
  MinecraftItemTypes2["IronTrapdoor"] = "minecraft:iron_trapdoor";
  MinecraftItemTypes2["Jigsaw"] = "minecraft:jigsaw";
  MinecraftItemTypes2["Jukebox"] = "minecraft:jukebox";
  MinecraftItemTypes2["JungleBoat"] = "minecraft:jungle_boat";
  MinecraftItemTypes2["JungleButton"] = "minecraft:jungle_button";
  MinecraftItemTypes2["JungleChestBoat"] = "minecraft:jungle_chest_boat";
  MinecraftItemTypes2["JungleDoor"] = "minecraft:jungle_door";
  MinecraftItemTypes2["JungleFence"] = "minecraft:jungle_fence";
  MinecraftItemTypes2["JungleFenceGate"] = "minecraft:jungle_fence_gate";
  MinecraftItemTypes2["JungleHangingSign"] = "minecraft:jungle_hanging_sign";
  MinecraftItemTypes2["JungleLeaves"] = "minecraft:jungle_leaves";
  MinecraftItemTypes2["JungleLog"] = "minecraft:jungle_log";
  MinecraftItemTypes2["JunglePlanks"] = "minecraft:jungle_planks";
  MinecraftItemTypes2["JunglePressurePlate"] = "minecraft:jungle_pressure_plate";
  MinecraftItemTypes2["JungleSapling"] = "minecraft:jungle_sapling";
  MinecraftItemTypes2["JungleShelf"] = "minecraft:jungle_shelf";
  MinecraftItemTypes2["JungleSign"] = "minecraft:jungle_sign";
  MinecraftItemTypes2["JungleSlab"] = "minecraft:jungle_slab";
  MinecraftItemTypes2["JungleStairs"] = "minecraft:jungle_stairs";
  MinecraftItemTypes2["JungleTrapdoor"] = "minecraft:jungle_trapdoor";
  MinecraftItemTypes2["JungleWood"] = "minecraft:jungle_wood";
  MinecraftItemTypes2["Kelp"] = "minecraft:kelp";
  MinecraftItemTypes2["Ladder"] = "minecraft:ladder";
  MinecraftItemTypes2["Lantern"] = "minecraft:lantern";
  MinecraftItemTypes2["LapisBlock"] = "minecraft:lapis_block";
  MinecraftItemTypes2["LapisLazuli"] = "minecraft:lapis_lazuli";
  MinecraftItemTypes2["LapisOre"] = "minecraft:lapis_ore";
  MinecraftItemTypes2["LargeAmethystBud"] = "minecraft:large_amethyst_bud";
  MinecraftItemTypes2["LargeFern"] = "minecraft:large_fern";
  MinecraftItemTypes2["LavaBucket"] = "minecraft:lava_bucket";
  MinecraftItemTypes2["Lead"] = "minecraft:lead";
  MinecraftItemTypes2["LeafLitter"] = "minecraft:leaf_litter";
  MinecraftItemTypes2["Leather"] = "minecraft:leather";
  MinecraftItemTypes2["LeatherBoots"] = "minecraft:leather_boots";
  MinecraftItemTypes2["LeatherChestplate"] = "minecraft:leather_chestplate";
  MinecraftItemTypes2["LeatherHelmet"] = "minecraft:leather_helmet";
  MinecraftItemTypes2["LeatherHorseArmor"] = "minecraft:leather_horse_armor";
  MinecraftItemTypes2["LeatherLeggings"] = "minecraft:leather_leggings";
  MinecraftItemTypes2["Lectern"] = "minecraft:lectern";
  MinecraftItemTypes2["Lever"] = "minecraft:lever";
  MinecraftItemTypes2["LightBlock0"] = "minecraft:light_block_0";
  MinecraftItemTypes2["LightBlock1"] = "minecraft:light_block_1";
  MinecraftItemTypes2["LightBlock10"] = "minecraft:light_block_10";
  MinecraftItemTypes2["LightBlock11"] = "minecraft:light_block_11";
  MinecraftItemTypes2["LightBlock12"] = "minecraft:light_block_12";
  MinecraftItemTypes2["LightBlock13"] = "minecraft:light_block_13";
  MinecraftItemTypes2["LightBlock14"] = "minecraft:light_block_14";
  MinecraftItemTypes2["LightBlock15"] = "minecraft:light_block_15";
  MinecraftItemTypes2["LightBlock2"] = "minecraft:light_block_2";
  MinecraftItemTypes2["LightBlock3"] = "minecraft:light_block_3";
  MinecraftItemTypes2["LightBlock4"] = "minecraft:light_block_4";
  MinecraftItemTypes2["LightBlock5"] = "minecraft:light_block_5";
  MinecraftItemTypes2["LightBlock6"] = "minecraft:light_block_6";
  MinecraftItemTypes2["LightBlock7"] = "minecraft:light_block_7";
  MinecraftItemTypes2["LightBlock8"] = "minecraft:light_block_8";
  MinecraftItemTypes2["LightBlock9"] = "minecraft:light_block_9";
  MinecraftItemTypes2["LightBlueBundle"] = "minecraft:light_blue_bundle";
  MinecraftItemTypes2["LightBlueCandle"] = "minecraft:light_blue_candle";
  MinecraftItemTypes2["LightBlueCarpet"] = "minecraft:light_blue_carpet";
  MinecraftItemTypes2["LightBlueConcrete"] = "minecraft:light_blue_concrete";
  MinecraftItemTypes2["LightBlueConcretePowder"] = "minecraft:light_blue_concrete_powder";
  MinecraftItemTypes2["LightBlueDye"] = "minecraft:light_blue_dye";
  MinecraftItemTypes2["LightBlueGlazedTerracotta"] = "minecraft:light_blue_glazed_terracotta";
  MinecraftItemTypes2["LightBlueHarness"] = "minecraft:light_blue_harness";
  MinecraftItemTypes2["LightBlueShulkerBox"] = "minecraft:light_blue_shulker_box";
  MinecraftItemTypes2["LightBlueStainedGlass"] = "minecraft:light_blue_stained_glass";
  MinecraftItemTypes2["LightBlueStainedGlassPane"] = "minecraft:light_blue_stained_glass_pane";
  MinecraftItemTypes2["LightBlueTerracotta"] = "minecraft:light_blue_terracotta";
  MinecraftItemTypes2["LightBlueWool"] = "minecraft:light_blue_wool";
  MinecraftItemTypes2["LightGrayBundle"] = "minecraft:light_gray_bundle";
  MinecraftItemTypes2["LightGrayCandle"] = "minecraft:light_gray_candle";
  MinecraftItemTypes2["LightGrayCarpet"] = "minecraft:light_gray_carpet";
  MinecraftItemTypes2["LightGrayConcrete"] = "minecraft:light_gray_concrete";
  MinecraftItemTypes2["LightGrayConcretePowder"] = "minecraft:light_gray_concrete_powder";
  MinecraftItemTypes2["LightGrayDye"] = "minecraft:light_gray_dye";
  MinecraftItemTypes2["LightGrayHarness"] = "minecraft:light_gray_harness";
  MinecraftItemTypes2["LightGrayShulkerBox"] = "minecraft:light_gray_shulker_box";
  MinecraftItemTypes2["LightGrayStainedGlass"] = "minecraft:light_gray_stained_glass";
  MinecraftItemTypes2["LightGrayStainedGlassPane"] = "minecraft:light_gray_stained_glass_pane";
  MinecraftItemTypes2["LightGrayTerracotta"] = "minecraft:light_gray_terracotta";
  MinecraftItemTypes2["LightGrayWool"] = "minecraft:light_gray_wool";
  MinecraftItemTypes2["LightWeightedPressurePlate"] = "minecraft:light_weighted_pressure_plate";
  MinecraftItemTypes2["LightningRod"] = "minecraft:lightning_rod";
  MinecraftItemTypes2["Lilac"] = "minecraft:lilac";
  MinecraftItemTypes2["LilyOfTheValley"] = "minecraft:lily_of_the_valley";
  MinecraftItemTypes2["LimeBundle"] = "minecraft:lime_bundle";
  MinecraftItemTypes2["LimeCandle"] = "minecraft:lime_candle";
  MinecraftItemTypes2["LimeCarpet"] = "minecraft:lime_carpet";
  MinecraftItemTypes2["LimeConcrete"] = "minecraft:lime_concrete";
  MinecraftItemTypes2["LimeConcretePowder"] = "minecraft:lime_concrete_powder";
  MinecraftItemTypes2["LimeDye"] = "minecraft:lime_dye";
  MinecraftItemTypes2["LimeGlazedTerracotta"] = "minecraft:lime_glazed_terracotta";
  MinecraftItemTypes2["LimeHarness"] = "minecraft:lime_harness";
  MinecraftItemTypes2["LimeShulkerBox"] = "minecraft:lime_shulker_box";
  MinecraftItemTypes2["LimeStainedGlass"] = "minecraft:lime_stained_glass";
  MinecraftItemTypes2["LimeStainedGlassPane"] = "minecraft:lime_stained_glass_pane";
  MinecraftItemTypes2["LimeTerracotta"] = "minecraft:lime_terracotta";
  MinecraftItemTypes2["LimeWool"] = "minecraft:lime_wool";
  MinecraftItemTypes2["LingeringPotion"] = "minecraft:lingering_potion";
  MinecraftItemTypes2["LitPumpkin"] = "minecraft:lit_pumpkin";
  MinecraftItemTypes2["LlamaSpawnEgg"] = "minecraft:llama_spawn_egg";
  MinecraftItemTypes2["Lodestone"] = "minecraft:lodestone";
  MinecraftItemTypes2["LodestoneCompass"] = "minecraft:lodestone_compass";
  MinecraftItemTypes2["Loom"] = "minecraft:loom";
  MinecraftItemTypes2["Mace"] = "minecraft:mace";
  MinecraftItemTypes2["MagentaBundle"] = "minecraft:magenta_bundle";
  MinecraftItemTypes2["MagentaCandle"] = "minecraft:magenta_candle";
  MinecraftItemTypes2["MagentaCarpet"] = "minecraft:magenta_carpet";
  MinecraftItemTypes2["MagentaConcrete"] = "minecraft:magenta_concrete";
  MinecraftItemTypes2["MagentaConcretePowder"] = "minecraft:magenta_concrete_powder";
  MinecraftItemTypes2["MagentaDye"] = "minecraft:magenta_dye";
  MinecraftItemTypes2["MagentaGlazedTerracotta"] = "minecraft:magenta_glazed_terracotta";
  MinecraftItemTypes2["MagentaHarness"] = "minecraft:magenta_harness";
  MinecraftItemTypes2["MagentaShulkerBox"] = "minecraft:magenta_shulker_box";
  MinecraftItemTypes2["MagentaStainedGlass"] = "minecraft:magenta_stained_glass";
  MinecraftItemTypes2["MagentaStainedGlassPane"] = "minecraft:magenta_stained_glass_pane";
  MinecraftItemTypes2["MagentaTerracotta"] = "minecraft:magenta_terracotta";
  MinecraftItemTypes2["MagentaWool"] = "minecraft:magenta_wool";
  MinecraftItemTypes2["Magma"] = "minecraft:magma";
  MinecraftItemTypes2["MagmaCream"] = "minecraft:magma_cream";
  MinecraftItemTypes2["MagmaCubeSpawnEgg"] = "minecraft:magma_cube_spawn_egg";
  MinecraftItemTypes2["MangroveBoat"] = "minecraft:mangrove_boat";
  MinecraftItemTypes2["MangroveButton"] = "minecraft:mangrove_button";
  MinecraftItemTypes2["MangroveChestBoat"] = "minecraft:mangrove_chest_boat";
  MinecraftItemTypes2["MangroveDoor"] = "minecraft:mangrove_door";
  MinecraftItemTypes2["MangroveFence"] = "minecraft:mangrove_fence";
  MinecraftItemTypes2["MangroveFenceGate"] = "minecraft:mangrove_fence_gate";
  MinecraftItemTypes2["MangroveHangingSign"] = "minecraft:mangrove_hanging_sign";
  MinecraftItemTypes2["MangroveLeaves"] = "minecraft:mangrove_leaves";
  MinecraftItemTypes2["MangroveLog"] = "minecraft:mangrove_log";
  MinecraftItemTypes2["MangrovePlanks"] = "minecraft:mangrove_planks";
  MinecraftItemTypes2["MangrovePressurePlate"] = "minecraft:mangrove_pressure_plate";
  MinecraftItemTypes2["MangrovePropagule"] = "minecraft:mangrove_propagule";
  MinecraftItemTypes2["MangroveRoots"] = "minecraft:mangrove_roots";
  MinecraftItemTypes2["MangroveShelf"] = "minecraft:mangrove_shelf";
  MinecraftItemTypes2["MangroveSign"] = "minecraft:mangrove_sign";
  MinecraftItemTypes2["MangroveSlab"] = "minecraft:mangrove_slab";
  MinecraftItemTypes2["MangroveStairs"] = "minecraft:mangrove_stairs";
  MinecraftItemTypes2["MangroveTrapdoor"] = "minecraft:mangrove_trapdoor";
  MinecraftItemTypes2["MangroveWood"] = "minecraft:mangrove_wood";
  MinecraftItemTypes2["MediumAmethystBud"] = "minecraft:medium_amethyst_bud";
  MinecraftItemTypes2["MelonBlock"] = "minecraft:melon_block";
  MinecraftItemTypes2["MelonSeeds"] = "minecraft:melon_seeds";
  MinecraftItemTypes2["MelonSlice"] = "minecraft:melon_slice";
  MinecraftItemTypes2["MilkBucket"] = "minecraft:milk_bucket";
  MinecraftItemTypes2["Minecart"] = "minecraft:minecart";
  MinecraftItemTypes2["MinerPotterySherd"] = "minecraft:miner_pottery_sherd";
  MinecraftItemTypes2["MobSpawner"] = "minecraft:mob_spawner";
  MinecraftItemTypes2["MojangBannerPattern"] = "minecraft:mojang_banner_pattern";
  MinecraftItemTypes2["MooshroomSpawnEgg"] = "minecraft:mooshroom_spawn_egg";
  MinecraftItemTypes2["MossBlock"] = "minecraft:moss_block";
  MinecraftItemTypes2["MossCarpet"] = "minecraft:moss_carpet";
  MinecraftItemTypes2["MossyCobblestone"] = "minecraft:mossy_cobblestone";
  MinecraftItemTypes2["MossyCobblestoneSlab"] = "minecraft:mossy_cobblestone_slab";
  MinecraftItemTypes2["MossyCobblestoneStairs"] = "minecraft:mossy_cobblestone_stairs";
  MinecraftItemTypes2["MossyCobblestoneWall"] = "minecraft:mossy_cobblestone_wall";
  MinecraftItemTypes2["MossyStoneBrickSlab"] = "minecraft:mossy_stone_brick_slab";
  MinecraftItemTypes2["MossyStoneBrickStairs"] = "minecraft:mossy_stone_brick_stairs";
  MinecraftItemTypes2["MossyStoneBrickWall"] = "minecraft:mossy_stone_brick_wall";
  MinecraftItemTypes2["MossyStoneBricks"] = "minecraft:mossy_stone_bricks";
  MinecraftItemTypes2["MournerPotterySherd"] = "minecraft:mourner_pottery_sherd";
  MinecraftItemTypes2["Mud"] = "minecraft:mud";
  MinecraftItemTypes2["MudBrickSlab"] = "minecraft:mud_brick_slab";
  MinecraftItemTypes2["MudBrickStairs"] = "minecraft:mud_brick_stairs";
  MinecraftItemTypes2["MudBrickWall"] = "minecraft:mud_brick_wall";
  MinecraftItemTypes2["MudBricks"] = "minecraft:mud_bricks";
  MinecraftItemTypes2["MuddyMangroveRoots"] = "minecraft:muddy_mangrove_roots";
  MinecraftItemTypes2["MuleSpawnEgg"] = "minecraft:mule_spawn_egg";
  MinecraftItemTypes2["MushroomStem"] = "minecraft:mushroom_stem";
  MinecraftItemTypes2["MushroomStew"] = "minecraft:mushroom_stew";
  MinecraftItemTypes2["MusicDisc11"] = "minecraft:music_disc_11";
  MinecraftItemTypes2["MusicDisc13"] = "minecraft:music_disc_13";
  MinecraftItemTypes2["MusicDisc5"] = "minecraft:music_disc_5";
  MinecraftItemTypes2["MusicDiscBlocks"] = "minecraft:music_disc_blocks";
  MinecraftItemTypes2["MusicDiscBounce"] = "minecraft:music_disc_bounce";
  MinecraftItemTypes2["MusicDiscCat"] = "minecraft:music_disc_cat";
  MinecraftItemTypes2["MusicDiscChirp"] = "minecraft:music_disc_chirp";
  MinecraftItemTypes2["MusicDiscCreator"] = "minecraft:music_disc_creator";
  MinecraftItemTypes2["MusicDiscCreatorMusicBox"] = "minecraft:music_disc_creator_music_box";
  MinecraftItemTypes2["MusicDiscFar"] = "minecraft:music_disc_far";
  MinecraftItemTypes2["MusicDiscLavaChicken"] = "minecraft:music_disc_lava_chicken";
  MinecraftItemTypes2["MusicDiscMall"] = "minecraft:music_disc_mall";
  MinecraftItemTypes2["MusicDiscMellohi"] = "minecraft:music_disc_mellohi";
  MinecraftItemTypes2["MusicDiscOtherside"] = "minecraft:music_disc_otherside";
  MinecraftItemTypes2["MusicDiscPigstep"] = "minecraft:music_disc_pigstep";
  MinecraftItemTypes2["MusicDiscPrecipice"] = "minecraft:music_disc_precipice";
  MinecraftItemTypes2["MusicDiscRelic"] = "minecraft:music_disc_relic";
  MinecraftItemTypes2["MusicDiscStal"] = "minecraft:music_disc_stal";
  MinecraftItemTypes2["MusicDiscStrad"] = "minecraft:music_disc_strad";
  MinecraftItemTypes2["MusicDiscTears"] = "minecraft:music_disc_tears";
  MinecraftItemTypes2["MusicDiscWait"] = "minecraft:music_disc_wait";
  MinecraftItemTypes2["MusicDiscWard"] = "minecraft:music_disc_ward";
  MinecraftItemTypes2["Mutton"] = "minecraft:mutton";
  MinecraftItemTypes2["Mycelium"] = "minecraft:mycelium";
  MinecraftItemTypes2["NameTag"] = "minecraft:name_tag";
  MinecraftItemTypes2["NautilusShell"] = "minecraft:nautilus_shell";
  MinecraftItemTypes2["NautilusSpawnEgg"] = "minecraft:nautilus_spawn_egg";
  MinecraftItemTypes2["NetherBrick"] = "minecraft:nether_brick";
  MinecraftItemTypes2["NetherBrickFence"] = "minecraft:nether_brick_fence";
  MinecraftItemTypes2["NetherBrickSlab"] = "minecraft:nether_brick_slab";
  MinecraftItemTypes2["NetherBrickStairs"] = "minecraft:nether_brick_stairs";
  MinecraftItemTypes2["NetherBrickWall"] = "minecraft:nether_brick_wall";
  MinecraftItemTypes2["NetherGoldOre"] = "minecraft:nether_gold_ore";
  MinecraftItemTypes2["NetherSprouts"] = "minecraft:nether_sprouts";
  MinecraftItemTypes2["NetherStar"] = "minecraft:nether_star";
  MinecraftItemTypes2["NetherWart"] = "minecraft:nether_wart";
  MinecraftItemTypes2["NetherWartBlock"] = "minecraft:nether_wart_block";
  MinecraftItemTypes2["Netherbrick"] = "minecraft:netherbrick";
  MinecraftItemTypes2["NetheriteAxe"] = "minecraft:netherite_axe";
  MinecraftItemTypes2["NetheriteBlock"] = "minecraft:netherite_block";
  MinecraftItemTypes2["NetheriteBoots"] = "minecraft:netherite_boots";
  MinecraftItemTypes2["NetheriteChestplate"] = "minecraft:netherite_chestplate";
  MinecraftItemTypes2["NetheriteHelmet"] = "minecraft:netherite_helmet";
  MinecraftItemTypes2["NetheriteHoe"] = "minecraft:netherite_hoe";
  MinecraftItemTypes2["NetheriteHorseArmor"] = "minecraft:netherite_horse_armor";
  MinecraftItemTypes2["NetheriteIngot"] = "minecraft:netherite_ingot";
  MinecraftItemTypes2["NetheriteLeggings"] = "minecraft:netherite_leggings";
  MinecraftItemTypes2["NetheriteNautilusArmor"] = "minecraft:netherite_nautilus_armor";
  MinecraftItemTypes2["NetheritePickaxe"] = "minecraft:netherite_pickaxe";
  MinecraftItemTypes2["NetheriteScrap"] = "minecraft:netherite_scrap";
  MinecraftItemTypes2["NetheriteShovel"] = "minecraft:netherite_shovel";
  MinecraftItemTypes2["NetheriteSpear"] = "minecraft:netherite_spear";
  MinecraftItemTypes2["NetheriteSword"] = "minecraft:netherite_sword";
  MinecraftItemTypes2["NetheriteUpgradeSmithingTemplate"] = "minecraft:netherite_upgrade_smithing_template";
  MinecraftItemTypes2["Netherrack"] = "minecraft:netherrack";
  MinecraftItemTypes2["NormalStoneSlab"] = "minecraft:normal_stone_slab";
  MinecraftItemTypes2["NormalStoneStairs"] = "minecraft:normal_stone_stairs";
  MinecraftItemTypes2["Noteblock"] = "minecraft:noteblock";
  MinecraftItemTypes2["OakBoat"] = "minecraft:oak_boat";
  MinecraftItemTypes2["OakChestBoat"] = "minecraft:oak_chest_boat";
  MinecraftItemTypes2["OakFence"] = "minecraft:oak_fence";
  MinecraftItemTypes2["OakHangingSign"] = "minecraft:oak_hanging_sign";
  MinecraftItemTypes2["OakLeaves"] = "minecraft:oak_leaves";
  MinecraftItemTypes2["OakLog"] = "minecraft:oak_log";
  MinecraftItemTypes2["OakPlanks"] = "minecraft:oak_planks";
  MinecraftItemTypes2["OakSapling"] = "minecraft:oak_sapling";
  MinecraftItemTypes2["OakShelf"] = "minecraft:oak_shelf";
  MinecraftItemTypes2["OakSign"] = "minecraft:oak_sign";
  MinecraftItemTypes2["OakSlab"] = "minecraft:oak_slab";
  MinecraftItemTypes2["OakStairs"] = "minecraft:oak_stairs";
  MinecraftItemTypes2["OakWood"] = "minecraft:oak_wood";
  MinecraftItemTypes2["Observer"] = "minecraft:observer";
  MinecraftItemTypes2["Obsidian"] = "minecraft:obsidian";
  MinecraftItemTypes2["OcelotSpawnEgg"] = "minecraft:ocelot_spawn_egg";
  MinecraftItemTypes2["OchreFroglight"] = "minecraft:ochre_froglight";
  MinecraftItemTypes2["OminousBottle"] = "minecraft:ominous_bottle";
  MinecraftItemTypes2["OminousTrialKey"] = "minecraft:ominous_trial_key";
  MinecraftItemTypes2["OpenEyeblossom"] = "minecraft:open_eyeblossom";
  MinecraftItemTypes2["OrangeBundle"] = "minecraft:orange_bundle";
  MinecraftItemTypes2["OrangeCandle"] = "minecraft:orange_candle";
  MinecraftItemTypes2["OrangeCarpet"] = "minecraft:orange_carpet";
  MinecraftItemTypes2["OrangeConcrete"] = "minecraft:orange_concrete";
  MinecraftItemTypes2["OrangeConcretePowder"] = "minecraft:orange_concrete_powder";
  MinecraftItemTypes2["OrangeDye"] = "minecraft:orange_dye";
  MinecraftItemTypes2["OrangeGlazedTerracotta"] = "minecraft:orange_glazed_terracotta";
  MinecraftItemTypes2["OrangeHarness"] = "minecraft:orange_harness";
  MinecraftItemTypes2["OrangeShulkerBox"] = "minecraft:orange_shulker_box";
  MinecraftItemTypes2["OrangeStainedGlass"] = "minecraft:orange_stained_glass";
  MinecraftItemTypes2["OrangeStainedGlassPane"] = "minecraft:orange_stained_glass_pane";
  MinecraftItemTypes2["OrangeTerracotta"] = "minecraft:orange_terracotta";
  MinecraftItemTypes2["OrangeTulip"] = "minecraft:orange_tulip";
  MinecraftItemTypes2["OrangeWool"] = "minecraft:orange_wool";
  MinecraftItemTypes2["OxeyeDaisy"] = "minecraft:oxeye_daisy";
  MinecraftItemTypes2["OxidizedChiseledCopper"] = "minecraft:oxidized_chiseled_copper";
  MinecraftItemTypes2["OxidizedCopper"] = "minecraft:oxidized_copper";
  MinecraftItemTypes2["OxidizedCopperBars"] = "minecraft:oxidized_copper_bars";
  MinecraftItemTypes2["OxidizedCopperBulb"] = "minecraft:oxidized_copper_bulb";
  MinecraftItemTypes2["OxidizedCopperChain"] = "minecraft:oxidized_copper_chain";
  MinecraftItemTypes2["OxidizedCopperChest"] = "minecraft:oxidized_copper_chest";
  MinecraftItemTypes2["OxidizedCopperDoor"] = "minecraft:oxidized_copper_door";
  MinecraftItemTypes2["OxidizedCopperGolemStatue"] = "minecraft:oxidized_copper_golem_statue";
  MinecraftItemTypes2["OxidizedCopperGrate"] = "minecraft:oxidized_copper_grate";
  MinecraftItemTypes2["OxidizedCopperLantern"] = "minecraft:oxidized_copper_lantern";
  MinecraftItemTypes2["OxidizedCopperTrapdoor"] = "minecraft:oxidized_copper_trapdoor";
  MinecraftItemTypes2["OxidizedCutCopper"] = "minecraft:oxidized_cut_copper";
  MinecraftItemTypes2["OxidizedCutCopperSlab"] = "minecraft:oxidized_cut_copper_slab";
  MinecraftItemTypes2["OxidizedCutCopperStairs"] = "minecraft:oxidized_cut_copper_stairs";
  MinecraftItemTypes2["OxidizedLightningRod"] = "minecraft:oxidized_lightning_rod";
  MinecraftItemTypes2["PackedIce"] = "minecraft:packed_ice";
  MinecraftItemTypes2["PackedMud"] = "minecraft:packed_mud";
  MinecraftItemTypes2["Painting"] = "minecraft:painting";
  MinecraftItemTypes2["PaleHangingMoss"] = "minecraft:pale_hanging_moss";
  MinecraftItemTypes2["PaleMossBlock"] = "minecraft:pale_moss_block";
  MinecraftItemTypes2["PaleMossCarpet"] = "minecraft:pale_moss_carpet";
  MinecraftItemTypes2["PaleOakBoat"] = "minecraft:pale_oak_boat";
  MinecraftItemTypes2["PaleOakButton"] = "minecraft:pale_oak_button";
  MinecraftItemTypes2["PaleOakChestBoat"] = "minecraft:pale_oak_chest_boat";
  MinecraftItemTypes2["PaleOakDoor"] = "minecraft:pale_oak_door";
  MinecraftItemTypes2["PaleOakFence"] = "minecraft:pale_oak_fence";
  MinecraftItemTypes2["PaleOakFenceGate"] = "minecraft:pale_oak_fence_gate";
  MinecraftItemTypes2["PaleOakHangingSign"] = "minecraft:pale_oak_hanging_sign";
  MinecraftItemTypes2["PaleOakLeaves"] = "minecraft:pale_oak_leaves";
  MinecraftItemTypes2["PaleOakLog"] = "minecraft:pale_oak_log";
  MinecraftItemTypes2["PaleOakPlanks"] = "minecraft:pale_oak_planks";
  MinecraftItemTypes2["PaleOakPressurePlate"] = "minecraft:pale_oak_pressure_plate";
  MinecraftItemTypes2["PaleOakSapling"] = "minecraft:pale_oak_sapling";
  MinecraftItemTypes2["PaleOakShelf"] = "minecraft:pale_oak_shelf";
  MinecraftItemTypes2["PaleOakSign"] = "minecraft:pale_oak_sign";
  MinecraftItemTypes2["PaleOakSlab"] = "minecraft:pale_oak_slab";
  MinecraftItemTypes2["PaleOakStairs"] = "minecraft:pale_oak_stairs";
  MinecraftItemTypes2["PaleOakTrapdoor"] = "minecraft:pale_oak_trapdoor";
  MinecraftItemTypes2["PaleOakWood"] = "minecraft:pale_oak_wood";
  MinecraftItemTypes2["PandaSpawnEgg"] = "minecraft:panda_spawn_egg";
  MinecraftItemTypes2["Paper"] = "minecraft:paper";
  MinecraftItemTypes2["ParchedSpawnEgg"] = "minecraft:parched_spawn_egg";
  MinecraftItemTypes2["ParrotSpawnEgg"] = "minecraft:parrot_spawn_egg";
  MinecraftItemTypes2["PearlescentFroglight"] = "minecraft:pearlescent_froglight";
  MinecraftItemTypes2["Peony"] = "minecraft:peony";
  MinecraftItemTypes2["PetrifiedOakSlab"] = "minecraft:petrified_oak_slab";
  MinecraftItemTypes2["PhantomMembrane"] = "minecraft:phantom_membrane";
  MinecraftItemTypes2["PhantomSpawnEgg"] = "minecraft:phantom_spawn_egg";
  MinecraftItemTypes2["PigSpawnEgg"] = "minecraft:pig_spawn_egg";
  MinecraftItemTypes2["PiglinBannerPattern"] = "minecraft:piglin_banner_pattern";
  MinecraftItemTypes2["PiglinBruteSpawnEgg"] = "minecraft:piglin_brute_spawn_egg";
  MinecraftItemTypes2["PiglinHead"] = "minecraft:piglin_head";
  MinecraftItemTypes2["PiglinSpawnEgg"] = "minecraft:piglin_spawn_egg";
  MinecraftItemTypes2["PillagerSpawnEgg"] = "minecraft:pillager_spawn_egg";
  MinecraftItemTypes2["PinkBundle"] = "minecraft:pink_bundle";
  MinecraftItemTypes2["PinkCandle"] = "minecraft:pink_candle";
  MinecraftItemTypes2["PinkCarpet"] = "minecraft:pink_carpet";
  MinecraftItemTypes2["PinkConcrete"] = "minecraft:pink_concrete";
  MinecraftItemTypes2["PinkConcretePowder"] = "minecraft:pink_concrete_powder";
  MinecraftItemTypes2["PinkDye"] = "minecraft:pink_dye";
  MinecraftItemTypes2["PinkGlazedTerracotta"] = "minecraft:pink_glazed_terracotta";
  MinecraftItemTypes2["PinkHarness"] = "minecraft:pink_harness";
  MinecraftItemTypes2["PinkPetals"] = "minecraft:pink_petals";
  MinecraftItemTypes2["PinkShulkerBox"] = "minecraft:pink_shulker_box";
  MinecraftItemTypes2["PinkStainedGlass"] = "minecraft:pink_stained_glass";
  MinecraftItemTypes2["PinkStainedGlassPane"] = "minecraft:pink_stained_glass_pane";
  MinecraftItemTypes2["PinkTerracotta"] = "minecraft:pink_terracotta";
  MinecraftItemTypes2["PinkTulip"] = "minecraft:pink_tulip";
  MinecraftItemTypes2["PinkWool"] = "minecraft:pink_wool";
  MinecraftItemTypes2["Piston"] = "minecraft:piston";
  MinecraftItemTypes2["PitcherPlant"] = "minecraft:pitcher_plant";
  MinecraftItemTypes2["PitcherPod"] = "minecraft:pitcher_pod";
  MinecraftItemTypes2["PlayerHead"] = "minecraft:player_head";
  MinecraftItemTypes2["PlentyPotterySherd"] = "minecraft:plenty_pottery_sherd";
  MinecraftItemTypes2["Podzol"] = "minecraft:podzol";
  MinecraftItemTypes2["PointedDripstone"] = "minecraft:pointed_dripstone";
  MinecraftItemTypes2["PoisonousPotato"] = "minecraft:poisonous_potato";
  MinecraftItemTypes2["PolarBearSpawnEgg"] = "minecraft:polar_bear_spawn_egg";
  MinecraftItemTypes2["PolishedAndesite"] = "minecraft:polished_andesite";
  MinecraftItemTypes2["PolishedAndesiteSlab"] = "minecraft:polished_andesite_slab";
  MinecraftItemTypes2["PolishedAndesiteStairs"] = "minecraft:polished_andesite_stairs";
  MinecraftItemTypes2["PolishedBasalt"] = "minecraft:polished_basalt";
  MinecraftItemTypes2["PolishedBlackstone"] = "minecraft:polished_blackstone";
  MinecraftItemTypes2["PolishedBlackstoneBrickSlab"] = "minecraft:polished_blackstone_brick_slab";
  MinecraftItemTypes2["PolishedBlackstoneBrickStairs"] = "minecraft:polished_blackstone_brick_stairs";
  MinecraftItemTypes2["PolishedBlackstoneBrickWall"] = "minecraft:polished_blackstone_brick_wall";
  MinecraftItemTypes2["PolishedBlackstoneBricks"] = "minecraft:polished_blackstone_bricks";
  MinecraftItemTypes2["PolishedBlackstoneButton"] = "minecraft:polished_blackstone_button";
  MinecraftItemTypes2["PolishedBlackstonePressurePlate"] = "minecraft:polished_blackstone_pressure_plate";
  MinecraftItemTypes2["PolishedBlackstoneSlab"] = "minecraft:polished_blackstone_slab";
  MinecraftItemTypes2["PolishedBlackstoneStairs"] = "minecraft:polished_blackstone_stairs";
  MinecraftItemTypes2["PolishedBlackstoneWall"] = "minecraft:polished_blackstone_wall";
  MinecraftItemTypes2["PolishedCinnabar"] = "minecraft:polished_cinnabar";
  MinecraftItemTypes2["PolishedCinnabarSlab"] = "minecraft:polished_cinnabar_slab";
  MinecraftItemTypes2["PolishedCinnabarStairs"] = "minecraft:polished_cinnabar_stairs";
  MinecraftItemTypes2["PolishedCinnabarWall"] = "minecraft:polished_cinnabar_wall";
  MinecraftItemTypes2["PolishedDeepslate"] = "minecraft:polished_deepslate";
  MinecraftItemTypes2["PolishedDeepslateSlab"] = "minecraft:polished_deepslate_slab";
  MinecraftItemTypes2["PolishedDeepslateStairs"] = "minecraft:polished_deepslate_stairs";
  MinecraftItemTypes2["PolishedDeepslateWall"] = "minecraft:polished_deepslate_wall";
  MinecraftItemTypes2["PolishedDiorite"] = "minecraft:polished_diorite";
  MinecraftItemTypes2["PolishedDioriteSlab"] = "minecraft:polished_diorite_slab";
  MinecraftItemTypes2["PolishedDioriteStairs"] = "minecraft:polished_diorite_stairs";
  MinecraftItemTypes2["PolishedGranite"] = "minecraft:polished_granite";
  MinecraftItemTypes2["PolishedGraniteSlab"] = "minecraft:polished_granite_slab";
  MinecraftItemTypes2["PolishedGraniteStairs"] = "minecraft:polished_granite_stairs";
  MinecraftItemTypes2["PolishedSulfur"] = "minecraft:polished_sulfur";
  MinecraftItemTypes2["PolishedSulfurSlab"] = "minecraft:polished_sulfur_slab";
  MinecraftItemTypes2["PolishedSulfurStairs"] = "minecraft:polished_sulfur_stairs";
  MinecraftItemTypes2["PolishedSulfurWall"] = "minecraft:polished_sulfur_wall";
  MinecraftItemTypes2["PolishedTuff"] = "minecraft:polished_tuff";
  MinecraftItemTypes2["PolishedTuffSlab"] = "minecraft:polished_tuff_slab";
  MinecraftItemTypes2["PolishedTuffStairs"] = "minecraft:polished_tuff_stairs";
  MinecraftItemTypes2["PolishedTuffWall"] = "minecraft:polished_tuff_wall";
  MinecraftItemTypes2["PoppedChorusFruit"] = "minecraft:popped_chorus_fruit";
  MinecraftItemTypes2["Poppy"] = "minecraft:poppy";
  MinecraftItemTypes2["Porkchop"] = "minecraft:porkchop";
  MinecraftItemTypes2["Potato"] = "minecraft:potato";
  MinecraftItemTypes2["PotentSulfur"] = "minecraft:potent_sulfur";
  MinecraftItemTypes2["Potion"] = "minecraft:potion";
  MinecraftItemTypes2["PowderSnowBucket"] = "minecraft:powder_snow_bucket";
  MinecraftItemTypes2["Prismarine"] = "minecraft:prismarine";
  MinecraftItemTypes2["PrismarineBrickSlab"] = "minecraft:prismarine_brick_slab";
  MinecraftItemTypes2["PrismarineBricks"] = "minecraft:prismarine_bricks";
  MinecraftItemTypes2["PrismarineBricksStairs"] = "minecraft:prismarine_bricks_stairs";
  MinecraftItemTypes2["PrismarineCrystals"] = "minecraft:prismarine_crystals";
  MinecraftItemTypes2["PrismarineShard"] = "minecraft:prismarine_shard";
  MinecraftItemTypes2["PrismarineSlab"] = "minecraft:prismarine_slab";
  MinecraftItemTypes2["PrismarineStairs"] = "minecraft:prismarine_stairs";
  MinecraftItemTypes2["PrismarineWall"] = "minecraft:prismarine_wall";
  MinecraftItemTypes2["PrizePotterySherd"] = "minecraft:prize_pottery_sherd";
  MinecraftItemTypes2["Pufferfish"] = "minecraft:pufferfish";
  MinecraftItemTypes2["PufferfishBucket"] = "minecraft:pufferfish_bucket";
  MinecraftItemTypes2["PufferfishSpawnEgg"] = "minecraft:pufferfish_spawn_egg";
  MinecraftItemTypes2["Pumpkin"] = "minecraft:pumpkin";
  MinecraftItemTypes2["PumpkinPie"] = "minecraft:pumpkin_pie";
  MinecraftItemTypes2["PumpkinSeeds"] = "minecraft:pumpkin_seeds";
  MinecraftItemTypes2["PurpleBundle"] = "minecraft:purple_bundle";
  MinecraftItemTypes2["PurpleCandle"] = "minecraft:purple_candle";
  MinecraftItemTypes2["PurpleCarpet"] = "minecraft:purple_carpet";
  MinecraftItemTypes2["PurpleConcrete"] = "minecraft:purple_concrete";
  MinecraftItemTypes2["PurpleConcretePowder"] = "minecraft:purple_concrete_powder";
  MinecraftItemTypes2["PurpleDye"] = "minecraft:purple_dye";
  MinecraftItemTypes2["PurpleGlazedTerracotta"] = "minecraft:purple_glazed_terracotta";
  MinecraftItemTypes2["PurpleHarness"] = "minecraft:purple_harness";
  MinecraftItemTypes2["PurpleShulkerBox"] = "minecraft:purple_shulker_box";
  MinecraftItemTypes2["PurpleStainedGlass"] = "minecraft:purple_stained_glass";
  MinecraftItemTypes2["PurpleStainedGlassPane"] = "minecraft:purple_stained_glass_pane";
  MinecraftItemTypes2["PurpleTerracotta"] = "minecraft:purple_terracotta";
  MinecraftItemTypes2["PurpleWool"] = "minecraft:purple_wool";
  MinecraftItemTypes2["PurpurBlock"] = "minecraft:purpur_block";
  MinecraftItemTypes2["PurpurPillar"] = "minecraft:purpur_pillar";
  MinecraftItemTypes2["PurpurSlab"] = "minecraft:purpur_slab";
  MinecraftItemTypes2["PurpurStairs"] = "minecraft:purpur_stairs";
  MinecraftItemTypes2["Quartz"] = "minecraft:quartz";
  MinecraftItemTypes2["QuartzBlock"] = "minecraft:quartz_block";
  MinecraftItemTypes2["QuartzBricks"] = "minecraft:quartz_bricks";
  MinecraftItemTypes2["QuartzOre"] = "minecraft:quartz_ore";
  MinecraftItemTypes2["QuartzPillar"] = "minecraft:quartz_pillar";
  MinecraftItemTypes2["QuartzSlab"] = "minecraft:quartz_slab";
  MinecraftItemTypes2["QuartzStairs"] = "minecraft:quartz_stairs";
  MinecraftItemTypes2["Rabbit"] = "minecraft:rabbit";
  MinecraftItemTypes2["RabbitFoot"] = "minecraft:rabbit_foot";
  MinecraftItemTypes2["RabbitHide"] = "minecraft:rabbit_hide";
  MinecraftItemTypes2["RabbitSpawnEgg"] = "minecraft:rabbit_spawn_egg";
  MinecraftItemTypes2["RabbitStew"] = "minecraft:rabbit_stew";
  MinecraftItemTypes2["Rail"] = "minecraft:rail";
  MinecraftItemTypes2["RaiserArmorTrimSmithingTemplate"] = "minecraft:raiser_armor_trim_smithing_template";
  MinecraftItemTypes2["RavagerSpawnEgg"] = "minecraft:ravager_spawn_egg";
  MinecraftItemTypes2["RawCopper"] = "minecraft:raw_copper";
  MinecraftItemTypes2["RawCopperBlock"] = "minecraft:raw_copper_block";
  MinecraftItemTypes2["RawGold"] = "minecraft:raw_gold";
  MinecraftItemTypes2["RawGoldBlock"] = "minecraft:raw_gold_block";
  MinecraftItemTypes2["RawIron"] = "minecraft:raw_iron";
  MinecraftItemTypes2["RawIronBlock"] = "minecraft:raw_iron_block";
  MinecraftItemTypes2["RecoveryCompass"] = "minecraft:recovery_compass";
  MinecraftItemTypes2["RedBundle"] = "minecraft:red_bundle";
  MinecraftItemTypes2["RedCandle"] = "minecraft:red_candle";
  MinecraftItemTypes2["RedCarpet"] = "minecraft:red_carpet";
  MinecraftItemTypes2["RedConcrete"] = "minecraft:red_concrete";
  MinecraftItemTypes2["RedConcretePowder"] = "minecraft:red_concrete_powder";
  MinecraftItemTypes2["RedDye"] = "minecraft:red_dye";
  MinecraftItemTypes2["RedGlazedTerracotta"] = "minecraft:red_glazed_terracotta";
  MinecraftItemTypes2["RedHarness"] = "minecraft:red_harness";
  MinecraftItemTypes2["RedMushroom"] = "minecraft:red_mushroom";
  MinecraftItemTypes2["RedMushroomBlock"] = "minecraft:red_mushroom_block";
  MinecraftItemTypes2["RedNetherBrick"] = "minecraft:red_nether_brick";
  MinecraftItemTypes2["RedNetherBrickSlab"] = "minecraft:red_nether_brick_slab";
  MinecraftItemTypes2["RedNetherBrickStairs"] = "minecraft:red_nether_brick_stairs";
  MinecraftItemTypes2["RedNetherBrickWall"] = "minecraft:red_nether_brick_wall";
  MinecraftItemTypes2["RedSand"] = "minecraft:red_sand";
  MinecraftItemTypes2["RedSandstone"] = "minecraft:red_sandstone";
  MinecraftItemTypes2["RedSandstoneSlab"] = "minecraft:red_sandstone_slab";
  MinecraftItemTypes2["RedSandstoneStairs"] = "minecraft:red_sandstone_stairs";
  MinecraftItemTypes2["RedSandstoneWall"] = "minecraft:red_sandstone_wall";
  MinecraftItemTypes2["RedShulkerBox"] = "minecraft:red_shulker_box";
  MinecraftItemTypes2["RedStainedGlass"] = "minecraft:red_stained_glass";
  MinecraftItemTypes2["RedStainedGlassPane"] = "minecraft:red_stained_glass_pane";
  MinecraftItemTypes2["RedTerracotta"] = "minecraft:red_terracotta";
  MinecraftItemTypes2["RedTulip"] = "minecraft:red_tulip";
  MinecraftItemTypes2["RedWool"] = "minecraft:red_wool";
  MinecraftItemTypes2["Redstone"] = "minecraft:redstone";
  MinecraftItemTypes2["RedstoneBlock"] = "minecraft:redstone_block";
  MinecraftItemTypes2["RedstoneLamp"] = "minecraft:redstone_lamp";
  MinecraftItemTypes2["RedstoneOre"] = "minecraft:redstone_ore";
  MinecraftItemTypes2["RedstoneTorch"] = "minecraft:redstone_torch";
  MinecraftItemTypes2["ReinforcedDeepslate"] = "minecraft:reinforced_deepslate";
  MinecraftItemTypes2["Repeater"] = "minecraft:repeater";
  MinecraftItemTypes2["RepeatingCommandBlock"] = "minecraft:repeating_command_block";
  MinecraftItemTypes2["ResinBlock"] = "minecraft:resin_block";
  MinecraftItemTypes2["ResinBrick"] = "minecraft:resin_brick";
  MinecraftItemTypes2["ResinBrickSlab"] = "minecraft:resin_brick_slab";
  MinecraftItemTypes2["ResinBrickStairs"] = "minecraft:resin_brick_stairs";
  MinecraftItemTypes2["ResinBrickWall"] = "minecraft:resin_brick_wall";
  MinecraftItemTypes2["ResinBricks"] = "minecraft:resin_bricks";
  MinecraftItemTypes2["ResinClump"] = "minecraft:resin_clump";
  MinecraftItemTypes2["RespawnAnchor"] = "minecraft:respawn_anchor";
  MinecraftItemTypes2["RibArmorTrimSmithingTemplate"] = "minecraft:rib_armor_trim_smithing_template";
  MinecraftItemTypes2["RoseBush"] = "minecraft:rose_bush";
  MinecraftItemTypes2["RottenFlesh"] = "minecraft:rotten_flesh";
  MinecraftItemTypes2["Saddle"] = "minecraft:saddle";
  MinecraftItemTypes2["Salmon"] = "minecraft:salmon";
  MinecraftItemTypes2["SalmonBucket"] = "minecraft:salmon_bucket";
  MinecraftItemTypes2["SalmonSpawnEgg"] = "minecraft:salmon_spawn_egg";
  MinecraftItemTypes2["Sand"] = "minecraft:sand";
  MinecraftItemTypes2["Sandstone"] = "minecraft:sandstone";
  MinecraftItemTypes2["SandstoneSlab"] = "minecraft:sandstone_slab";
  MinecraftItemTypes2["SandstoneStairs"] = "minecraft:sandstone_stairs";
  MinecraftItemTypes2["SandstoneWall"] = "minecraft:sandstone_wall";
  MinecraftItemTypes2["Scaffolding"] = "minecraft:scaffolding";
  MinecraftItemTypes2["ScrapePotterySherd"] = "minecraft:scrape_pottery_sherd";
  MinecraftItemTypes2["Sculk"] = "minecraft:sculk";
  MinecraftItemTypes2["SculkCatalyst"] = "minecraft:sculk_catalyst";
  MinecraftItemTypes2["SculkSensor"] = "minecraft:sculk_sensor";
  MinecraftItemTypes2["SculkShrieker"] = "minecraft:sculk_shrieker";
  MinecraftItemTypes2["SculkVein"] = "minecraft:sculk_vein";
  MinecraftItemTypes2["SeaLantern"] = "minecraft:sea_lantern";
  MinecraftItemTypes2["SeaPickle"] = "minecraft:sea_pickle";
  MinecraftItemTypes2["Seagrass"] = "minecraft:seagrass";
  MinecraftItemTypes2["SentryArmorTrimSmithingTemplate"] = "minecraft:sentry_armor_trim_smithing_template";
  MinecraftItemTypes2["ShaperArmorTrimSmithingTemplate"] = "minecraft:shaper_armor_trim_smithing_template";
  MinecraftItemTypes2["SheafPotterySherd"] = "minecraft:sheaf_pottery_sherd";
  MinecraftItemTypes2["Shears"] = "minecraft:shears";
  MinecraftItemTypes2["SheepSpawnEgg"] = "minecraft:sheep_spawn_egg";
  MinecraftItemTypes2["ShelterPotterySherd"] = "minecraft:shelter_pottery_sherd";
  MinecraftItemTypes2["Shield"] = "minecraft:shield";
  MinecraftItemTypes2["ShortDryGrass"] = "minecraft:short_dry_grass";
  MinecraftItemTypes2["ShortGrass"] = "minecraft:short_grass";
  MinecraftItemTypes2["Shroomlight"] = "minecraft:shroomlight";
  MinecraftItemTypes2["ShulkerShell"] = "minecraft:shulker_shell";
  MinecraftItemTypes2["ShulkerSpawnEgg"] = "minecraft:shulker_spawn_egg";
  MinecraftItemTypes2["SilenceArmorTrimSmithingTemplate"] = "minecraft:silence_armor_trim_smithing_template";
  MinecraftItemTypes2["SilverGlazedTerracotta"] = "minecraft:silver_glazed_terracotta";
  MinecraftItemTypes2["SilverfishSpawnEgg"] = "minecraft:silverfish_spawn_egg";
  MinecraftItemTypes2["SkeletonHorseSpawnEgg"] = "minecraft:skeleton_horse_spawn_egg";
  MinecraftItemTypes2["SkeletonSkull"] = "minecraft:skeleton_skull";
  MinecraftItemTypes2["SkeletonSpawnEgg"] = "minecraft:skeleton_spawn_egg";
  MinecraftItemTypes2["SkullBannerPattern"] = "minecraft:skull_banner_pattern";
  MinecraftItemTypes2["SkullPotterySherd"] = "minecraft:skull_pottery_sherd";
  MinecraftItemTypes2["Slime"] = "minecraft:slime";
  MinecraftItemTypes2["SlimeBall"] = "minecraft:slime_ball";
  MinecraftItemTypes2["SlimeSpawnEgg"] = "minecraft:slime_spawn_egg";
  MinecraftItemTypes2["SmallAmethystBud"] = "minecraft:small_amethyst_bud";
  MinecraftItemTypes2["SmallDripleafBlock"] = "minecraft:small_dripleaf_block";
  MinecraftItemTypes2["SmithingTable"] = "minecraft:smithing_table";
  MinecraftItemTypes2["Smoker"] = "minecraft:smoker";
  MinecraftItemTypes2["SmoothBasalt"] = "minecraft:smooth_basalt";
  MinecraftItemTypes2["SmoothQuartz"] = "minecraft:smooth_quartz";
  MinecraftItemTypes2["SmoothQuartzSlab"] = "minecraft:smooth_quartz_slab";
  MinecraftItemTypes2["SmoothQuartzStairs"] = "minecraft:smooth_quartz_stairs";
  MinecraftItemTypes2["SmoothRedSandstone"] = "minecraft:smooth_red_sandstone";
  MinecraftItemTypes2["SmoothRedSandstoneSlab"] = "minecraft:smooth_red_sandstone_slab";
  MinecraftItemTypes2["SmoothRedSandstoneStairs"] = "minecraft:smooth_red_sandstone_stairs";
  MinecraftItemTypes2["SmoothSandstone"] = "minecraft:smooth_sandstone";
  MinecraftItemTypes2["SmoothSandstoneSlab"] = "minecraft:smooth_sandstone_slab";
  MinecraftItemTypes2["SmoothSandstoneStairs"] = "minecraft:smooth_sandstone_stairs";
  MinecraftItemTypes2["SmoothStone"] = "minecraft:smooth_stone";
  MinecraftItemTypes2["SmoothStoneSlab"] = "minecraft:smooth_stone_slab";
  MinecraftItemTypes2["SnifferEgg"] = "minecraft:sniffer_egg";
  MinecraftItemTypes2["SnifferSpawnEgg"] = "minecraft:sniffer_spawn_egg";
  MinecraftItemTypes2["SnortPotterySherd"] = "minecraft:snort_pottery_sherd";
  MinecraftItemTypes2["SnoutArmorTrimSmithingTemplate"] = "minecraft:snout_armor_trim_smithing_template";
  MinecraftItemTypes2["Snow"] = "minecraft:snow";
  MinecraftItemTypes2["SnowGolemSpawnEgg"] = "minecraft:snow_golem_spawn_egg";
  MinecraftItemTypes2["SnowLayer"] = "minecraft:snow_layer";
  MinecraftItemTypes2["Snowball"] = "minecraft:snowball";
  MinecraftItemTypes2["SoulCampfire"] = "minecraft:soul_campfire";
  MinecraftItemTypes2["SoulLantern"] = "minecraft:soul_lantern";
  MinecraftItemTypes2["SoulSand"] = "minecraft:soul_sand";
  MinecraftItemTypes2["SoulSoil"] = "minecraft:soul_soil";
  MinecraftItemTypes2["SoulTorch"] = "minecraft:soul_torch";
  MinecraftItemTypes2["SpiderEye"] = "minecraft:spider_eye";
  MinecraftItemTypes2["SpiderSpawnEgg"] = "minecraft:spider_spawn_egg";
  MinecraftItemTypes2["SpireArmorTrimSmithingTemplate"] = "minecraft:spire_armor_trim_smithing_template";
  MinecraftItemTypes2["SplashPotion"] = "minecraft:splash_potion";
  MinecraftItemTypes2["Sponge"] = "minecraft:sponge";
  MinecraftItemTypes2["SporeBlossom"] = "minecraft:spore_blossom";
  MinecraftItemTypes2["SpruceBoat"] = "minecraft:spruce_boat";
  MinecraftItemTypes2["SpruceButton"] = "minecraft:spruce_button";
  MinecraftItemTypes2["SpruceChestBoat"] = "minecraft:spruce_chest_boat";
  MinecraftItemTypes2["SpruceDoor"] = "minecraft:spruce_door";
  MinecraftItemTypes2["SpruceFence"] = "minecraft:spruce_fence";
  MinecraftItemTypes2["SpruceFenceGate"] = "minecraft:spruce_fence_gate";
  MinecraftItemTypes2["SpruceHangingSign"] = "minecraft:spruce_hanging_sign";
  MinecraftItemTypes2["SpruceLeaves"] = "minecraft:spruce_leaves";
  MinecraftItemTypes2["SpruceLog"] = "minecraft:spruce_log";
  MinecraftItemTypes2["SprucePlanks"] = "minecraft:spruce_planks";
  MinecraftItemTypes2["SprucePressurePlate"] = "minecraft:spruce_pressure_plate";
  MinecraftItemTypes2["SpruceSapling"] = "minecraft:spruce_sapling";
  MinecraftItemTypes2["SpruceShelf"] = "minecraft:spruce_shelf";
  MinecraftItemTypes2["SpruceSign"] = "minecraft:spruce_sign";
  MinecraftItemTypes2["SpruceSlab"] = "minecraft:spruce_slab";
  MinecraftItemTypes2["SpruceStairs"] = "minecraft:spruce_stairs";
  MinecraftItemTypes2["SpruceTrapdoor"] = "minecraft:spruce_trapdoor";
  MinecraftItemTypes2["SpruceWood"] = "minecraft:spruce_wood";
  MinecraftItemTypes2["Spyglass"] = "minecraft:spyglass";
  MinecraftItemTypes2["SquidSpawnEgg"] = "minecraft:squid_spawn_egg";
  MinecraftItemTypes2["Stick"] = "minecraft:stick";
  MinecraftItemTypes2["StickyPiston"] = "minecraft:sticky_piston";
  MinecraftItemTypes2["Stone"] = "minecraft:stone";
  MinecraftItemTypes2["StoneAxe"] = "minecraft:stone_axe";
  MinecraftItemTypes2["StoneBrickSlab"] = "minecraft:stone_brick_slab";
  MinecraftItemTypes2["StoneBrickStairs"] = "minecraft:stone_brick_stairs";
  MinecraftItemTypes2["StoneBrickWall"] = "minecraft:stone_brick_wall";
  MinecraftItemTypes2["StoneBricks"] = "minecraft:stone_bricks";
  MinecraftItemTypes2["StoneButton"] = "minecraft:stone_button";
  MinecraftItemTypes2["StoneHoe"] = "minecraft:stone_hoe";
  MinecraftItemTypes2["StonePickaxe"] = "minecraft:stone_pickaxe";
  MinecraftItemTypes2["StonePressurePlate"] = "minecraft:stone_pressure_plate";
  MinecraftItemTypes2["StoneShovel"] = "minecraft:stone_shovel";
  MinecraftItemTypes2["StoneSpear"] = "minecraft:stone_spear";
  MinecraftItemTypes2["StoneStairs"] = "minecraft:stone_stairs";
  MinecraftItemTypes2["StoneSword"] = "minecraft:stone_sword";
  MinecraftItemTypes2["StonecutterBlock"] = "minecraft:stonecutter_block";
  MinecraftItemTypes2["StraySpawnEgg"] = "minecraft:stray_spawn_egg";
  MinecraftItemTypes2["StriderSpawnEgg"] = "minecraft:strider_spawn_egg";
  MinecraftItemTypes2["String"] = "minecraft:string";
  MinecraftItemTypes2["StrippedAcaciaLog"] = "minecraft:stripped_acacia_log";
  MinecraftItemTypes2["StrippedAcaciaWood"] = "minecraft:stripped_acacia_wood";
  MinecraftItemTypes2["StrippedBambooBlock"] = "minecraft:stripped_bamboo_block";
  MinecraftItemTypes2["StrippedBirchLog"] = "minecraft:stripped_birch_log";
  MinecraftItemTypes2["StrippedBirchWood"] = "minecraft:stripped_birch_wood";
  MinecraftItemTypes2["StrippedCherryLog"] = "minecraft:stripped_cherry_log";
  MinecraftItemTypes2["StrippedCherryWood"] = "minecraft:stripped_cherry_wood";
  MinecraftItemTypes2["StrippedCrimsonHyphae"] = "minecraft:stripped_crimson_hyphae";
  MinecraftItemTypes2["StrippedCrimsonStem"] = "minecraft:stripped_crimson_stem";
  MinecraftItemTypes2["StrippedDarkOakLog"] = "minecraft:stripped_dark_oak_log";
  MinecraftItemTypes2["StrippedDarkOakWood"] = "minecraft:stripped_dark_oak_wood";
  MinecraftItemTypes2["StrippedJungleLog"] = "minecraft:stripped_jungle_log";
  MinecraftItemTypes2["StrippedJungleWood"] = "minecraft:stripped_jungle_wood";
  MinecraftItemTypes2["StrippedMangroveLog"] = "minecraft:stripped_mangrove_log";
  MinecraftItemTypes2["StrippedMangroveWood"] = "minecraft:stripped_mangrove_wood";
  MinecraftItemTypes2["StrippedOakLog"] = "minecraft:stripped_oak_log";
  MinecraftItemTypes2["StrippedOakWood"] = "minecraft:stripped_oak_wood";
  MinecraftItemTypes2["StrippedPaleOakLog"] = "minecraft:stripped_pale_oak_log";
  MinecraftItemTypes2["StrippedPaleOakWood"] = "minecraft:stripped_pale_oak_wood";
  MinecraftItemTypes2["StrippedSpruceLog"] = "minecraft:stripped_spruce_log";
  MinecraftItemTypes2["StrippedSpruceWood"] = "minecraft:stripped_spruce_wood";
  MinecraftItemTypes2["StrippedWarpedHyphae"] = "minecraft:stripped_warped_hyphae";
  MinecraftItemTypes2["StrippedWarpedStem"] = "minecraft:stripped_warped_stem";
  MinecraftItemTypes2["StructureBlock"] = "minecraft:structure_block";
  MinecraftItemTypes2["StructureVoid"] = "minecraft:structure_void";
  MinecraftItemTypes2["Sugar"] = "minecraft:sugar";
  MinecraftItemTypes2["SugarCane"] = "minecraft:sugar_cane";
  MinecraftItemTypes2["Sulfur"] = "minecraft:sulfur";
  MinecraftItemTypes2["SulfurBrickSlab"] = "minecraft:sulfur_brick_slab";
  MinecraftItemTypes2["SulfurBrickStairs"] = "minecraft:sulfur_brick_stairs";
  MinecraftItemTypes2["SulfurBrickWall"] = "minecraft:sulfur_brick_wall";
  MinecraftItemTypes2["SulfurBricks"] = "minecraft:sulfur_bricks";
  MinecraftItemTypes2["SulfurCubeBucket"] = "minecraft:sulfur_cube_bucket";
  MinecraftItemTypes2["SulfurCubeSpawnEgg"] = "minecraft:sulfur_cube_spawn_egg";
  MinecraftItemTypes2["SulfurSlab"] = "minecraft:sulfur_slab";
  MinecraftItemTypes2["SulfurSpike"] = "minecraft:sulfur_spike";
  MinecraftItemTypes2["SulfurStairs"] = "minecraft:sulfur_stairs";
  MinecraftItemTypes2["SulfurWall"] = "minecraft:sulfur_wall";
  MinecraftItemTypes2["Sunflower"] = "minecraft:sunflower";
  MinecraftItemTypes2["SuspiciousGravel"] = "minecraft:suspicious_gravel";
  MinecraftItemTypes2["SuspiciousSand"] = "minecraft:suspicious_sand";
  MinecraftItemTypes2["SuspiciousStew"] = "minecraft:suspicious_stew";
  MinecraftItemTypes2["SweetBerries"] = "minecraft:sweet_berries";
  MinecraftItemTypes2["TadpoleBucket"] = "minecraft:tadpole_bucket";
  MinecraftItemTypes2["TadpoleSpawnEgg"] = "minecraft:tadpole_spawn_egg";
  MinecraftItemTypes2["TallDryGrass"] = "minecraft:tall_dry_grass";
  MinecraftItemTypes2["TallGrass"] = "minecraft:tall_grass";
  MinecraftItemTypes2["Target"] = "minecraft:target";
  MinecraftItemTypes2["TideArmorTrimSmithingTemplate"] = "minecraft:tide_armor_trim_smithing_template";
  MinecraftItemTypes2["TintedGlass"] = "minecraft:tinted_glass";
  MinecraftItemTypes2["Tnt"] = "minecraft:tnt";
  MinecraftItemTypes2["TntMinecart"] = "minecraft:tnt_minecart";
  MinecraftItemTypes2["Torch"] = "minecraft:torch";
  MinecraftItemTypes2["Torchflower"] = "minecraft:torchflower";
  MinecraftItemTypes2["TorchflowerSeeds"] = "minecraft:torchflower_seeds";
  MinecraftItemTypes2["TotemOfUndying"] = "minecraft:totem_of_undying";
  MinecraftItemTypes2["TraderLlamaSpawnEgg"] = "minecraft:trader_llama_spawn_egg";
  MinecraftItemTypes2["Trapdoor"] = "minecraft:trapdoor";
  MinecraftItemTypes2["TrappedChest"] = "minecraft:trapped_chest";
  MinecraftItemTypes2["TrialKey"] = "minecraft:trial_key";
  MinecraftItemTypes2["TrialSpawner"] = "minecraft:trial_spawner";
  MinecraftItemTypes2["Trident"] = "minecraft:trident";
  MinecraftItemTypes2["TripwireHook"] = "minecraft:tripwire_hook";
  MinecraftItemTypes2["TropicalFish"] = "minecraft:tropical_fish";
  MinecraftItemTypes2["TropicalFishBucket"] = "minecraft:tropical_fish_bucket";
  MinecraftItemTypes2["TropicalFishSpawnEgg"] = "minecraft:tropical_fish_spawn_egg";
  MinecraftItemTypes2["TubeCoral"] = "minecraft:tube_coral";
  MinecraftItemTypes2["TubeCoralBlock"] = "minecraft:tube_coral_block";
  MinecraftItemTypes2["TubeCoralFan"] = "minecraft:tube_coral_fan";
  MinecraftItemTypes2["Tuff"] = "minecraft:tuff";
  MinecraftItemTypes2["TuffBrickSlab"] = "minecraft:tuff_brick_slab";
  MinecraftItemTypes2["TuffBrickStairs"] = "minecraft:tuff_brick_stairs";
  MinecraftItemTypes2["TuffBrickWall"] = "minecraft:tuff_brick_wall";
  MinecraftItemTypes2["TuffBricks"] = "minecraft:tuff_bricks";
  MinecraftItemTypes2["TuffSlab"] = "minecraft:tuff_slab";
  MinecraftItemTypes2["TuffStairs"] = "minecraft:tuff_stairs";
  MinecraftItemTypes2["TuffWall"] = "minecraft:tuff_wall";
  MinecraftItemTypes2["TurtleEgg"] = "minecraft:turtle_egg";
  MinecraftItemTypes2["TurtleHelmet"] = "minecraft:turtle_helmet";
  MinecraftItemTypes2["TurtleScute"] = "minecraft:turtle_scute";
  MinecraftItemTypes2["TurtleSpawnEgg"] = "minecraft:turtle_spawn_egg";
  MinecraftItemTypes2["TwistingVines"] = "minecraft:twisting_vines";
  MinecraftItemTypes2["UndyedShulkerBox"] = "minecraft:undyed_shulker_box";
  MinecraftItemTypes2["Vault"] = "minecraft:vault";
  MinecraftItemTypes2["VerdantFroglight"] = "minecraft:verdant_froglight";
  MinecraftItemTypes2["VexArmorTrimSmithingTemplate"] = "minecraft:vex_armor_trim_smithing_template";
  MinecraftItemTypes2["VexSpawnEgg"] = "minecraft:vex_spawn_egg";
  MinecraftItemTypes2["VillagerSpawnEgg"] = "minecraft:villager_spawn_egg";
  MinecraftItemTypes2["VindicatorSpawnEgg"] = "minecraft:vindicator_spawn_egg";
  MinecraftItemTypes2["Vine"] = "minecraft:vine";
  MinecraftItemTypes2["WanderingTraderSpawnEgg"] = "minecraft:wandering_trader_spawn_egg";
  MinecraftItemTypes2["WardArmorTrimSmithingTemplate"] = "minecraft:ward_armor_trim_smithing_template";
  MinecraftItemTypes2["WardenSpawnEgg"] = "minecraft:warden_spawn_egg";
  MinecraftItemTypes2["WarpedButton"] = "minecraft:warped_button";
  MinecraftItemTypes2["WarpedDoor"] = "minecraft:warped_door";
  MinecraftItemTypes2["WarpedFence"] = "minecraft:warped_fence";
  MinecraftItemTypes2["WarpedFenceGate"] = "minecraft:warped_fence_gate";
  MinecraftItemTypes2["WarpedFungus"] = "minecraft:warped_fungus";
  MinecraftItemTypes2["WarpedFungusOnAStick"] = "minecraft:warped_fungus_on_a_stick";
  MinecraftItemTypes2["WarpedHangingSign"] = "minecraft:warped_hanging_sign";
  MinecraftItemTypes2["WarpedHyphae"] = "minecraft:warped_hyphae";
  MinecraftItemTypes2["WarpedNylium"] = "minecraft:warped_nylium";
  MinecraftItemTypes2["WarpedPlanks"] = "minecraft:warped_planks";
  MinecraftItemTypes2["WarpedPressurePlate"] = "minecraft:warped_pressure_plate";
  MinecraftItemTypes2["WarpedRoots"] = "minecraft:warped_roots";
  MinecraftItemTypes2["WarpedShelf"] = "minecraft:warped_shelf";
  MinecraftItemTypes2["WarpedSign"] = "minecraft:warped_sign";
  MinecraftItemTypes2["WarpedSlab"] = "minecraft:warped_slab";
  MinecraftItemTypes2["WarpedStairs"] = "minecraft:warped_stairs";
  MinecraftItemTypes2["WarpedStem"] = "minecraft:warped_stem";
  MinecraftItemTypes2["WarpedTrapdoor"] = "minecraft:warped_trapdoor";
  MinecraftItemTypes2["WarpedWartBlock"] = "minecraft:warped_wart_block";
  MinecraftItemTypes2["WaterBucket"] = "minecraft:water_bucket";
  MinecraftItemTypes2["Waterlily"] = "minecraft:waterlily";
  MinecraftItemTypes2["WaxedChiseledCopper"] = "minecraft:waxed_chiseled_copper";
  MinecraftItemTypes2["WaxedCopper"] = "minecraft:waxed_copper";
  MinecraftItemTypes2["WaxedCopperBars"] = "minecraft:waxed_copper_bars";
  MinecraftItemTypes2["WaxedCopperBulb"] = "minecraft:waxed_copper_bulb";
  MinecraftItemTypes2["WaxedCopperChain"] = "minecraft:waxed_copper_chain";
  MinecraftItemTypes2["WaxedCopperChest"] = "minecraft:waxed_copper_chest";
  MinecraftItemTypes2["WaxedCopperDoor"] = "minecraft:waxed_copper_door";
  MinecraftItemTypes2["WaxedCopperGolemStatue"] = "minecraft:waxed_copper_golem_statue";
  MinecraftItemTypes2["WaxedCopperGrate"] = "minecraft:waxed_copper_grate";
  MinecraftItemTypes2["WaxedCopperLantern"] = "minecraft:waxed_copper_lantern";
  MinecraftItemTypes2["WaxedCopperTrapdoor"] = "minecraft:waxed_copper_trapdoor";
  MinecraftItemTypes2["WaxedCutCopper"] = "minecraft:waxed_cut_copper";
  MinecraftItemTypes2["WaxedCutCopperSlab"] = "minecraft:waxed_cut_copper_slab";
  MinecraftItemTypes2["WaxedCutCopperStairs"] = "minecraft:waxed_cut_copper_stairs";
  MinecraftItemTypes2["WaxedExposedChiseledCopper"] = "minecraft:waxed_exposed_chiseled_copper";
  MinecraftItemTypes2["WaxedExposedCopper"] = "minecraft:waxed_exposed_copper";
  MinecraftItemTypes2["WaxedExposedCopperBars"] = "minecraft:waxed_exposed_copper_bars";
  MinecraftItemTypes2["WaxedExposedCopperBulb"] = "minecraft:waxed_exposed_copper_bulb";
  MinecraftItemTypes2["WaxedExposedCopperChain"] = "minecraft:waxed_exposed_copper_chain";
  MinecraftItemTypes2["WaxedExposedCopperChest"] = "minecraft:waxed_exposed_copper_chest";
  MinecraftItemTypes2["WaxedExposedCopperDoor"] = "minecraft:waxed_exposed_copper_door";
  MinecraftItemTypes2["WaxedExposedCopperGolemStatue"] = "minecraft:waxed_exposed_copper_golem_statue";
  MinecraftItemTypes2["WaxedExposedCopperGrate"] = "minecraft:waxed_exposed_copper_grate";
  MinecraftItemTypes2["WaxedExposedCopperLantern"] = "minecraft:waxed_exposed_copper_lantern";
  MinecraftItemTypes2["WaxedExposedCopperTrapdoor"] = "minecraft:waxed_exposed_copper_trapdoor";
  MinecraftItemTypes2["WaxedExposedCutCopper"] = "minecraft:waxed_exposed_cut_copper";
  MinecraftItemTypes2["WaxedExposedCutCopperSlab"] = "minecraft:waxed_exposed_cut_copper_slab";
  MinecraftItemTypes2["WaxedExposedCutCopperStairs"] = "minecraft:waxed_exposed_cut_copper_stairs";
  MinecraftItemTypes2["WaxedExposedLightningRod"] = "minecraft:waxed_exposed_lightning_rod";
  MinecraftItemTypes2["WaxedLightningRod"] = "minecraft:waxed_lightning_rod";
  MinecraftItemTypes2["WaxedOxidizedChiseledCopper"] = "minecraft:waxed_oxidized_chiseled_copper";
  MinecraftItemTypes2["WaxedOxidizedCopper"] = "minecraft:waxed_oxidized_copper";
  MinecraftItemTypes2["WaxedOxidizedCopperBars"] = "minecraft:waxed_oxidized_copper_bars";
  MinecraftItemTypes2["WaxedOxidizedCopperBulb"] = "minecraft:waxed_oxidized_copper_bulb";
  MinecraftItemTypes2["WaxedOxidizedCopperChain"] = "minecraft:waxed_oxidized_copper_chain";
  MinecraftItemTypes2["WaxedOxidizedCopperChest"] = "minecraft:waxed_oxidized_copper_chest";
  MinecraftItemTypes2["WaxedOxidizedCopperDoor"] = "minecraft:waxed_oxidized_copper_door";
  MinecraftItemTypes2["WaxedOxidizedCopperGolemStatue"] = "minecraft:waxed_oxidized_copper_golem_statue";
  MinecraftItemTypes2["WaxedOxidizedCopperGrate"] = "minecraft:waxed_oxidized_copper_grate";
  MinecraftItemTypes2["WaxedOxidizedCopperLantern"] = "minecraft:waxed_oxidized_copper_lantern";
  MinecraftItemTypes2["WaxedOxidizedCopperTrapdoor"] = "minecraft:waxed_oxidized_copper_trapdoor";
  MinecraftItemTypes2["WaxedOxidizedCutCopper"] = "minecraft:waxed_oxidized_cut_copper";
  MinecraftItemTypes2["WaxedOxidizedCutCopperSlab"] = "minecraft:waxed_oxidized_cut_copper_slab";
  MinecraftItemTypes2["WaxedOxidizedCutCopperStairs"] = "minecraft:waxed_oxidized_cut_copper_stairs";
  MinecraftItemTypes2["WaxedOxidizedLightningRod"] = "minecraft:waxed_oxidized_lightning_rod";
  MinecraftItemTypes2["WaxedWeatheredChiseledCopper"] = "minecraft:waxed_weathered_chiseled_copper";
  MinecraftItemTypes2["WaxedWeatheredCopper"] = "minecraft:waxed_weathered_copper";
  MinecraftItemTypes2["WaxedWeatheredCopperBars"] = "minecraft:waxed_weathered_copper_bars";
  MinecraftItemTypes2["WaxedWeatheredCopperBulb"] = "minecraft:waxed_weathered_copper_bulb";
  MinecraftItemTypes2["WaxedWeatheredCopperChain"] = "minecraft:waxed_weathered_copper_chain";
  MinecraftItemTypes2["WaxedWeatheredCopperChest"] = "minecraft:waxed_weathered_copper_chest";
  MinecraftItemTypes2["WaxedWeatheredCopperDoor"] = "minecraft:waxed_weathered_copper_door";
  MinecraftItemTypes2["WaxedWeatheredCopperGolemStatue"] = "minecraft:waxed_weathered_copper_golem_statue";
  MinecraftItemTypes2["WaxedWeatheredCopperGrate"] = "minecraft:waxed_weathered_copper_grate";
  MinecraftItemTypes2["WaxedWeatheredCopperLantern"] = "minecraft:waxed_weathered_copper_lantern";
  MinecraftItemTypes2["WaxedWeatheredCopperTrapdoor"] = "minecraft:waxed_weathered_copper_trapdoor";
  MinecraftItemTypes2["WaxedWeatheredCutCopper"] = "minecraft:waxed_weathered_cut_copper";
  MinecraftItemTypes2["WaxedWeatheredCutCopperSlab"] = "minecraft:waxed_weathered_cut_copper_slab";
  MinecraftItemTypes2["WaxedWeatheredCutCopperStairs"] = "minecraft:waxed_weathered_cut_copper_stairs";
  MinecraftItemTypes2["WaxedWeatheredLightningRod"] = "minecraft:waxed_weathered_lightning_rod";
  MinecraftItemTypes2["WayfinderArmorTrimSmithingTemplate"] = "minecraft:wayfinder_armor_trim_smithing_template";
  MinecraftItemTypes2["WeatheredChiseledCopper"] = "minecraft:weathered_chiseled_copper";
  MinecraftItemTypes2["WeatheredCopper"] = "minecraft:weathered_copper";
  MinecraftItemTypes2["WeatheredCopperBars"] = "minecraft:weathered_copper_bars";
  MinecraftItemTypes2["WeatheredCopperBulb"] = "minecraft:weathered_copper_bulb";
  MinecraftItemTypes2["WeatheredCopperChain"] = "minecraft:weathered_copper_chain";
  MinecraftItemTypes2["WeatheredCopperChest"] = "minecraft:weathered_copper_chest";
  MinecraftItemTypes2["WeatheredCopperDoor"] = "minecraft:weathered_copper_door";
  MinecraftItemTypes2["WeatheredCopperGolemStatue"] = "minecraft:weathered_copper_golem_statue";
  MinecraftItemTypes2["WeatheredCopperGrate"] = "minecraft:weathered_copper_grate";
  MinecraftItemTypes2["WeatheredCopperLantern"] = "minecraft:weathered_copper_lantern";
  MinecraftItemTypes2["WeatheredCopperTrapdoor"] = "minecraft:weathered_copper_trapdoor";
  MinecraftItemTypes2["WeatheredCutCopper"] = "minecraft:weathered_cut_copper";
  MinecraftItemTypes2["WeatheredCutCopperSlab"] = "minecraft:weathered_cut_copper_slab";
  MinecraftItemTypes2["WeatheredCutCopperStairs"] = "minecraft:weathered_cut_copper_stairs";
  MinecraftItemTypes2["WeatheredLightningRod"] = "minecraft:weathered_lightning_rod";
  MinecraftItemTypes2["Web"] = "minecraft:web";
  MinecraftItemTypes2["WeepingVines"] = "minecraft:weeping_vines";
  MinecraftItemTypes2["WetSponge"] = "minecraft:wet_sponge";
  MinecraftItemTypes2["Wheat"] = "minecraft:wheat";
  MinecraftItemTypes2["WheatSeeds"] = "minecraft:wheat_seeds";
  MinecraftItemTypes2["WhiteBundle"] = "minecraft:white_bundle";
  MinecraftItemTypes2["WhiteCandle"] = "minecraft:white_candle";
  MinecraftItemTypes2["WhiteCarpet"] = "minecraft:white_carpet";
  MinecraftItemTypes2["WhiteConcrete"] = "minecraft:white_concrete";
  MinecraftItemTypes2["WhiteConcretePowder"] = "minecraft:white_concrete_powder";
  MinecraftItemTypes2["WhiteDye"] = "minecraft:white_dye";
  MinecraftItemTypes2["WhiteGlazedTerracotta"] = "minecraft:white_glazed_terracotta";
  MinecraftItemTypes2["WhiteHarness"] = "minecraft:white_harness";
  MinecraftItemTypes2["WhiteShulkerBox"] = "minecraft:white_shulker_box";
  MinecraftItemTypes2["WhiteStainedGlass"] = "minecraft:white_stained_glass";
  MinecraftItemTypes2["WhiteStainedGlassPane"] = "minecraft:white_stained_glass_pane";
  MinecraftItemTypes2["WhiteTerracotta"] = "minecraft:white_terracotta";
  MinecraftItemTypes2["WhiteTulip"] = "minecraft:white_tulip";
  MinecraftItemTypes2["WhiteWool"] = "minecraft:white_wool";
  MinecraftItemTypes2["WildArmorTrimSmithingTemplate"] = "minecraft:wild_armor_trim_smithing_template";
  MinecraftItemTypes2["Wildflowers"] = "minecraft:wildflowers";
  MinecraftItemTypes2["WindCharge"] = "minecraft:wind_charge";
  MinecraftItemTypes2["WitchSpawnEgg"] = "minecraft:witch_spawn_egg";
  MinecraftItemTypes2["WitherRose"] = "minecraft:wither_rose";
  MinecraftItemTypes2["WitherSkeletonSkull"] = "minecraft:wither_skeleton_skull";
  MinecraftItemTypes2["WitherSkeletonSpawnEgg"] = "minecraft:wither_skeleton_spawn_egg";
  MinecraftItemTypes2["WitherSpawnEgg"] = "minecraft:wither_spawn_egg";
  MinecraftItemTypes2["WolfArmor"] = "minecraft:wolf_armor";
  MinecraftItemTypes2["WolfSpawnEgg"] = "minecraft:wolf_spawn_egg";
  MinecraftItemTypes2["WoodenAxe"] = "minecraft:wooden_axe";
  MinecraftItemTypes2["WoodenButton"] = "minecraft:wooden_button";
  MinecraftItemTypes2["WoodenDoor"] = "minecraft:wooden_door";
  MinecraftItemTypes2["WoodenHoe"] = "minecraft:wooden_hoe";
  MinecraftItemTypes2["WoodenPickaxe"] = "minecraft:wooden_pickaxe";
  MinecraftItemTypes2["WoodenPressurePlate"] = "minecraft:wooden_pressure_plate";
  MinecraftItemTypes2["WoodenShovel"] = "minecraft:wooden_shovel";
  MinecraftItemTypes2["WoodenSpear"] = "minecraft:wooden_spear";
  MinecraftItemTypes2["WoodenSword"] = "minecraft:wooden_sword";
  MinecraftItemTypes2["WritableBook"] = "minecraft:writable_book";
  MinecraftItemTypes2["YellowBundle"] = "minecraft:yellow_bundle";
  MinecraftItemTypes2["YellowCandle"] = "minecraft:yellow_candle";
  MinecraftItemTypes2["YellowCarpet"] = "minecraft:yellow_carpet";
  MinecraftItemTypes2["YellowConcrete"] = "minecraft:yellow_concrete";
  MinecraftItemTypes2["YellowConcretePowder"] = "minecraft:yellow_concrete_powder";
  MinecraftItemTypes2["YellowDye"] = "minecraft:yellow_dye";
  MinecraftItemTypes2["YellowGlazedTerracotta"] = "minecraft:yellow_glazed_terracotta";
  MinecraftItemTypes2["YellowHarness"] = "minecraft:yellow_harness";
  MinecraftItemTypes2["YellowShulkerBox"] = "minecraft:yellow_shulker_box";
  MinecraftItemTypes2["YellowStainedGlass"] = "minecraft:yellow_stained_glass";
  MinecraftItemTypes2["YellowStainedGlassPane"] = "minecraft:yellow_stained_glass_pane";
  MinecraftItemTypes2["YellowTerracotta"] = "minecraft:yellow_terracotta";
  MinecraftItemTypes2["YellowWool"] = "minecraft:yellow_wool";
  MinecraftItemTypes2["ZoglinSpawnEgg"] = "minecraft:zoglin_spawn_egg";
  MinecraftItemTypes2["ZombieHead"] = "minecraft:zombie_head";
  MinecraftItemTypes2["ZombieHorseSpawnEgg"] = "minecraft:zombie_horse_spawn_egg";
  MinecraftItemTypes2["ZombieNautilusSpawnEgg"] = "minecraft:zombie_nautilus_spawn_egg";
  MinecraftItemTypes2["ZombiePigmanSpawnEgg"] = "minecraft:zombie_pigman_spawn_egg";
  MinecraftItemTypes2["ZombieSpawnEgg"] = "minecraft:zombie_spawn_egg";
  MinecraftItemTypes2["ZombieVillagerSpawnEgg"] = "minecraft:zombie_villager_spawn_egg";
  return MinecraftItemTypes2;
})(MinecraftItemTypes || {});
var MinecraftPotionDeliveryTypes = ((MinecraftPotionDeliveryTypes2) => {
  MinecraftPotionDeliveryTypes2["Consume"] = "Consume";
  MinecraftPotionDeliveryTypes2["ThrownLingering"] = "ThrownLingering";
  MinecraftPotionDeliveryTypes2["ThrownSplash"] = "ThrownSplash";
  return MinecraftPotionDeliveryTypes2;
})(MinecraftPotionDeliveryTypes || {});
var MinecraftPotionEffectTypes = ((MinecraftPotionEffectTypes2) => {
  MinecraftPotionEffectTypes2["Awkward"] = "minecraft:awkward";
  MinecraftPotionEffectTypes2["FireResistance"] = "minecraft:fire_resistance";
  MinecraftPotionEffectTypes2["Harming"] = "minecraft:harming";
  MinecraftPotionEffectTypes2["Healing"] = "minecraft:healing";
  MinecraftPotionEffectTypes2["Infested"] = "minecraft:infested";
  MinecraftPotionEffectTypes2["Invisibility"] = "minecraft:invisibility";
  MinecraftPotionEffectTypes2["Leaping"] = "minecraft:leaping";
  MinecraftPotionEffectTypes2["LongFireResistance"] = "minecraft:long_fire_resistance";
  MinecraftPotionEffectTypes2["LongInvisibility"] = "minecraft:long_invisibility";
  MinecraftPotionEffectTypes2["LongLeaping"] = "minecraft:long_leaping";
  MinecraftPotionEffectTypes2["LongMundane"] = "minecraft:long_mundane";
  MinecraftPotionEffectTypes2["LongNightvision"] = "minecraft:long_nightvision";
  MinecraftPotionEffectTypes2["LongPoison"] = "minecraft:long_poison";
  MinecraftPotionEffectTypes2["LongRegeneration"] = "minecraft:long_regeneration";
  MinecraftPotionEffectTypes2["LongSlowFalling"] = "minecraft:long_slow_falling";
  MinecraftPotionEffectTypes2["LongSlowness"] = "minecraft:long_slowness";
  MinecraftPotionEffectTypes2["LongStrength"] = "minecraft:long_strength";
  MinecraftPotionEffectTypes2["LongSwiftness"] = "minecraft:long_swiftness";
  MinecraftPotionEffectTypes2["LongTurtleMaster"] = "minecraft:long_turtle_master";
  MinecraftPotionEffectTypes2["LongWaterBreathing"] = "minecraft:long_water_breathing";
  MinecraftPotionEffectTypes2["LongWeakness"] = "minecraft:long_weakness";
  MinecraftPotionEffectTypes2["Mundane"] = "minecraft:mundane";
  MinecraftPotionEffectTypes2["Nightvision"] = "minecraft:nightvision";
  MinecraftPotionEffectTypes2["Oozing"] = "minecraft:oozing";
  MinecraftPotionEffectTypes2["Poison"] = "minecraft:poison";
  MinecraftPotionEffectTypes2["Regeneration"] = "minecraft:regeneration";
  MinecraftPotionEffectTypes2["SlowFalling"] = "minecraft:slow_falling";
  MinecraftPotionEffectTypes2["Slowness"] = "minecraft:slowness";
  MinecraftPotionEffectTypes2["Strength"] = "minecraft:strength";
  MinecraftPotionEffectTypes2["StrongHarming"] = "minecraft:strong_harming";
  MinecraftPotionEffectTypes2["StrongHealing"] = "minecraft:strong_healing";
  MinecraftPotionEffectTypes2["StrongLeaping"] = "minecraft:strong_leaping";
  MinecraftPotionEffectTypes2["StrongPoison"] = "minecraft:strong_poison";
  MinecraftPotionEffectTypes2["StrongRegeneration"] = "minecraft:strong_regeneration";
  MinecraftPotionEffectTypes2["StrongSlowness"] = "minecraft:strong_slowness";
  MinecraftPotionEffectTypes2["StrongStrength"] = "minecraft:strong_strength";
  MinecraftPotionEffectTypes2["StrongSwiftness"] = "minecraft:strong_swiftness";
  MinecraftPotionEffectTypes2["StrongTurtleMaster"] = "minecraft:strong_turtle_master";
  MinecraftPotionEffectTypes2["Swiftness"] = "minecraft:swiftness";
  MinecraftPotionEffectTypes2["Thick"] = "minecraft:thick";
  MinecraftPotionEffectTypes2["TurtleMaster"] = "minecraft:turtle_master";
  MinecraftPotionEffectTypes2["Water"] = "minecraft:water";
  MinecraftPotionEffectTypes2["WaterBreathing"] = "minecraft:water_breathing";
  MinecraftPotionEffectTypes2["Weakness"] = "minecraft:weakness";
  MinecraftPotionEffectTypes2["Weaving"] = "minecraft:weaving";
  MinecraftPotionEffectTypes2["WindCharged"] = "minecraft:wind_charged";
  MinecraftPotionEffectTypes2["Wither"] = "minecraft:wither";
  return MinecraftPotionEffectTypes2;
})(MinecraftPotionEffectTypes || {});

// scripts/block_components/crop.ts
var cropComponent = {
  onRandomTick(event) {
    const { block } = event, { permutation } = block;
    const below = block.below();
    const hydrated = below.permutation.getState("moisturized_amount") ?? 0 > 0;
    const growth_chance = hydrated ? 1 / 3 : 1 / 7;
    if (Math.random() >= growth_chance) return;
    const growth2 = permutation.getState("tcsmp:growth_stage") ?? 0;
    if (growth2 < 2)
      block.setPermutation(permutation.withState("tcsmp:growth_stage", growth2 + 1));
  },
  onPlayerInteract(event) {
    const { player, block, dimension } = event, { permutation } = block;
    const slot = player == null ? void 0 : player.equipment.getEquipmentSlot(EquipmentSlot.Mainhand);
    if (!(slot == null ? void 0 : slot.hasItem()) || (slot == null ? void 0 : slot.typeId) != MinecraftItemTypes.BoneMeal) return;
    dimension.spawnParticle("minecraft:crop_growth_emitter", block.center());
    dimension.playSound("item.bone_meal.use", block.center());
    block.setPermutation(permutation.withState("tcsmp:growth_stage", 2));
    if ((player == null ? void 0 : player.getGameMode()) != GameMode.Creative) {
      if (slot.hasItem()) slot.decrement();
    }
  }
};
var crop_default = cropComponent;

// scripts/block_components/export.ts
var BlockComponents = [
  {
    name: "tcsmp:waystone",
    component: waystone_default
  },
  {
    name: "tcsmp:tick_particle",
    component: tick_particle_default
  },
  {
    name: "tcsmp:crop",
    component: crop_default
  }
];
var export_default = BlockComponents;

// scripts/block_events/jukebox.ts
import { BlockComponentTypes, system, world as world6 } from "@minecraft/server";
var RecordMap = {};
var RecordSounds = {
  "tcsmp:music_disc_drop_it": "record.drop_it",
  "tcsmp:music_disc_crackas": "record.crackas",
  "tcsmp:music_disc_puma_pants": "record.puma_pants",
  "tcsmp:music_disc_based_boys": "record.based_boys",
  "tcsmp:music_disc_obama": "record.obama",
  "tcsmp:music_disc_straight_facts": "record.straight_facts"
};
world6.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const { block } = event, { dimension, location } = block;
  if (!block.matches(MinecraftBlockTypes.Jukebox)) return;
  const recordPlayer = block.getComponent(BlockComponentTypes.RecordPlayer);
  if (!recordPlayer.isPlaying()) {
    if (event.itemStack && world6.getDynamicProperty("servermode")) {
      const recordSound = RecordSounds[event.itemStack.typeId];
      if (!recordSound) return;
      const descKey = recordSound.replace(".", "_");
      system.run(() => {
        for (const player of dimension.getPlayers({
          location: block.center(),
          maxDistance: 64
        })) player.onScreenDisplay.setActionBar([
          "\xA7dNow playing: ",
          { translate: `item.${descKey}.desc` },
          "\xA7r"
        ]);
      });
    }
    return;
  }
  RecordMap[Vec3.toString(location)] = recordPlayer.getRecord().typeId;
});
world6.afterEvents.playerInteractWithBlock.subscribe((event) => {
  const { block } = event, { dimension, location } = block;
  if (!block.matches(MinecraftBlockTypes.Jukebox)) return;
  const stringLocation = Vec3.toString(location);
  const player = block.getComponent(BlockComponentTypes.RecordPlayer);
  if (player == null ? void 0 : player.isPlaying()) return;
  const sound = RecordSounds[RecordMap[stringLocation] ?? "none"];
  for (const player2 of dimension.getPlayers({
    location: block.center(),
    maxDistance: 64
  })) player2.stopSound(sound);
});
world6.beforeEvents.playerBreakBlock.subscribe((event) => {
  const { block } = event, { location } = block;
  const player = block.getComponent(BlockComponentTypes.RecordPlayer);
  if (!(player == null ? void 0 : player.isPlaying())) return;
  RecordMap[Vec3.toString(location)] = player.getRecord().typeId;
}, { blockTypes: [MinecraftBlockTypes.Jukebox] });
world6.afterEvents.playerBreakBlock.subscribe((event) => {
  const { block } = event, { dimension, location } = block;
  const stringLocation = Vec3.toString(location);
  const sound = RecordSounds[RecordMap[stringLocation]];
  for (const player of dimension.getPlayers({
    location: block.center(),
    maxDistance: 64
  })) player.stopSound(sound);
}, { blockTypes: [MinecraftBlockTypes.Jukebox] });

// scripts/block_events/stairs.ts
import { Direction as Direction2, system as system2, world as world7 } from "@minecraft/server";
var SittingBlocks = /* @__PURE__ */ new Set();
function weirdoToVector(weirdoDir) {
  return [Vec3.East, Vec3.West, Vec3.South, Vec3.North][weirdoDir];
}
world7.beforeEvents.playerInteractWithBlock.subscribe((event) => {
  const { player, block, itemStack, isFirstEvent, blockFace } = event;
  if (block.location.y - player.location.y > 0.5) return;
  if (!block.typeId.endsWith("stairs")) return;
  if (itemStack || !isFirstEvent) return;
  const { dimension } = block, { heightRange } = dimension;
  if (SittingBlocks.has(JSON.stringify({ dimension, ...block.location })))
    return;
  const bottomCenter = block.bottomCenter();
  if (Vec3.distance(
    Vec3.from(player.location.x, 0, player.location.z),
    Vec3.from(bottomCenter.x, 0, bottomCenter.z)
  ) >= 2.5) return;
  const states = block.permutation.getAllStates();
  if (states["upside_down_bit"] || states["minecraft:vertical_half"] == "top")
    return;
  const above = block.location.y < heightRange.max ? block.above() : void 0;
  if (above && !above.isAir && !above.isLiquid) return;
  const weirdoDir = states["weirdo_direction"], cardDir = states["minecraft:cardinal_direction"];
  const direction = cardDir ? Vec3.fromBlockFace(cardDir) : weirdoToVector(weirdoDir ?? 0);
  if (Vec3.toDirection(direction) == blockFace || blockFace == Direction2.Down)
    return;
  const location = Vec3.below(Vec3.add(block.center(), Vec3.mul(direction, -0.125)), 0.125);
  system2.run(() => {
    const seat = dimension.spawnEntity("tcsmp:stair_seat", location);
    seat.setRotation(Vec3.toRotation(Vec3.neg(direction)));
    seat.addRider(player);
  });
  SittingBlocks.add(JSON.stringify({ dimension, ...block.location }));
});
world7.afterEvents.playerBreakBlock.subscribe((event) => {
  const { block, dimension, brokenBlockPermutation } = event, { location } = block;
  if (!brokenBlockPermutation.type.id.includes("stairs")) return;
  for (const seat of dimension.getEntities(
    { location, volume: Vec3.One, type: "tcsmp:stair_seat" }
  )) seat.remove();
});
world7.beforeEvents.entityRemove.subscribe(({ removedEntity }) => {
  if (removedEntity.typeId !== "tcsmp:stair_seat") return;
  const { dimension, location } = removedEntity;
  const blockLocation = Vec3.floor(location);
  SittingBlocks.delete(JSON.stringify({ dimension, ...blockLocation }));
});

// scripts/custom_commands/admin/dynamicproperties.ts
import { CommandPermissionLevel, CustomCommandParamType, CustomCommandStatus, world as world8 } from "@minecraft/server";
var DynamicPropertiesAction = /* @__PURE__ */ ((DynamicPropertiesAction2) => {
  DynamicPropertiesAction2["List"] = "list";
  DynamicPropertiesAction2["Clear"] = "clear";
  return DynamicPropertiesAction2;
})(DynamicPropertiesAction || {});
var DynamicPropertiesField = /* @__PURE__ */ ((DynamicPropertiesField2) => {
  DynamicPropertiesField2["Self"] = "self";
  DynamicPropertiesField2["World"] = "world";
  return DynamicPropertiesField2;
})(DynamicPropertiesField || {});
var dynamicPropertiesCommand = {
  name: "tcsmp:dynamicproperties",
  description: "Manages the dynamic properties stored in the world.",
  permissionLevel: CommandPermissionLevel.Admin,
  cheatsRequired: true,
  mandatoryParameters: [
    {
      name: "tcsmp:dynamicproperties_action",
      type: CustomCommandParamType.Enum
    },
    {
      name: "tcsmp:dynamicproperties_field",
      type: CustomCommandParamType.Enum
    }
  ]
};
function dynamicPropertiesCallback(origin, action, field) {
  const medium = field === "self" /* Self */ ? origin.sourceEntity : world8;
  const propertyIds = medium.getDynamicPropertyIds();
  if (propertyIds.length === 0) return {
    message: `No ${field} dynamic properties currently stored.`,
    status: CustomCommandStatus.Success
  };
  let message;
  switch (action) {
    case "list" /* List */:
      message = `Dynamic Properties:
\xA77${propertyIds.map((id) => {
        const value = medium.getDynamicProperty(id);
        const output = Vec3.isVector3(value) ? Vec3.toString(value) : value;
        return `${id}: ${output}`;
      }).join("\n")}\xA7r`;
      break;
    case "clear" /* Clear */:
      message = `Cleared all ${field} dynamic properties.`;
      medium.clearDynamicProperties();
      break;
  }
  return {
    message,
    status: CustomCommandStatus.Success
  };
}
var dynamicproperties_default = { command: dynamicPropertiesCommand, callback: dynamicPropertiesCallback };

// scripts/custom_commands/enums.ts
var CustomCommandEnums = [
  {
    name: "tcsmp:faction_colour",
    values: Object.keys(FactionColour)
  },
  {
    name: "tcsmp:dynamicproperties_action",
    values: Object.values(DynamicPropertiesAction)
  },
  {
    name: "tcsmp:dynamicproperties_field",
    values: Object.values(DynamicPropertiesField)
  }
];
var enums_default = CustomCommandEnums;

// scripts/custom_commands/admin/biomeinfo.ts
import { CommandPermissionLevel as CommandPermissionLevel2, CustomCommandStatus as CustomCommandStatus2 } from "@minecraft/server";
var biomeInfoCommand = {
  name: "tcsmp:biomeinfo",
  description: "Displays information about the current biome.",
  permissionLevel: CommandPermissionLevel2.Admin,
  cheatsRequired: false
};
function biomeInfoCallback(origin) {
  const biome = origin.sourceEntity.dimension.getBiome(origin.sourceEntity.location);
  return {
    message: `Biome: \xA77${biome.id}\xA7r
Tags: \xA77${biome.getTags().join(", ")}\xA7r`,
    status: CustomCommandStatus2.Success
  };
}
var biomeinfo_default = { command: biomeInfoCommand, callback: biomeInfoCallback };

// scripts/custom_commands/admin/blockinfo.ts
import { CommandPermissionLevel as CommandPermissionLevel3, CustomCommandStatus as CustomCommandStatus3 } from "@minecraft/server";
var blockInfoCommand = {
  name: "tcsmp:blockinfo",
  description: "Displays information about the block currently being looked at.",
  permissionLevel: CommandPermissionLevel3.Admin,
  cheatsRequired: true
};
function blockInfoCallback(origin) {
  var _a;
  const player = origin.sourceEntity;
  const block = (_a = player.getBlockFromViewDirection({
    includePassableBlocks: true,
    includeLiquidBlocks: true,
    maxDistance: 6
  })) == null ? void 0 : _a.block;
  if (!block) return {
    message: "Could not find block.",
    status: CustomCommandStatus3.Failure
  };
  let message = `Block: \xA77${block.typeId}\xA7r`;
  const tags = block.getTags();
  if (tags.length > 0)
    message += `
Tags: \xA77${tags.join(", ")}\xA7r`;
  const states = block.permutation.getAllStates();
  if (Object.keys(states).length > 0)
    message += `
States: \xA77${Object.entries(states).map((pair) => `${pair[0]}: ${pair[1]}`).join(", ")}\xA7r`;
  const components = block.getComponents();
  if (components.length > 0)
    message += `
Components: \xA77${components.map((comp) => comp.typeId).join(", ")}\xA7r`;
  return {
    message,
    status: CustomCommandStatus3.Success
  };
}
var blockinfo_default = { command: blockInfoCommand, callback: blockInfoCallback };

// scripts/custom_commands/admin/damageitem.ts
import { CommandPermissionLevel as CommandPermissionLevel4, CustomCommandParamType as CustomCommandParamType2, CustomCommandStatus as CustomCommandStatus4, ItemComponentTypes, system as system3 } from "@minecraft/server";
var damageItemCommand = {
  name: "tcsmp:damageitem",
  description: "Applies durability damage to the currently held item.",
  permissionLevel: CommandPermissionLevel4.Admin,
  cheatsRequired: true,
  optionalParameters: [
    {
      name: "amount",
      type: CustomCommandParamType2.Integer
    }
  ]
};
function damageItemCallback(origin, amount) {
  const player = origin.sourceEntity;
  const itemToDamage = player.inventory.container.getSlot(player.selectedSlotIndex);
  const itemStack = itemToDamage.getItem();
  if (!itemStack) return {
    message: "Could not find an item to damage.",
    status: CustomCommandStatus4.Failure
  };
  if (!itemStack.hasComponent(ItemComponentTypes.Durability)) return {
    message: `Could not damage ${itemStack.typeId}.`,
    status: CustomCommandStatus4.Failure
  };
  system3.run(() => {
    const damagedItem = itemStack.damage(amount);
    itemToDamage.setItem(damagedItem);
    if (!damagedItem) player.dimension.playSound(
      "random.break",
      player.getHeadLocation(),
      { pitch: 0.9 }
    );
  });
  return {
    message: `Applied ${amount} damage to ${itemStack.typeId}.`,
    status: CustomCommandStatus4.Success
  };
}
var damageitem_default = { command: damageItemCommand, callback: damageItemCallback };

// scripts/custom_commands/admin/dimensioninfo.ts
import { CommandPermissionLevel as CommandPermissionLevel5, CustomCommandStatus as CustomCommandStatus5 } from "@minecraft/server";
var dimensionInfoCommand = {
  name: "tcsmp:dimensioninfo",
  description: "Displays information about the current dimension.",
  permissionLevel: CommandPermissionLevel5.Admin,
  cheatsRequired: false
};
function dimensionInfoCallback(origin) {
  const dimension = origin.sourceEntity.dimension;
  dimension.heightRange;
  return {
    message: `Dimension: \xA77${dimension.id}\xA7r
Maximum Height: \xA77${dimension.heightRange.max}\xA7r
Minimum Height: \xA77${dimension.heightRange.min}\xA7r`,
    status: CustomCommandStatus5.Success
  };
}
var dimensioninfo_default = { command: dimensionInfoCommand, callback: dimensionInfoCallback };

// scripts/custom_commands/admin/iteminfo.ts
import { CommandPermissionLevel as CommandPermissionLevel6, CustomCommandStatus as CustomCommandStatus6 } from "@minecraft/server";
var itemInfoCommand = {
  name: "tcsmp:iteminfo",
  description: "Displays information about the currently held item.",
  permissionLevel: CommandPermissionLevel6.Admin,
  cheatsRequired: true
};
function itemInfoCallback(origin) {
  const player = origin.sourceEntity;
  const itemStack = player.inventory.container.getItem(player.selectedSlotIndex);
  if (!itemStack) return {
    message: "Could not find item.",
    status: CustomCommandStatus6.Failure
  };
  let message = `Item: \xA77${itemStack.typeId}\xA7r`;
  const tags = itemStack.getTags();
  if (tags.length > 0)
    message += `
Tags: \xA77${tags.join(", ")}\xA7r`;
  const components = itemStack.getComponents();
  if (components.length > 0)
    message += `
Components: \xA77${components.map((comp) => comp.typeId).join(", ")}\xA7r`;
  return {
    message,
    status: CustomCommandStatus6.Success
  };
}
var iteminfo_default = { command: itemInfoCommand, callback: itemInfoCallback };

// scripts/custom_commands/admin/removeentity.ts
import { CommandPermissionLevel as CommandPermissionLevel7, CustomCommandParamType as CustomCommandParamType3, CustomCommandStatus as CustomCommandStatus7, system as system4 } from "@minecraft/server";
var removeEntityCommand = {
  name: "tcsmp:removeentity",
  description: "Removes an entity from the world.",
  permissionLevel: CommandPermissionLevel7.Admin,
  cheatsRequired: true,
  mandatoryParameters: [
    {
      name: "entity",
      type: CustomCommandParamType3.EntitySelector
    }
  ]
};
function removeEntityCallback(origin, entities) {
  let count = 0;
  for (const entity of entities) {
    system4.run(() => {
      entity.remove();
    });
    ++count;
  }
  return {
    message: `Removed ${count} entit${count == 1 ? "y" : "ies"}.`,
    status: CustomCommandStatus7.Success
  };
}
var removeentity_default = { command: removeEntityCommand, callback: removeEntityCallback };

// scripts/custom_commands/admin/resetcooldown.ts
import { CommandPermissionLevel as CommandPermissionLevel8, CustomCommandStatus as CustomCommandStatus8, ItemComponentTypes as ItemComponentTypes2, system as system5 } from "@minecraft/server";
var resetCooldownCommand = {
  name: "tcsmp:resetcooldown",
  description: "Reset the cooldown of the currently held item.",
  permissionLevel: CommandPermissionLevel8.Admin,
  cheatsRequired: true
};
function resetCooldownCallback(origin) {
  const player = origin.sourceEntity;
  const itemSlot = player.inventory.container.getSlot(player.selectedSlotIndex);
  const itemStack = itemSlot.getItem();
  if (!itemStack) return {
    message: "Could not find an item to reset cooldown for.",
    status: CustomCommandStatus8.Failure
  };
  if (!itemStack.hasComponent(ItemComponentTypes2.Cooldown)) return {
    message: `Could not find cooldown for ${itemStack.typeId}.`,
    status: CustomCommandStatus8.Failure
  };
  system5.run(() => {
    const cooldown = itemStack.getComponent(ItemComponentTypes2.Cooldown);
    player.startItemCooldown(cooldown.cooldownCategory, 0);
  });
  return {
    message: `Reset the cooldown of ${itemStack.typeId}`,
    status: CustomCommandStatus8.Success
  };
}
var resetcooldown_default = { command: resetCooldownCommand, callback: resetCooldownCallback };

// scripts/custom_commands/admin/servermode.ts
import { CommandPermissionLevel as CommandPermissionLevel9, CustomCommandParamType as CustomCommandParamType4, CustomCommandStatus as CustomCommandStatus9, world as world9 } from "@minecraft/server";
var serverModeCommand = {
  name: "tcsmp:servermode",
  description: "Whether scripts should execute as if they are in a bedrock dedicated server environment.",
  permissionLevel: CommandPermissionLevel9.Admin,
  cheatsRequired: true,
  optionalParameters: [
    {
      name: "value",
      type: CustomCommandParamType4.Boolean
    }
  ]
};
function serverModeCallback(origin, value) {
  if (!(typeof value === "boolean")) return {
    status: CustomCommandStatus9.Success,
    message: `servermode = ${world9.getDynamicProperty("servermode") ?? false}`
  };
  world9.setDynamicProperty("servermode", value);
  return {
    status: CustomCommandStatus9.Success,
    message: `Script rule servermode has been updated to ${value}`
  };
}
var servermode_default = { command: serverModeCommand, callback: serverModeCallback };

// scripts/custom_commands/aura/listaura.ts
import { CommandPermissionLevel as CommandPermissionLevel10, CustomCommandStatus as CustomCommandStatus10, Player as Player8 } from "@minecraft/server";
var listAuraCommand = {
  name: "tcsmp:listaura",
  description: "Displays your current aura value.",
  permissionLevel: CommandPermissionLevel10.Any,
  cheatsRequired: false
};
function listAuraCallback(origin) {
  if (!(origin.sourceEntity instanceof Player8)) return {
    status: CustomCommandStatus10.Failure,
    message: "Non-players cannot possess an aura score."
  };
  const auraScore = origin.sourceEntity.getDynamicProperty("aura");
  return {
    status: CustomCommandStatus10.Success,
    message: `You currently have ${auraScore} Aura.`
  };
}
var listaura_default = { command: listAuraCommand, callback: listAuraCallback };

// scripts/custom_commands/aura/toggleaura.ts
import { CommandPermissionLevel as CommandPermissionLevel11, CustomCommandStatus as CustomCommandStatus11, Player as Player9, system as system7, world as world11 } from "@minecraft/server";
var toggleAuraCommand = {
  name: "tcsmp:toggleaura",
  description: "Toggles display of the aura meter.",
  permissionLevel: CommandPermissionLevel11.Any,
  cheatsRequired: false
};
function toggleAuraCallback(origin) {
  if (!(origin.sourceEntity instanceof Player9)) return {
    status: CustomCommandStatus11.Failure,
    message: "Non-players cannot possess an aura score."
  };
  const aura = world11.scoreboard.getObjective("aura");
  const displayState = aura.hasParticipant(origin.sourceEntity);
  system7.run(() => {
    if (displayState) aura.removeParticipant(origin.sourceEntity);
    else {
      const auraScore = origin.sourceEntity.getDynamicProperty("aura");
      aura.setScore(origin.sourceEntity, auraScore);
    }
  });
  return {
    status: CustomCommandStatus11.Success,
    message: `Aura meter visibility has been set to ${!displayState}.`
  };
}
var toggleaura_default = { command: toggleAuraCommand, callback: toggleAuraCallback };

// scripts/custom_commands/factions/create.ts
import { CommandPermissionLevel as CommandPermissionLevel12, CustomCommandParamType as CustomCommandParamType5, CustomCommandStatus as CustomCommandStatus12, Player as Player10, system as system8 } from "@minecraft/server";
var createFactionCommand = {
  name: "tcsmp:createfaction",
  description: "Creates a new faction.",
  permissionLevel: CommandPermissionLevel12.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "name",
      type: CustomCommandParamType5.String
    },
    {
      name: "tcsmp:faction_colour",
      type: CustomCommandParamType5.Enum
    }
  ]
};
function createFactionCallback(origin, name, colour) {
  if (!(origin.sourceEntity instanceof Player10)) return {
    status: CustomCommandStatus12.Failure,
    message: `Non-player entities cannot create factions.`
  };
  if (FactionRegistry.getFaction(origin.sourceEntity)) return {
    status: CustomCommandStatus12.Failure,
    message: `Cannot create a faction while already part of one.`
  };
  if (!(colour in FactionColour)) return {
    status: CustomCommandStatus12.Failure,
    message: `Faction colour ${colour} is invalid.`
  };
  if (!FactionRegistry.nameIsValid(name)) return {
    status: CustomCommandStatus12.Failure,
    message: `Faction name ${name} is invalid.`
  };
  system8.run(() => FactionRegistry.addFaction({
    name,
    colour: FactionColour[colour],
    owner: origin.sourceEntity.id,
    players: [origin.sourceEntity.id]
  }));
  return {
    status: CustomCommandStatus12.Success,
    message: `Successfully created faction \xA7${FactionColour[colour]}${name}\xA7r.`
  };
}
var create_default = { command: createFactionCommand, callback: createFactionCallback };

// scripts/custom_commands/factions/delete.ts
import { CommandPermissionLevel as CommandPermissionLevel13, CustomCommandStatus as CustomCommandStatus13, Player as Player11, system as system9 } from "@minecraft/server";
var factionDeleteCommand = {
  name: "tcsmp:deletefaction",
  description: "Deletes your faction.",
  permissionLevel: CommandPermissionLevel13.Any,
  cheatsRequired: false
};
function factionDeleteCallback(origin) {
  if (!(origin.sourceEntity instanceof Player11)) return {
    status: CustomCommandStatus13.Failure,
    message: `Non-player entities cannot send faction invites.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus13.Failure,
    message: `Cannot find faction.`
  };
  if (faction.owner != origin.sourceEntity.id) return {
    status: CustomCommandStatus13.Failure,
    message: `Cannot delete faction, ownership required.`
  };
  system9.run(() => {
    FactionRegistry.removeFaction(faction);
  });
  return {
    status: CustomCommandStatus13.Success,
    message: `Deleted faction \xA7${faction.colour}${faction.name}\xA7r.`
  };
}
var delete_default = { command: factionDeleteCommand, callback: factionDeleteCallback };

// scripts/custom_commands/factions/invite.ts
import { CommandPermissionLevel as CommandPermissionLevel14, CustomCommandParamType as CustomCommandParamType6, CustomCommandStatus as CustomCommandStatus14, Player as Player12 } from "@minecraft/server";
var factionInviteCommand = {
  name: "tcsmp:invitefaction",
  description: "Invites a player to your faction.",
  permissionLevel: CommandPermissionLevel14.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "player",
      type: CustomCommandParamType6.PlayerSelector
    }
  ]
};
function factionInviteCallback(origin, players) {
  if (!(origin.sourceEntity instanceof Player12)) return {
    status: CustomCommandStatus14.Failure,
    message: `Non-player entities cannot send faction invites.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus14.Failure,
    message: `Cannot find faction.`
  };
  const invited = [];
  for (const player of players) {
    if (player.id == origin.sourceEntity.id) continue;
    if (FactionRegistry.getFaction(player)) {
      origin.sourceEntity.sendMessage(`\xA7c${player.name} is already in a faction.\xA7r`);
      continue;
    }
    ;
    player.sendMessage(`You've been invited to join \xA7${faction.colour}${faction.name}\xA7r. Use \xA77/joinfaction\xA7r to accept.`);
    FactionRegistry.invitePlayer(faction, player);
    invited.push(player.name);
  }
  if (invited.length) return {
    status: CustomCommandStatus14.Success,
    message: `Successfully sent faction invite${invited.length > 1 ? "s" : ""} to ${invited}.`
  };
  else return {
    status: CustomCommandStatus14.Failure,
    message: `Could not send any faction invites.`
  };
}
var invite_default = { command: factionInviteCommand, callback: factionInviteCallback };

// scripts/custom_commands/factions/join.ts
import { CommandPermissionLevel as CommandPermissionLevel15, CustomCommandStatus as CustomCommandStatus15, Player as Player13, system as system10 } from "@minecraft/server";
var factionJoinCommand = {
  name: "tcsmp:joinfaction",
  description: "Accepts the most recent invite to a faction.",
  permissionLevel: CommandPermissionLevel15.Any,
  cheatsRequired: false
};
function factionJoinCallback(origin) {
  if (!(origin.sourceEntity instanceof Player13)) return {
    status: CustomCommandStatus15.Failure,
    message: `Non-player entities cannot send faction invites.`
  };
  const currentFaction = FactionRegistry.getFaction(origin.sourceEntity);
  if (currentFaction) return {
    status: CustomCommandStatus15.Failure,
    message: `Cannot join multiple factions.`
  };
  const targetFaction = FactionRegistry.getFaction(origin.sourceEntity.getDynamicProperty("tcsmp:faction_invite"));
  if (!targetFaction) return {
    status: CustomCommandStatus15.Failure,
    message: `Invited faction no longer exists.`
  };
  system10.run(() => {
    FactionRegistry.sendMessage(targetFaction, `\xA7e${origin.sourceEntity.name} has joined the faction`);
    FactionRegistry.addPlayer(targetFaction, origin.sourceEntity.id);
    origin.sourceEntity.setDynamicProperty("tcsmp:faction_invite");
  });
  return {
    status: CustomCommandStatus15.Success,
    message: `You have joined faction \xA7${targetFaction.colour}${targetFaction.name}\xA7r.`
  };
}
var join_default = { command: factionJoinCommand, callback: factionJoinCallback };

// scripts/custom_commands/factions/kick.ts
import { CommandPermissionLevel as CommandPermissionLevel16, CustomCommandParamType as CustomCommandParamType7, CustomCommandStatus as CustomCommandStatus16, Player as Player14, system as system11 } from "@minecraft/server";
var factionKickCommand = {
  name: "tcsmp:kickfaction",
  description: "Kicks a player from your faction.",
  permissionLevel: CommandPermissionLevel16.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "player",
      type: CustomCommandParamType7.PlayerSelector
    }
  ]
};
function factionKickCallback(origin, players) {
  if (!(origin.sourceEntity instanceof Player14)) return {
    status: CustomCommandStatus16.Failure,
    message: `Non-player entities cannot create factions.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus16.Failure,
    message: `Cannot find faction.`
  };
  if (faction.owner != origin.sourceEntity.id) return {
    status: CustomCommandStatus16.Failure,
    message: `Cannot kick players, ownership required.`
  };
  const kicked = [];
  for (const player of players) {
    if (!faction.players.includes(player.id)) {
      origin.sourceEntity.sendMessage(`\xA7e${player.name} is not in your faction.\xA7r`);
      continue;
    }
    if (faction.owner == player.id) {
      origin.sourceEntity.sendMessage(`\xA7cCannot kick owner from faction.\xA7r`);
      continue;
    }
    player.sendMessage(`You have been kicked from \xA7${faction.colour}${faction.name}\xA7r.`);
    system11.run(() => {
      FactionRegistry.removePlayer(faction, player.id);
    });
    kicked.push(player.name);
  }
  if (kicked.length) return {
    status: CustomCommandStatus16.Success,
    message: `Successfully kicked ${kicked}.`
  };
  else return {
    status: CustomCommandStatus16.Failure,
    message: `Could not kick any players.`
  };
}
var kick_default = { command: factionKickCommand, callback: factionKickCallback };

// scripts/custom_commands/factions/leave.ts
import { CommandPermissionLevel as CommandPermissionLevel17, CustomCommandStatus as CustomCommandStatus17, Player as Player15, system as system12 } from "@minecraft/server";
var factionLeaveCommand = {
  name: "tcsmp:leavefaction",
  description: "Leave your current faction.",
  permissionLevel: CommandPermissionLevel17.Any,
  cheatsRequired: false
};
function factionLeaveCallback(origin) {
  if (!(origin.sourceEntity instanceof Player15)) return {
    status: CustomCommandStatus17.Failure,
    message: "Non-player entities cannot leave factions."
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus17.Failure,
    message: `Cannot find faction.`
  };
  if (faction.owner == origin.sourceEntity.id) return {
    status: CustomCommandStatus17.Failure,
    message: `Cannot leave a faction you own.`
  };
  system12.run(() => {
    FactionRegistry.removePlayer(faction, origin.sourceEntity.id);
  });
  return {
    status: CustomCommandStatus17.Success,
    message: `You are no longer in faction \xA7${faction.colour}${faction.name}\xA7r.`
  };
}
var leave_default = { command: factionLeaveCommand, callback: factionLeaveCallback };

// scripts/custom_commands/factions/list.ts
import { CommandPermissionLevel as CommandPermissionLevel18, CustomCommandStatus as CustomCommandStatus18, Player as Player16 } from "@minecraft/server";
var factionListCommand = {
  name: "tcsmp:listfaction",
  description: "Lists the players currently in your faction.",
  permissionLevel: CommandPermissionLevel18.Any,
  cheatsRequired: false
};
function factionListCallback(origin) {
  if (!(origin.sourceEntity instanceof Player16)) return {
    status: CustomCommandStatus18.Failure,
    message: `Non-player entities cannot list faction members.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus18.Failure,
    message: `Cannot find faction.`
  };
  let message = `There are ${faction.players.length} players in \xA7${faction.colour}${faction.name}\xA7r:
`;
  message += faction.players.reduce((prev, cur) => {
    let display = NameRegistry.getName(cur);
    if (faction.owner == cur) return prev;
    return prev + ", " + display;
  }, NameRegistry.getName(faction.owner) + " (Owner)");
  return {
    status: CustomCommandStatus18.Success,
    message
  };
}
var list_default = { command: factionListCommand, callback: factionListCallback };

// scripts/custom_commands/factions/message.ts
import { CommandPermissionLevel as CommandPermissionLevel19, CustomCommandParamType as CustomCommandParamType8, CustomCommandStatus as CustomCommandStatus19, Player as Player17 } from "@minecraft/server";
var factionMessageCommand = {
  name: "tcsmp:messagefaction",
  description: "Send a message to your faction.",
  permissionLevel: CommandPermissionLevel19.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "message",
      type: CustomCommandParamType8.String
    }
  ]
};
function factionMessageCallback(origin, message) {
  if (!(origin.sourceEntity instanceof Player17)) return {
    status: CustomCommandStatus19.Failure,
    message: `Non-player entities cannot send faction messages.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus19.Failure,
    message: `Cannot find faction.`
  };
  FactionRegistry.sendMessage(faction, `<${origin.sourceEntity.name}> ${message}`);
  return {
    status: CustomCommandStatus19.Success
  };
}
var message_default = { command: factionMessageCommand, callback: factionMessageCallback };

// scripts/custom_commands/factions/rename.ts
import { CommandPermissionLevel as CommandPermissionLevel20, CustomCommandParamType as CustomCommandParamType9, CustomCommandStatus as CustomCommandStatus20, Player as Player18, system as system13 } from "@minecraft/server";
var renameFactionCommand = {
  name: "tcsmp:renamefaction",
  description: "Renames your faction.",
  permissionLevel: CommandPermissionLevel20.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "name",
      type: CustomCommandParamType9.String
    },
    {
      name: "tcsmp:faction_colour",
      type: CustomCommandParamType9.Enum
    }
  ]
};
function renameFactionCallback(origin, name, colour) {
  if (!(origin.sourceEntity instanceof Player18)) return {
    status: CustomCommandStatus20.Failure,
    message: `Non-player entities cannot rename factions.`
  };
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus20.Failure,
    message: `Cannot find faction.`
  };
  if (faction.owner != origin.sourceEntity.id) return {
    status: CustomCommandStatus20.Failure,
    message: `Unable to rename faction, ownership required.`
  };
  if (!(colour in FactionColour)) return {
    status: CustomCommandStatus20.Failure,
    message: `Faction colour ${colour} is invalid.`
  };
  if (name != faction.name && !FactionRegistry.nameIsValid(name)) return {
    status: CustomCommandStatus20.Failure,
    message: `Faction name \xA7${FactionColour[colour]}${name}\xA7c is invalid.`
  };
  system13.run(() => {
    FactionRegistry.removeFaction(faction);
    FactionRegistry.addFaction({
      name,
      colour: FactionColour[colour],
      owner: faction.owner,
      players: faction.players
    });
  });
  return {
    status: CustomCommandStatus20.Success,
    message: `Renamed faction to \xA7${FactionColour[colour]}${name}\xA7r.`
  };
}
var rename_default = { command: renameFactionCommand, callback: renameFactionCallback };

// scripts/custom_commands/factions/transfer.ts
import { CommandPermissionLevel as CommandPermissionLevel21, CustomCommandParamType as CustomCommandParamType10, CustomCommandStatus as CustomCommandStatus21, Player as Player19, system as system14 } from "@minecraft/server";
var factionTransferCommand = {
  name: "tcsmp:transferfaction",
  description: "Transfer ownership of your faction.",
  permissionLevel: CommandPermissionLevel21.Any,
  cheatsRequired: false,
  mandatoryParameters: [
    {
      name: "player",
      type: CustomCommandParamType10.PlayerSelector
    }
  ]
};
function factionTransferCallback(origin, players) {
  if (!(origin.sourceEntity instanceof Player19)) return {
    status: CustomCommandStatus21.Failure,
    message: `Non-player entities cannot transfer faction ownership.`
  };
  if (players.length > 1) return {
    status: CustomCommandStatus21.Failure,
    message: `Cannot transfer faction ownership to multiple players.`
  };
  const [player] = players;
  const faction = FactionRegistry.getFaction(origin.sourceEntity);
  if (!faction) return {
    status: CustomCommandStatus21.Failure,
    message: `Cannot find faction.`
  };
  if (faction.owner != origin.sourceEntity.id) return {
    status: CustomCommandStatus21.Failure,
    message: `Cannot transfer ownership of a faction you don't own.`
  };
  if (!faction.players.includes(player.id)) return {
    status: CustomCommandStatus21.Failure,
    message: `Cannot transfer faction ownership to a player outside of your faction.`
  };
  system14.run(() => {
    FactionRegistry.removeFaction(faction);
    FactionRegistry.addFaction({
      name: faction.name,
      colour: faction.colour,
      owner: player.id,
      players: faction.players
    });
    FactionRegistry.sendMessage(faction, `\xA7e${player.name} is now the faction owner\xA7r`);
  });
  return {
    status: CustomCommandStatus21.Success,
    message: `Transfered faction ownership to ${player.name}.`
  };
}
var transfer_default = { command: factionTransferCommand, callback: factionTransferCallback };

// scripts/custom_commands/export.ts
var CustomCommands = [
  create_default,
  rename_default,
  invite_default,
  leave_default,
  transfer_default,
  delete_default,
  message_default,
  join_default,
  kick_default,
  list_default,
  biomeinfo_default,
  damageitem_default,
  blockinfo_default,
  iteminfo_default,
  dimensioninfo_default,
  dynamicproperties_default,
  resetcooldown_default,
  removeentity_default,
  servermode_default,
  toggleaura_default,
  listaura_default
];
var export_default2 = CustomCommands;

// behaviours/entities/barnacle.entity.json
var barnacle_entity_default = {
  format_version: "1.26.40",
  "minecraft:entity": {
    description: {
      identifier: "tcsmp:barnacle",
      is_summonable: true,
      is_spawnable: true,
      spawn_category: "monster",
      runtime_identifier: "minecraft:warden",
      properties: {
        "tcsmp:barnacle_state": {
          type: "enum",
          values: ["idling", "hunting", "dragging", "consuming"],
          default: "hunting",
          client_sync: true
        }
      }
    },
    component_groups: {
      "tcsmp:idling": {
        "minecraft:timer": {
          looping: false,
          randomInterval: false,
          time: 30,
          time_down_event: {
            event: "tcsmp:start_hunting"
          }
        },
        "minecraft:damage_sensor": {
          triggers: {
            cause: "all",
            on_damage: {
              event: "tcsmp:start_hunting"
            }
          }
        }
      },
      "tcsmp:hunting": {
        "minecraft:attack": {
          damage: 1
        }
      },
      "tcsmp:chasing": {
        "minecraft:attack": {
          damage: 1
        },
        "minecraft:environment_sensor": {
          triggers: {
            filters: {
              any_of: [
                {
                  test: "has_target",
                  value: false
                },
                {
                  test: "target_distance",
                  operator: ">",
                  value: 32
                }
              ]
            },
            event: "tcsmp:on_target_lost"
          }
        }
      },
      "tcsmp:dragging_target": {
        "minecraft:knockback_resistance": {
          value: 1
        },
        "minecraft:behavior.rise_to_liquid_level": {
          priority: 0,
          liquid_y_offset: 384,
          rise_delta: 0.1,
          sink_delta: 0.1
        },
        "minecraft:environment_sensor": {
          triggers: [
            {
              filters: {
                test: "on_ground"
              },
              event: "tcsmp:on_target_dragged"
            },
            {
              filters: {
                test: "has_target",
                value: false
              },
              event: "tcsmp:on_target_lost"
            }
          ]
        }
      },
      "tcsmp:eating_prey": {
        "minecraft:attack": {
          damage: 9
        },
        "minecraft:variant": {
          value: 0
        },
        "minecraft:environment_sensor": {
          triggers: [
            {
              filters: {
                all_of: [
                  {
                    test: "has_target",
                    value: true
                  },
                  {
                    test: "target_distance",
                    operator: ">",
                    value: 6
                  }
                ]
              },
              event: "tcsmp:on_target_escape"
            },
            {
              filters: {
                any_of: [
                  {
                    test: "has_target",
                    value: false
                  },
                  {
                    test: "target_distance",
                    operator: ">",
                    value: 16
                  }
                ]
              },
              event: "tcsmp:on_target_lost"
            }
          ]
        }
      }
    },
    components: {
      "minecraft:apply_knockback_rules": {
        presets: [
          {
            vertical_power: 0,
            horizontal_power: 0
          }
        ]
      },
      "minecraft:body_rotation_always_follows_head": {},
      "minecraft:breathable": {
        breathes_air: false,
        breathes_lava: false,
        breathes_water: true,
        generates_bubbles: false,
        suffocate_time: 0,
        total_supply: 15
      },
      "minecraft:collision_box": {
        width: 0.9,
        height: 0.8
      },
      "minecraft:custom_hit_test": {
        hitboxes: [
          {
            width: 0.75,
            height: 0.75,
            pivot: [0, 0.375, -0.5]
          },
          {
            width: 0.5,
            height: 0.5,
            pivot: [0, 0.375, 0.4375]
          }
        ]
      },
      "minecraft:conditional_bandwidth_optimization": {},
      "minecraft:despawn": {
        despawn_from_distance: {}
      },
      "minecraft:experience_reward": {
        on_death: "query.last_hit_by_player ? 10 : 0"
      },
      "minecraft:follow_range": {
        max: 32,
        value: 32
      },
      "minecraft:game_event_movement_tracking": {},
      "minecraft:health": {
        max: 30,
        value: 30
      },
      "minecraft:hurt_on_condition": {
        damage_conditions: [
          {
            filters: {
              test: "in_lava"
            },
            cause: "lava",
            damage_per_tick: 4
          }
        ]
      },
      "minecraft:knockback_resistance": {
        value: 0.75
      },
      "minecraft:loot": {
        table: "loot_tables/entities/barnacle.json"
      },
      "minecraft:movement": {
        value: 0.15
      },
      "minecraft:underwater_movement": {
        value: 0.15
      },
      "minecraft:navigation.generic": {
        is_amphibious: false,
        can_path_over_water: false,
        can_swim: true,
        can_walk: false,
        can_breach: false,
        can_sink: false,
        can_jump: false
      },
      "minecraft:movement.sway": {
        sway_amplitude: 0
      },
      "minecraft:physics": {},
      "minecraft:pushable_by_block": {},
      "minecraft:pushable_by_entity": {},
      "minecraft:type_family": {
        family: [
          "aquatic",
          "barnacle",
          "squid",
          "monster",
          "mob"
        ]
      },
      "minecraft:behavior.melee_box_attack": {
        priority: 1,
        track_target: true,
        horizontal_reach: 1,
        on_attack: {
          filters: {
            all_of: [
              {
                test: "enum_property",
                domain: "tcsmp:barnacle_state",
                value: "hunting"
              },
              {
                test: "on_ground",
                value: false
              }
            ]
          },
          event: "tcsmp:on_grab_target"
        }
      },
      "minecraft:behavior.hurt_by_target": {
        priority: 2
      },
      "minecraft:behavior.nearest_attackable_target": {
        priority: 3,
        must_see: true,
        must_reach: true,
        reselect_targets: true,
        entity_types: [
          {
            filters: {
              all_of: [
                {
                  test: "enum_property",
                  domain: "tcsmp:barnacle_state",
                  operator: "not",
                  value: "idling"
                },
                {
                  any_of: [
                    {
                      test: "is_family",
                      subject: "other",
                      value: "guardian"
                    },
                    {
                      test: "is_family",
                      subject: "other",
                      value: "axolotl"
                    }
                  ]
                },
                {
                  test: "in_water",
                  subject: "other",
                  value: true
                }
              ]
            },
            reevaluate_description: true,
            max_dist: 16
          },
          {
            filters: {
              all_of: [
                {
                  test: "enum_property",
                  domain: "tcsmp:barnacle_state",
                  operator: "not",
                  value: "idling"
                },
                {
                  test: "is_family",
                  subject: "other",
                  value: "player"
                },
                {
                  any_of: [
                    {
                      all_of: [
                        {
                          any_of: [
                            {
                              test: "in_water",
                              subject: "other",
                              value: true
                            },
                            {
                              test: "in_block",
                              subject: "other",
                              value: "minecraft:water"
                            },
                            {
                              test: "in_block",
                              subject: "other",
                              value: "minecraft:flowing_water"
                            }
                          ]
                        },
                        {
                          test: "is_vehicle_family",
                          subject: "other",
                          operator: "not",
                          value: "nautilus"
                        }
                      ]
                    },
                    {
                      test: "is_vehicle_family",
                      subject: "other",
                      value: "boat"
                    }
                  ]
                }
              ]
            },
            reevaluate_description: true,
            max_dist: 32
          }
        ]
      },
      "minecraft:behavior.look_at_target": {
        priority: 4,
        probability: 1,
        look_distance: 32,
        control_flags: ["move", "look"]
      },
      "minecraft:behavior.move_towards_target": {
        priority: 5
      },
      "minecraft:behavior.random_swim": {
        priority: 6,
        xz_dist: 16,
        y_dist: 4,
        interval: 0
      },
      "minecraft:behavior.swim_wander": {
        priority: 7,
        interval: 10,
        look_ahead: 2,
        speed_multiplier: 1.5,
        wander_time: 5
      }
    },
    events: {
      "minecraft:entity_spawned": {
        trigger: "tcsmp:start_hunting"
      },
      "tcsmp:on_grab_target": {
        add: {
          component_groups: ["tcsmp:dragging_target"]
        },
        set_property: {
          "tcsmp:barnacle_state": "dragging"
        }
      },
      "tcsmp:start_consuming": {
        remove: {
          component_groups: [
            "tcsmp:idling",
            "tcsmp:dragging_target",
            "tcsmp:hunting"
          ]
        },
        add: {
          component_groups: ["tcsmp:eating_prey"]
        },
        set_property: {
          "tcsmp:barnacle_state": "consuming"
        }
      },
      "tcsmp:on_target_dragged": {
        trigger: "tcsmp:start_consuming"
      },
      "tcsmp:start_hunting": {
        remove: {
          component_groups: [
            "tcsmp:idling",
            "tcsmp:dragging_target",
            "tcsmp:eating_prey"
          ]
        },
        add: {
          component_groups: [
            "tcsmp:hunting"
          ]
        },
        set_property: {
          "tcsmp:barnacle_state": "hunting"
        }
      },
      "tcsmp:on_target_escape": {
        trigger: "tcsmp:start_chasing"
      },
      "tcsmp:on_target_lost": {
        trigger: "tcsmp:start_idling",
        reset_target: {}
      },
      "tcsmp:start_idling": {
        remove: {
          component_groups: [
            "tcsmp:dragging_target",
            "tcsmp:eating_prey",
            "tcsmp:hunting"
          ]
        },
        add: {
          component_groups: ["tcsmp:idling"]
        },
        set_property: {
          "tcsmp:barnacle_state": "idling"
        }
      },
      "tcsmp:start_chasing": {
        remove: {
          component_groups: [
            "tcsmp:idling",
            "tcsmp:dragging_target",
            "tcsmp:eating_prey"
          ]
        },
        add: {
          component_groups: [
            "tcsmp:chasing"
          ]
        },
        set_property: {
          "tcsmp:barnacle_state": "hunting"
        }
      }
    }
  }
};

// scripts/entity_events/barnacle.ts
import { EntityDamageCause, Player as Player20, system as system15, world as world12 } from "@minecraft/server";
var EATING_DAMAGE = barnacle_entity_default["minecraft:entity"].component_groups["tcsmp:eating_prey"]["minecraft:attack"].damage;
world12.beforeEvents.entityHurt.subscribe((event) => {
  const hurtEntity = event.hurtEntity;
  const damagingEntity = event.damageSource.damagingEntity;
  if (damagingEntity == null ? void 0 : damagingEntity.matches({ type: "tcsmp:barnacle" })) {
    if (damagingEntity.getProperty("tcsmp:barnacle_state") == "consuming") return;
    const block_below = damagingEntity.dimension.getBlockBelow(
      damagingEntity.location,
      { maxDistance: 3 }
    );
    if (block_below) event.damage = EATING_DAMAGE;
  } else if (hurtEntity.matches({ type: "tcsmp:barnacle" })) {
    if (hurtEntity.isInvunerable) return event.cancel = true;
    if (hurtEntity.getProperty("tcsmp:barnacle_state") == "dragging")
      event.damage *= 0.25;
  }
}, { allowedDamageCauses: [EntityDamageCause.entityAttack] });
world12.afterEvents.entityHitEntity.subscribe((event) => {
  const { damagingEntity: barnacle, hitEntity } = event;
  if (barnacle.getProperty("tcsmp:barnacle_state") == "consuming") return;
  const block_below = barnacle.dimension.getBlockBelow(
    barnacle.location,
    { maxDistance: 3 }
  );
  const draggedEntityId = barnacle.getDynamicProperty("draggedEntityId");
  if (block_below || draggedEntityId && draggedEntityId != hitEntity.id)
    return barnacle.triggerEvent("tcsmp:start_consuming");
  const draggedEntity = hitEntity.entityRidingOn ?? hitEntity;
  if (draggedEntity.hasTag("tcsmp:is_being_dragged"))
    return barnacle.triggerEvent("tcsmp:start_consuming");
  if (draggedEntity instanceof Player20)
    draggedEntity.onScreenDisplay.setTitle("overlay: tongue");
  draggedEntity.addTag("tcsmp:is_being_dragged");
  const interval = system15.runInterval(() => {
    if (!draggedEntity.isValid || !barnacle.isValid) {
      if (draggedEntity.isValid) draggedEntity.removeTag("tcsmp:is_being_dragged");
      return system15.clearRun(interval);
    }
    const head_center = Vec3.above(barnacle.location, 0.375);
    const move_target = Vec3.add(head_center, barnacle.getViewDirection());
    const to_target = Vec3.sub(move_target, draggedEntity.location);
    draggedEntity.applyImpulse(Vec3.mul(to_target, 0.125));
  });
  barnacle.setDynamicProperties({
    "dragInterval": interval,
    "draggedEntityId": draggedEntity.id
  });
}, { entityTypes: ["tcsmp:barnacle"] });
world12.afterEvents.dataDrivenEntityTrigger.subscribe(({ entity }) => {
  const dragInterval = entity.getDynamicProperty("dragInterval");
  const draggedEntityId = entity.getDynamicProperty("draggedEntityId");
  if (dragInterval) system15.clearRun(dragInterval);
  if (!draggedEntityId) return;
  const draggedEntity = world12.getEntity(draggedEntityId);
  draggedEntity == null ? void 0 : draggedEntity.removeTag("tcsmp:is_being_dragged");
  if (draggedEntity instanceof Player20)
    draggedEntity.onScreenDisplay.setTitle("overlay: none");
}, {
  entityTypes: ["tcsmp:barnacle"],
  eventTypes: ["tcsmp:on_target_dragged"]
});

// scripts/entity_events/cannon.ts
import { GameMode as GameMode2, MolangVariableMap, Player as Player21, system as system16, TicksPerSecond, world as world13 } from "@minecraft/server";
var UseTimes = {};
var USE_COOLDOWN = 1 * TicksPerSecond;
world13.afterEvents.entityHitEntity.subscribe((event) => {
  var _a;
  const { hitEntity: cannon, damagingEntity: player } = event;
  if (!cannon.isValid) return;
  if (!(player instanceof Player21)) return;
  if (!cannon.matches({ type: "tcsmp:cannon" })) return;
  const lastUsedTime = UseTimes[cannon.id] ?? 0;
  const rider = cannon.getRiders()[0];
  const { dimension } = cannon;
  if (!rider) {
    dimension.playSound("cannon.break", cannon.location);
    if (player.getGameMode() == GameMode2.Survival)
      player.dimension.spawnLoot(cannon.location, "blocks/cannon");
    cannon.dropInventory();
    cannon.remove();
  } else if (rider.id == player.id && system16.currentTick - lastUsedTime >= USE_COOLDOWN) {
    UseTimes[cannon.id] = system16.currentTick;
    const container = (_a = cannon.inventory) == null ? void 0 : _a.container;
    const ammo = container == null ? void 0 : container.firstMatch((item) => item.hasTag("tcsmp:cannon_ammo"));
    const fuel = container == null ? void 0 : container.firstMatch((item) => item.typeId == MinecraftItemTypes.Gunpowder);
    if (ammo && fuel) {
      dimension.playSound("cannon.fire", cannon.location, { pitch: 0.5 * Math.random() + 0.75 });
      const view = player.getViewDirection(), origin = Vec3.above(cannon.location);
      const direction = Vec3.normalize(Vec3.from(view.x, Math.max(view.y, 0), view.z));
      const velocity = Vec3.mul(direction, 1.35);
      const ball = dimension.spawnEntity(ammo.typeId, Vec3.add(origin, velocity));
      const projectile = ball.projectile;
      projectile.owner = player;
      spawnSmoke({ dimension, ...ball.location }, direction);
      projectile.shoot(velocity);
      ammo.decrement();
      fuel.decrement();
    } else dimension.playSound("cannon.light", cannon.location);
  }
}, { entityTypes: ["minecraft:player"] });
function spawnSmoke(origin, direction) {
  const molang_map = new MolangVariableMap();
  const tnb = Mat3.buildTNB(direction);
  for (let i = 0; i < 3; ++i) {
    molang_map.setVector3("direction", Mat3.mul(tnb, RandVec.cap(0.5)));
    origin.dimension.spawnParticle("tcsmp:cannon_smoke", origin, molang_map);
  }
}

// scripts/entity_events/fire_cannonball.ts
import { world as world14 } from "@minecraft/server";
world14.afterEvents.projectileHitBlock.subscribe((event) => {
  if (!event.projectile.isValid) return;
  if (event.projectile.matches({ type: "tcsmp:fire_cannonball" })) hit(event);
});
world14.afterEvents.projectileHitEntity.subscribe((event) => {
  if (!event.projectile.isValid) return;
  if (event.projectile.matches({ type: "tcsmp:fire_cannonball" })) hit(event);
});
function hit(event) {
  const targets = event.dimension.getEntities({ location: event.location, maxDistance: 10 });
  for (const target of targets) target.setOnFire(10);
}

// scripts/entity_events/lightning_bottle.ts
import { MolangVariableMap as MolangVariableMap2, world as world15 } from "@minecraft/server";
world15.afterEvents.projectileHitBlock.subscribe(lightningBottleHit);
world15.afterEvents.projectileHitEntity.subscribe(lightningBottleHit);
function lightningBottleHit({ dimension, location, projectile }) {
  if (!projectile.isValid || !projectile.matches({ type: "tcsmp:lightning_bottle" })) return;
  projectile.remove();
  dimension.spawnEntity(MinecraftEntityTypes.LightningBolt, Vec3.below(location, 0.5));
  const breaking_molang = new MolangVariableMap2();
  breaking_molang.setFloat("num_particles", 10);
  breaking_molang.setFloat("emitter_radius", 0);
  breaking_molang.setFloat("speed_modifier", 1);
  breaking_molang.setFloat("size_modifier", 1.25);
  dimension.spawnParticle("tcsmp:bottle_shards", location, breaking_molang);
  const splash_molang = new MolangVariableMap2();
  splash_molang.setFloat("splash_range", 1);
  splash_molang.setFloat("splash_power", 1);
  splash_molang.setColorRGBA("color", { red: 1, green: 1, blue: 1, alpha: 1 });
  dimension.spawnParticle("tcsmp:lightning_bottle_splash", location, splash_molang);
}

// scripts/entity_events/spawn_death.ts
import { EntityComponentTypes, EntityDamageCause as EntityDamageCause2, Player as Player22, world as world16 } from "@minecraft/server";
var EntityAliases = {
  // Changes here must be mirrored across all ui instances
  // including chat message filters in hud_screen and chat_screen.
  // Use https://wiki.bedrock.dev/json-ui/json-ui-intro#string-formatting
  // to find the relevant byte counts for each alias.
  "tcsmp:unicorn": "\xA7U\xA7N\xA7I\xA7C\xA7O\xA7R\xA7N",
  "tcsmp:cannon": "\xA7C\xA7A\xA7N\xA7N\xA7O\xA7N",
  "tcsmp:gerbil": "\xA7G\xA7E\xA7R\xA7B\xA7I\xA7L"
};
world16.afterEvents.entitySpawn.subscribe(({ entity }) => {
  if (!entity.isValid) return;
  if (EntityAliases[entity.typeId])
    entity.nameTag = EntityAliases[entity.typeId];
});
world16.afterEvents.entityDie.subscribe((event) => {
  const { deadEntity, damageSource } = event;
  if (deadEntity.nameTag != EntityAliases[deadEntity.typeId]) return;
  const tameableComponent = deadEntity.getComponent(EntityComponentTypes.Tameable);
  const tameMountComponent = deadEntity.getComponent(EntityComponentTypes.TameMount);
  const isTamed = (tameableComponent == null ? void 0 : tameableComponent.isTamed) ?? (tameMountComponent == null ? void 0 : tameMountComponent.isTamed);
  if (!isTamed) return;
  const entityKey = deadEntity.localizationKey;
  switch (damageSource.cause) {
    case EntityDamageCause2.anvil:
      sendDeathMessage(entityKey, "death.attack.anvil");
      break;
    case EntityDamageCause2.blockExplosion:
    case EntityDamageCause2.entityExplosion:
      sendDeathMessage(entityKey, "death.attack.explosion");
      break;
    case EntityDamageCause2.campfire:
    case EntityDamageCause2.fire:
    case EntityDamageCause2.fireTick:
    case EntityDamageCause2.soulCampfire:
      sendDeathMessage(entityKey, "death.attack.inFire");
      break;
    case EntityDamageCause2.contact:
      if (damageSource.damagingEntity)
        sendDeathMessage(entityKey, "death.attack.mob", damageSource.damagingEntity);
      else sendDeathMessage(entityKey, "death.attack.cactus");
      break;
    case EntityDamageCause2.drowning:
      sendDeathMessage(entityKey, "death.attack.drown");
      break;
    case EntityDamageCause2.entityAttack:
    case EntityDamageCause2.ramAttack:
      sendDeathMessage(entityKey, "death.attack.mob", damageSource.damagingEntity);
      break;
    case EntityDamageCause2.fall:
      sendDeathMessage(entityKey, "death.attack.fall");
      break;
    case EntityDamageCause2.fallingBlock:
      sendDeathMessage(entityKey, "death.attack.fallingBlock");
      break;
    case EntityDamageCause2.fireworks:
      sendDeathMessage(entityKey, "death.attack.fireworks");
      break;
    case EntityDamageCause2.flyIntoWall:
      sendDeathMessage(entityKey, "death.attack.flyIntoWall");
      break;
    case EntityDamageCause2.freezing:
      sendDeathMessage(entityKey, "death.attack.freeze");
      break;
    case EntityDamageCause2.lava:
      sendDeathMessage(entityKey, "death.attack.lava");
      break;
    case EntityDamageCause2.lightning:
      sendDeathMessage(entityKey, "death.attack.lightningBolt");
      break;
    case EntityDamageCause2.maceSmash:
      sendDeathMessage(entityKey, "death.attack.maceSmash.player", damageSource.damagingEntity);
      break;
    case EntityDamageCause2.magic:
      sendDeathMessage(entityKey, "death.attack.magic");
      break;
    case EntityDamageCause2.magma:
      sendDeathMessage(entityKey, "death.attack.magma");
      break;
    case EntityDamageCause2.none:
    case EntityDamageCause2.override:
    case EntityDamageCause2.selfDestruct:
    case EntityDamageCause2.temperature:
      sendDeathMessage(entityKey, "death.attack.generic");
      break;
    case EntityDamageCause2.piston:
    case EntityDamageCause2.suffocation:
      sendDeathMessage(entityKey, "death.attack.inWall");
      break;
    case EntityDamageCause2.projectile:
      const entity = damageSource.damagingProjectile;
      if (entity.typeId == MinecraftEntityTypes.Arrow)
        sendDeathMessage(entityKey, "death.attack.arrow", entity.projectile.owner);
      else if (entity.typeId == MinecraftEntityTypes.ShulkerBullet)
        sendDeathMessage(entityKey, "death.attack.bullet", entity.projectile.owner);
      else if (entity.typeId == MinecraftEntityTypes.ThrownTrident)
        sendDeathMessage(entityKey, "death.attack.trident", entity.projectile.owner);
      else sendDeathMessage(entityKey, "death.attack.thrown", entity.projectile.owner);
      break;
    case EntityDamageCause2.sonicBoom:
      sendDeathMessage(entityKey, "death.attack.sonicBoom");
      break;
    case EntityDamageCause2.stalactite:
      sendDeathMessage(entityKey, "death.attack.stalagtite");
      break;
    case EntityDamageCause2.stalagmite:
      sendDeathMessage(entityKey, "death.attack.stalagmite");
      break;
    case EntityDamageCause2.starve:
      sendDeathMessage(entityKey, "death.attack.starve");
      break;
    case EntityDamageCause2.thorns:
      sendDeathMessage(entityKey, "death.attack.thorns", damageSource.damagingEntity);
      break;
    case EntityDamageCause2.void:
      sendDeathMessage(entityKey, "death.attack.outOfWorld");
      break;
    case EntityDamageCause2.wither:
      sendDeathMessage(entityKey, "death.attack.wither");
      break;
  }
}, { entityTypes: Object.keys(EntityAliases) });
function sendDeathMessage(entityKey, deathKey, killer) {
  const message = [{ translate: entityKey }];
  if (killer instanceof Player22)
    message.push({ translate: deathKey, with: ["", killer.name] });
  else if (killer)
    message.push(
      { translate: deathKey, with: ["", ""] },
      { translate: killer.localizationKey }
    );
  else message.push({ translate: deathKey, with: [""] });
  return world16.sendMessage(message);
}

// scripts/entity_events/wolf.ts
import { EntityComponentTypes as EntityComponentTypes2, EquipmentSlot as EquipmentSlot2, system as system17, TicksPerSecond as TicksPerSecond2, world as world17 } from "@minecraft/server";
var PET_DELAY = 0.5 * TicksPerSecond2;
var PetTimes = {};
world17.beforeEvents.playerInteractWithEntity.subscribe((event) => {
  const { player, target } = event;
  if (!target.isValid || !target.matches({ type: MinecraftEntityTypes.Wolf }) || !target.hasComponent(EntityComponentTypes2.IsTamed) || player.equipment.getEquipment(EquipmentSlot2.Mainhand) || Vec3.distance(player.location, target.location) > 1.5 || !player.isSneaking) return;
  event.cancel = true;
  if (system17.currentTick - (PetTimes[target.id] ?? 0) < PET_DELAY) return;
  PetTimes[target.id] = system17.currentTick;
  const { dimension } = player;
  system17.run(() => {
    dimension.playSound("wolf.pet", target.location);
    const variant = target.getProperty("minecraft:sound_variant");
    const sound = variant == "default" ? "mob.wolf.bark" : `mob.wolf.${variant}.bark`;
    dimension.playSound(sound, target.location);
    dimension.spawnParticle("minecraft:heart_particle", Vec3.above(target.location));
    player.playAnimation("animation.player.pet");
  });
});

// scripts/entity_events/faded_death.ts
import { MolangVariableMap as MolangVariableMap3, world as world18 } from "@minecraft/server";
world18.afterEvents.dataDrivenEntityTrigger.subscribe(({ entity, eventId }) => {
  const { location, dimension } = entity;
  if (eventId == "tcsmp:about_to_despawn") {
    const molang = new MolangVariableMap3();
    molang.setVector3("aabb", entity.getAABB().extent);
    dimension.spawnParticle("tcsmp:faded_wilter", location, molang);
    const sound = entity.typeId == "tcsmp:faded_zombie" ? "mob.faded_zombie.wilter" : "mob.faded_skeleton.wilter";
    dimension.playSound(sound, location, {
      pitch: randomRange(1.2, 1.4)
    });
  } else {
    const molang = new MolangVariableMap3();
    molang.setVector3("aabb", entity.getAABB().extent);
    dimension.spawnParticle("tcsmp:faded_death_explosion", location, molang);
    const sound = entity.typeId == "tcsmp:faded_zombie" ? "mob.faded_zombie.death" : "mob.faded_skeleton.death";
    dimension.playSound(sound, location, {
      pitch: randomRange(0.8, 1.2)
    });
    entity.remove();
  }
}, {
  eventTypes: [
    "tcsmp:about_to_despawn",
    "tcsmp:instant_despawn"
  ],
  entityTypes: [
    "tcsmp:faded_skeleton",
    "tcsmp:faded_zombie"
  ]
});

// scripts/entity_events/player.ts
import { EntityComponentTypes as EntityComponentTypes3, EntityDamageCause as EntityDamageCause3, Player as Player23, system as system18, world as world19 } from "@minecraft/server";
world19.beforeEvents.entityHurt.subscribe((event) => {
  var _a, _b;
  const damagingEntity = event.damageSource.damagingEntity ?? ((_b = (_a = event.damageSource.damagingProjectile) == null ? void 0 : _a.projectile) == null ? void 0 : _b.owner);
  if (event.damageSource.cause === EntityDamageCause3.fireTick && event.hurtEntity.isInvunerable) {
    event.cancel = true;
    system18.run(() => {
      event.hurtEntity.extinguishFire(false);
    });
  }
  if (!(damagingEntity instanceof Player23)) return;
  const faction = FactionRegistry.getFaction(damagingEntity);
  if (faction == null ? void 0 : faction.players.includes(event.hurtEntity.id)) {
    event.hurtEntity.setInvunerable();
    event.cancel = true;
  }
}, { entityFilter: { type: MinecraftEntityTypes.Player } });
var FoodTickTimer = {};
world19.afterEvents.entityHurt.subscribe(({ hurtEntity: player }) => {
  FoodTickTimer[player.id] = 0;
}, { entityTypes: [MinecraftEntityTypes.Player] });
world19.afterEvents.worldLoad.subscribe(() => {
  world19.gameRules.naturalRegeneration = false;
  system18.runInterval(() => {
    system18.runJob(handlePlayerHealing());
  });
});
function* handlePlayerHealing() {
  for (const player of world19.getAllPlayers()) {
    const health = player.getComponent(EntityComponentTypes3.Health);
    if (health.currentValue === health.effectiveMin) {
      FoodTickTimer[player.id] = Infinity;
      return player.onScreenDisplay.setTitle("flash: off");
    }
    const foodTickTimer = FoodTickTimer[player.id] ?? 0;
    FoodTickTimer[player.id] = foodTickTimer + 1;
    if (foodTickTimer < 6) {
      if (Math.floor(foodTickTimer / 2) % 2 === 0)
        player.onScreenDisplay.setTitle("flash: on");
      else player.onScreenDisplay.setTitle("flash: off");
    } else if (foodTickTimer === 6)
      player.onScreenDisplay.setTitle("flash: off");
    if (health.currentValue === health.effectiveMax) continue;
    const hunger = player.getComponent(EntityComponentTypes3.Hunger);
    if (hunger.currentValue <= 17) continue;
    const saturation = player.getComponent(EntityComponentTypes3.Saturation);
    const healDelay = hunger.currentValue === hunger.effectiveMax && saturation.currentValue >= saturation.effectiveMin + 1.5 ? 10 : 80;
    if (FoodTickTimer[player.id] < healDelay) continue;
    FoodTickTimer[player.id] = 0;
    player.onScreenDisplay.setTitle("flash: on");
    health.setCurrentValue(Math.min(health.currentValue + 1, health.effectiveMax));
    const exhaustion = player.getComponent(EntityComponentTypes3.Exhaustion);
    exhaustion.setCurrentValue(Math.min(exhaustion.currentValue + 6, exhaustion.effectiveMax));
    yield;
  }
}

// scripts/entity_events/villager.ts
import { EntityComponentTypes as EntityComponentTypes4, EntityDamageCause as EntityDamageCause4, ItemStack, world as world20 } from "@minecraft/server";
world20.afterEvents.entityDie.subscribe(({ deadEntity, damageSource }) => {
  if (damageSource.cause != EntityDamageCause4.fall) return;
  if (!deadEntity.hasComponent(EntityComponentTypes4.IsBaby)) return;
  deadEntity.dimension.spawnItem(
    new ItemStack("tcsmp:music_disc_drop_it"),
    deadEntity.location
  );
}, { entityTypes: ["minecraft:villager_v2"] });

// scripts/entity_events/zombie.ts
import { EntityComponentTypes as EntityComponentTypes5, ItemStack as ItemStack2, Player as Player24, system as system19, world as world21 } from "@minecraft/server";
world21.beforeEvents.entityItemPickup.subscribe(({ entity, item }) => {
  const itemStack = item.getComponent(EntityComponentTypes5.Item).itemStack;
  if (itemStack.typeId == "minecraft:leather_leggings")
    system19.run(() => {
      entity.addTag("tcsmp:wearing_leather_leggings");
    });
  else if (itemStack.typeId.endsWith("leggings"))
    system19.run(() => {
      entity.removeTag("tcsmp:wearing_leather_leggings");
    });
}, { entityFilter: { type: "minecraft:zombie" } });
world21.afterEvents.entityDie.subscribe(({ deadEntity, damageSource }) => {
  if (!(damageSource.damagingEntity instanceof Player24)) return;
  if (deadEntity.hasTag("tcsmp:wearing_leather_leggings"))
    deadEntity.dimension.spawnItem(
      new ItemStack2("tcsmp:music_disc_puma_pants"),
      deadEntity.location
    );
}, { entityTypes: ["minecraft:zombie"] });

// scripts/extensions/entities.ts
import { Entity as Entity5, EntityComponentTypes as EntityComponentTypes6, Player as Player25, system as system20, world as world22 } from "@minecraft/server";
Player25.prototype.stopSound = function(sound) {
  this.runCommand("stopsound @s " + sound);
};
var DamageTimes = {};
world22.afterEvents.entityHurt.subscribe(({ hurtEntity }) => {
  DamageTimes[hurtEntity.id] = system20.currentTick;
});
Object.defineProperties(Entity5.prototype, {
  inventory: {
    get() {
      if (!this.isValid) return void 0;
      else return this.getComponent(EntityComponentTypes6.Inventory);
    }
  },
  equipment: {
    get() {
      if (!this.isValid) return void 0;
      else return this.getComponent(EntityComponentTypes6.Equippable);
    }
  },
  projectile: {
    get() {
      if (!this.isValid) return void 0;
      else return this.getComponent(EntityComponentTypes6.Projectile);
    }
  },
  entityRidingOn: {
    get() {
      var _a;
      if (!this.isValid) return void 0;
      else return (_a = this.getComponent(EntityComponentTypes6.Riding)) == null ? void 0 : _a.entityRidingOn;
    }
  },
  leashHolder: {
    get() {
      var _a;
      if (!this.isValid) return void 0;
      else return (_a = this.getComponent(EntityComponentTypes6.Leashable)) == null ? void 0 : _a.leashHolder;
    }
  },
  isInvunerable: {
    get() {
      return system20.currentTick - (DamageTimes[this.id] ?? 0) < 10;
    }
  }
});
Entity5.prototype.addRider = function(rider) {
  const component = this.getComponent(EntityComponentTypes6.Rideable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Rideable);
  return component.addRider(rider);
};
Entity5.prototype.ejectRider = function(rider) {
  const component = this.getComponent(EntityComponentTypes6.Rideable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Rideable);
  return component.ejectRider(rider);
};
Entity5.prototype.ejectRiders = function() {
  const component = this.getComponent(EntityComponentTypes6.Rideable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Rideable);
  return component.ejectRiders();
};
Entity5.prototype.getRiders = function() {
  const component = this.getComponent(EntityComponentTypes6.Rideable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Rideable);
  return component.getRiders();
};
Entity5.prototype.dropInventory = function() {
  const component = this.getComponent(EntityComponentTypes6.Inventory);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Inventory);
  const { container, inventorySize } = component;
  for (let i = 0; i < inventorySize; ++i) {
    const slot = container == null ? void 0 : container.getSlot(i);
    if (!(slot == null ? void 0 : slot.hasItem())) continue;
    this.dimension.spawnItem(slot == null ? void 0 : slot.getItem(), this.location);
    slot.setItem();
  }
};
Entity5.prototype.leashTo = function(leashHolder) {
  const component = this.getComponent(EntityComponentTypes6.Leashable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Leashable);
  return component.leashTo(leashHolder);
};
Entity5.prototype.unleash = function() {
  const component = this.getComponent(EntityComponentTypes6.Leashable);
  if (!component) throw new MissingComponentError(EntityComponentTypes6.Leashable);
  return component.unleash();
};
Entity5.prototype.setInvunerable = function() {
  DamageTimes[this.id] = system20.currentTick;
};

// scripts/extensions/items.ts
import { ItemComponentTypes as ItemComponentTypes3, ItemStack as ItemStack4 } from "@minecraft/server";
Object.defineProperties(ItemStack4.prototype, {
  durability: {
    get() {
      return this.getComponent(ItemComponentTypes3.Durability);
    }
  },
  enchantable: {
    get() {
      return this.getComponent(ItemComponentTypes3.Enchantable);
    }
  }
});
ItemStack4.prototype.clone = function(type) {
  const item = new ItemStack4(type ?? this.type);
  item.amount = this.amount;
  item.nameTag = this.nameTag;
  item.lockMode = this.lockMode;
  item.keepOnDeath = this.keepOnDeath;
  if (this.durability) {
    if (!item.durability) throw new MissingComponentError(ItemComponentTypes3.Durability);
    item.durability.damage = this.durability.damage;
  }
  if (this.enchantable) {
    if (!item.enchantable) throw new MissingComponentError(ItemComponentTypes3.Enchantable);
    item.enchantable.addEnchantments(this.enchantable.getEnchantments());
  }
  return item;
};
ItemStack4.prototype.damage = function(amount = 1) {
  var _a, _b;
  const item = this.clone();
  if (!item.durability) throw new MissingComponentError(ItemComponentTypes3.Durability);
  const unbreaking = ((_b = (_a = item.enchantable) == null ? void 0 : _a.getEnchantment(MinecraftEnchantmentTypes.Unbreaking)) == null ? void 0 : _b.level) ?? 0;
  if (Math.random() > 1 / (unbreaking + 1)) return item;
  if (item.durability.damage + amount > item.durability.maxDurability)
    return void 0;
  item.durability.damage += amount;
  return item;
};

// scripts/extensions/dimensions.ts
import { Dimension } from "@minecraft/server";
Dimension.prototype.spawnLoot = function(location, loot_table) {
  this.runCommand(`loot spawn ${Vec3.toString(location)} loot "${loot_table}"`);
};

// scripts/extensions/components.ts
import { Container, ContainerSlot } from "@minecraft/server";
Container.prototype.firstMatch = function(pred) {
  for (let i = 0; i < this.size; ++i) {
    const slot = this.getSlot(i);
    if (!slot.hasItem()) continue;
    if (pred(slot.getItem())) return slot;
  }
  return void 0;
};
ContainerSlot.prototype.decrement = function() {
  if (!this.hasItem()) return;
  if (this.amount > 1)
    this.amount--;
  else this.setItem();
};

// scripts/item_components/spell_scroll.ts
import { MolangVariableMap as MolangVariableMap4 } from "@minecraft/server";
var spellScrollComponent = {
  onUse({ source }, parameters) {
    const { params } = parameters;
    const { dimension } = source;
    source.stopSound("random.bow");
    const head = source.getHeadLocation();
    dimension.playSound("scroll.cast", head, {
      pitch: randomRange(0.95, 1.05)
    });
    const vars = new MolangVariableMap4();
    const colour = Vec3.toRGB(Vec3.from(params.spell_colour));
    vars.setColorRGB("colour", colour);
    dimension.spawnParticle("tcsmp:spell_cast", head, vars);
  }
};
var spell_scroll_default = spellScrollComponent;

// scripts/item_components/return_spell.ts
import { system as system21, world as world23 } from "@minecraft/server";
world23.beforeEvents.itemUse.subscribe((event) => {
  const { itemStack, source } = event;
  if (!itemStack.hasComponent("tcsmp:return_spell")) return;
  if (source.getItemCooldown("spell") > 0) return;
  const waystones = WaystoneRegistry.get(source);
  if (waystones.length == 0) {
    event.cancel = true;
    const currentCooldown = source.getItemCooldown("spell");
    system21.run(() => {
      source.onScreenDisplay.setActionBar({ translate: "info.return_scroll.no_waystones" });
      if (currentCooldown == 0) source.startItemCooldown("spell", 0);
    });
  }
});
var returnSpellComponent = {
  onUse({ source }) {
    const closest = WaystoneRegistry.get(source).reduce((current, next) => {
      if (Vec3.distance(next.location, source.location) < Vec3.distance(current.location, source.location))
        return next;
      else return current;
    });
    source.playSound("waystone.teleport");
    source.camera.fade({
      fadeColor: { red: 0.914, green: 0.882, blue: 0.851 },
      fadeTime: {
        fadeInTime: 0,
        holdTime: 1,
        fadeOutTime: 0.8
      }
    });
    source.teleport(closest.location);
  }
};
var return_spell_default = returnSpellComponent;

// scripts/item_components/thunder_spell.ts
import { WeatherType, world as world24 } from "@minecraft/server";
var BOLT_COUNT = 12;
world24.beforeEvents.itemUse.subscribe((event) => {
  const { source, itemStack } = event, { dimension } = source;
  if (!itemStack.hasComponent("tcsmp:thunder_spell")) return;
  event.cancel = dimension.id != MinecraftDimensionTypes.Overworld;
});
var thunderSpellComponent = {
  onUse({ source }) {
    const { dimension } = source, head = source.getHeadLocation();
    for (let i = 0; i < BOLT_COUNT; ++i) {
      const sample = Vec2.toVectorXZ(randBoundedDisk(5, 15));
      const target = Vec3.add(head, Vec3.fromVectorXZ(sample));
      const block = dimension.getTopmostBlock(target, head.y + 2);
      if (!block) continue;
      const spawn_location = Vec3.above(block.bottomCenter());
      dimension.spawnEntity("minecraft:lightning_bolt", spawn_location);
    }
    dimension.setWeather(WeatherType.Thunder);
  }
};
var thunder_spell_default = thunderSpellComponent;

// scripts/item_components/growth_spell.ts
import { system as system22 } from "@minecraft/server";
var GROWTH_RANGE = Vec3.from(15, 7, 15);
var GROWTH_VOLUME = getRectPrism(GROWTH_RANGE).filter((u) => {
  return ellipsoidValue(GROWTH_RANGE, u) <= 1;
}).sort((u, v) => {
  return Vec3.dot(u, u) - Vec3.dot(v, v);
});
var SHORT_PLANTS = [
  MinecraftBlockTypes.ShortGrass,
  MinecraftBlockTypes.Fern,
  MinecraftBlockTypes.Dandelion,
  MinecraftBlockTypes.Poppy,
  MinecraftBlockTypes.BlueOrchid,
  MinecraftBlockTypes.Allium,
  MinecraftBlockTypes.AzureBluet,
  MinecraftBlockTypes.RedTulip,
  MinecraftBlockTypes.OrangeTulip,
  MinecraftBlockTypes.WhiteTulip,
  MinecraftBlockTypes.PinkTulip,
  MinecraftBlockTypes.OxeyeDaisy,
  MinecraftBlockTypes.Cornflower,
  MinecraftBlockTypes.LilyOfTheValley
];
var TALL_PLANTS = [
  MinecraftBlockTypes.TallGrass,
  MinecraftBlockTypes.LargeFern,
  MinecraftBlockTypes.Lilac,
  MinecraftBlockTypes.RoseBush,
  MinecraftBlockTypes.Peony
];
var WATER_PLANTS = [
  MinecraftBlockTypes.Seagrass,
  MinecraftBlockTypes.SeaPickle,
  MinecraftBlockTypes.FireCoral,
  MinecraftBlockTypes.FireCoralFan,
  MinecraftBlockTypes.BrainCoral,
  MinecraftBlockTypes.BrainCoralFan,
  MinecraftBlockTypes.BubbleCoral,
  MinecraftBlockTypes.BubbleCoralFan,
  MinecraftBlockTypes.TubeCoral,
  MinecraftBlockTypes.TubeCoralFan,
  MinecraftBlockTypes.HornCoral,
  MinecraftBlockTypes.HornCoralFan
];
var growthSpellComponent = {
  onUse(event) {
    const { source } = event, { location, dimension } = source;
    system22.runJob(growth(location, dimension));
  }
};
function* growth(location, dimension) {
  for (const offset of GROWTH_VOLUME) {
    const value = ellipsoidValue(GROWTH_RANGE, offset);
    const target = Vec3.add(location, offset);
    if (!within(target.y, dimension.heightRange)) continue;
    const block = dimension.getBlock(target);
    if (block) applyGrowth(block, value);
    yield;
  }
}
var growth_spell_default = growthSpellComponent;
function applyGrowth(block, value) {
  var _a, _b, _c, _d;
  const { dimension, permutation } = block, { heightRange } = dimension;
  const rand = Math.random();
  const place = value * rand < 0.5;
  const tall = value * rand < 0.08 && block.y < heightRange.max;
  const variant = rand < 0.5;
  if (rand < 0.015)
    dimension.spawnParticle("minecraft:crop_growth_area_emitter", block.center());
  switch (block.typeId) {
    case MinecraftBlockTypes.Dirt:
      if (block.y == heightRange.max) break;
      const above = block.above(), is_deadbush = above == null ? void 0 : above.matches(MinecraftBlockTypes.Deadbush);
      if (!(above == null ? void 0 : above.matches(MinecraftBlockTypes.Air)) && !is_deadbush) break;
      block.setType(MinecraftBlockTypes.GrassBlock);
      if (is_deadbush) above == null ? void 0 : above.setType(MinecraftBlockTypes.ShortGrass);
      break;
    case MinecraftBlockTypes.CoarseDirt:
      block.setType(MinecraftBlockTypes.Dirt);
      if (block.y == heightRange.max) break;
      if ((_a = block.above()) == null ? void 0 : _a.matches(MinecraftBlockTypes.Deadbush))
        (_b = block.above()) == null ? void 0 : _b.setType(MinecraftBlockTypes.Air);
      break;
    case MinecraftBlockTypes.Air:
      if (!place) break;
      if (block.y == heightRange.min) break;
      if (!((_c = block.below()) == null ? void 0 : _c.matches(MinecraftBlockTypes.GrassBlock))) break;
      if (variant) {
        const typeId = tall ? randomElement(TALL_PLANTS) : randomElement(SHORT_PLANTS);
        block.setType(typeId);
      } else block.setType(tall ? MinecraftBlockTypes.TallGrass : MinecraftBlockTypes.ShortGrass);
      break;
    case MinecraftBlockTypes.Water:
    case MinecraftBlockTypes.FlowingWater:
      if (!place) break;
      if (block.y == heightRange.min) break;
      const below = block.below();
      if (!(below == null ? void 0 : below.matches(MinecraftBlockTypes.Gravel)) && !(below == null ? void 0 : below.matches(MinecraftBlockTypes.Sand))) break;
      if (tall) {
        block.setType(MinecraftBlockTypes.Seagrass);
        const above2 = block.above();
        if (above2 == null ? void 0 : above2.isLiquid) {
          block.setPermutation(block.permutation.withState("sea_grass_type", "double_bot"));
          above2.setPermutation(block.permutation.withState("sea_grass_type", "double_top"));
        }
      } else block.setType(variant ? randomElement(WATER_PLANTS) : MinecraftBlockTypes.Seagrass);
      break;
    case MinecraftBlockTypes.Fern:
      if (block.location.y == heightRange.max) break;
      if (!((_d = block.above()) == null ? void 0 : _d.matches(MinecraftBlockTypes.Air))) break;
      dimension.spawnParticle("minecraft:crop_growth_emitter", block.center());
      block.setType(MinecraftBlockTypes.LargeFern);
      break;
    case MinecraftBlockTypes.PitcherCrop:
      dimension.spawnParticle("minecraft:crop_growth_emitter", block.center());
      block.setPermutation(permutation.withState("growth", 2));
      break;
    case MinecraftBlockTypes.Wheat:
    case MinecraftBlockTypes.Carrots:
    case MinecraftBlockTypes.Potatoes:
    case MinecraftBlockTypes.PumpkinStem:
    case MinecraftBlockTypes.MelonStem:
    case MinecraftBlockTypes.Beetroot:
    case MinecraftBlockTypes.SweetBerryBush:
    case MinecraftBlockTypes.TorchflowerCrop:
      dimension.spawnParticle("minecraft:crop_growth_emitter", block.center());
      block.setPermutation(permutation.withState("growth", 7));
      break;
    case "tcsmp:tomato":
      dimension.spawnParticle("minecraft:crop_growth_emitter", block.center());
      block.setPermutation(permutation.withState("tcsmp:growth_stage", 2));
      break;
  }
}

// scripts/item_components/decay_spell.ts
import { system as system23 } from "@minecraft/server";
var DECAY_RANGE = Vec3.from(15, 7, 15);
var DECAY_VOLUME = getRectPrism(DECAY_RANGE).filter((u) => {
  return ellipsoidValue(DECAY_RANGE, u) <= 1;
}).sort((u, v) => {
  return Vec3.dot(u, u) - Vec3.dot(v, v);
});
var decaySpellComponent = {
  onUse(event) {
    const { source } = event, { location, dimension } = source;
    system23.runJob(decay(location, dimension));
  }
};
function* decay(location, dimension) {
  for (const offset of DECAY_VOLUME) {
    const value = ellipsoidValue(DECAY_RANGE, offset);
    const target = Vec3.add(location, offset);
    if (!within(target.y, dimension.heightRange)) continue;
    const block = dimension.getBlock(target);
    if (block) applyDecay(block, value);
    yield;
  }
}
var decay_spell_default = decaySpellComponent;
function applyDecay(block, value) {
  const { dimension, permutation } = block, { heightRange } = dimension;
  const rand = Math.random();
  const coarse = value * rand < 0.08;
  const deadbush = rand < 0.25;
  const deadbushId = MinecraftBlockTypes.Deadbush;
  const coarseDirtId = MinecraftBlockTypes.CoarseDirt;
  const airId = MinecraftBlockTypes.Air;
  const dirtId = MinecraftBlockTypes.Dirt;
  switch (block.typeId) {
    case MinecraftBlockTypes.Dirt:
    case MinecraftBlockTypes.GrassBlock:
      block.setType(coarse ? coarseDirtId : dirtId);
      if (block.y == heightRange.max) break;
      const above = block.above();
      if (!deadbush || !(above == null ? void 0 : above.matches(airId))) break;
      above.setType(deadbushId);
      break;
    case MinecraftBlockTypes.ShortGrass:
    case MinecraftBlockTypes.Fern:
    case MinecraftBlockTypes.Dandelion:
    case MinecraftBlockTypes.Poppy:
    case MinecraftBlockTypes.BlueOrchid:
    case MinecraftBlockTypes.Allium:
    case MinecraftBlockTypes.AzureBluet:
    case MinecraftBlockTypes.RedTulip:
    case MinecraftBlockTypes.OrangeTulip:
    case MinecraftBlockTypes.WhiteTulip:
    case MinecraftBlockTypes.PinkTulip:
    case MinecraftBlockTypes.OxeyeDaisy:
    case MinecraftBlockTypes.Cornflower:
    case MinecraftBlockTypes.LilyOfTheValley:
      const typeId = deadbush ? deadbushId : airId;
      block.setType(typeId);
      break;
    case MinecraftBlockTypes.LargeFern:
    case MinecraftBlockTypes.Lilac:
    case MinecraftBlockTypes.RoseBush:
    case MinecraftBlockTypes.Peony:
      const top_double_plant = permutation.getState("upper_block_bit");
      const replace_double_plant = top_double_plant ? block.below() : block;
      replace_double_plant == null ? void 0 : replace_double_plant.setType(airId);
      break;
    case MinecraftBlockTypes.TallGrass:
      const top_grass = permutation.getState("upper_block_bit");
      const replace_grass = top_grass ? block : block.above();
      replace_grass == null ? void 0 : replace_grass.setType(airId);
      block.setType(airId);
      break;
    case MinecraftBlockTypes.PitcherCrop:
    case MinecraftBlockTypes.Wheat:
    case MinecraftBlockTypes.Carrots:
    case MinecraftBlockTypes.Potatoes:
    case MinecraftBlockTypes.PumpkinStem:
    case MinecraftBlockTypes.MelonStem:
    case MinecraftBlockTypes.Beetroot:
    case MinecraftBlockTypes.SweetBerryBush:
    case MinecraftBlockTypes.TorchflowerCrop:
      block.setType(airId);
      break;
    case MinecraftBlockTypes.Farmland:
      block.setPermutation(permutation.withState("moisturized_amount", 0));
      break;
  }
}

// scripts/item_components/grappling_hook.ts
import { GameMode as GameMode3, ItemLockMode, Player as Player26, system as system24, TicksPerSecond as TicksPerSecond3, world as world25 } from "@minecraft/server";

// behaviours/items/grappling_hook/grappling_hook.item.json
var grappling_hook_item_default = {
  format_version: "1.26.30",
  "minecraft:item": {
    description: {
      identifier: "tcsmp:grappling_hook",
      menu_category: {
        category: "equipment"
      }
    },
    components: {
      "tcsmp:grappling_hook": {},
      "minecraft:max_stack_size": 1,
      "minecraft:display_name": {
        value: "item.tcsmp:grappling_hook.name"
      },
      "minecraft:icon": {
        textures: {
          default: "grappling_hook"
        }
      },
      "minecraft:use_modifiers": {
        movement_modifier: 0.35,
        use_duration: 500
      },
      "minecraft:shooter": {
        charge_on_draw: false,
        max_draw_duration: 1
      },
      "minecraft:repairable": {
        repair_items: [{
          items: ["minecraft:copper_ingot"],
          repair_amount: 128
        }]
      },
      "minecraft:durability": {
        max_durability: 128
      },
      "minecraft:enchantable": {
        slot: "shield",
        value: 10
      }
    }
  }
};

// scripts/item_components/grappling_hook.ts
var USE_TIME = TicksPerSecond3 * grappling_hook_item_default["minecraft:item"].components["minecraft:shooter"].max_draw_duration;
var MAX_DURATION = TicksPerSecond3 * grappling_hook_item_default["minecraft:item"].components["minecraft:use_modifiers"].use_duration;
var GRAPPLE_SOUNDS = [
  "grappling_hook.retract.short",
  "grappling_hook.retract.medium",
  "grappling_hook.retract.long"
];
world25.afterEvents.itemReleaseUse.subscribe((event) => {
  var _a, _b;
  const { itemStack, source, useDuration } = event;
  if ((itemStack == null ? void 0 : itemStack.typeId) != "tcsmp:grappling_hook") return;
  source.stopSound("grappling_hook.loading.start");
  if (MAX_DURATION - useDuration < USE_TIME) return;
  const { inventory, dimension, location } = source;
  (_a = source.entityRidingOn) == null ? void 0 : _a.ejectRider(source);
  const slot = (_b = inventory.container) == null ? void 0 : _b.getSlot(source.selectedSlotIndex);
  const empty_hook = itemStack.clone("tcsmp:empty_grappling_hook");
  empty_hook.lockMode = ItemLockMode.slot;
  slot == null ? void 0 : slot.setItem(empty_hook);
  const view = source.getViewDirection(), head = source.getHeadLocation();
  const stake = dimension.spawnEntity("tcsmp:grappling_hook_stake", head);
  const seat = dimension.spawnEntity("tcsmp:grappling_hook_seat", location);
  const seat2 = dimension.spawnEntity("tcsmp:grappling_hook_seat", location);
  seat.addRider(seat2);
  seat.leashTo(stake);
  stake.setDynamicProperty("seat", seat.id);
  const projectile = stake.projectile;
  projectile.owner = source;
  projectile.shoot(Vec3.mul(view, 2));
  source.dimension.playSound("grappling_hook.shoot", head);
  const interval = system24.runInterval(() => {
    var _a2;
    if (Vec3.distance(stake.location, source.getHeadLocation()) <= 48) {
      seat.teleport(source.location);
      return;
    }
    seat.remove();
    stake.remove();
    seat2.remove();
    const hook = (_a2 = slot == null ? void 0 : slot.getItem()) == null ? void 0 : _a2.clone("tcsmp:grappling_hook");
    slot == null ? void 0 : slot.setItem(hook);
    slot.lockMode = ItemLockMode.none;
    source.dimension.playSound("leashknot.break", source.getHeadLocation());
    system24.clearRun(interval);
  });
  stake.setDynamicProperty("interval", interval);
});
world25.afterEvents.projectileHitBlock.subscribe(({ projectile: stake, source: player }) => {
  if (!stake.isValid || !(player instanceof Player26) || !player.isValid) return;
  if (!stake.matches({ type: "tcsmp:grappling_hook_stake" })) return;
  system24.clearRun(stake.getDynamicProperty("interval"));
  const seat = world25.getEntity(stake.getDynamicProperty("seat"));
  seat == null ? void 0 : seat.teleport(Vec3.above(seat.location, 0.1));
  const playerSeat = seat == null ? void 0 : seat.getRiders()[0];
  playerSeat == null ? void 0 : playerSeat.addRider(player);
  const head = player.getHeadLocation();
  player.dimension.playSound("leashknot.place", head);
  seat == null ? void 0 : seat.triggerEvent("tcsmp:retract");
  const dist = Vec3.distance(stake.location, head);
  const sound = GRAPPLE_SOUNDS[clamp(Math.floor(3 * dist / 48), 0, 2)];
  player.playSound(sound);
  const interval = system24.runInterval(() => {
    if ((playerSeat == null ? void 0 : playerSeat.isValid) && ((playerSeat == null ? void 0 : playerSeat.getRiders().length) ?? 0) > 0) return;
    player.stopSound(sound);
    for (const entity of [playerSeat, seat, stake])
      if (entity == null ? void 0 : entity.isValid) entity.remove();
    const slot = player.inventory.container.firstMatch((item) => item.typeId === "tcsmp:empty_grappling_hook");
    if (!slot) return;
    const hook = slot.getItem().clone("tcsmp:grappling_hook");
    hook.lockMode = ItemLockMode.none;
    slot.setItem(hook);
    slot.setItem(player.getGameMode() === GameMode3.Creative ? hook : hook.damage());
    if (!(slot == null ? void 0 : slot.hasItem()))
      player.dimension.playSound(
        "random.break",
        player.getHeadLocation(),
        { pitch: 0.9 }
      );
    else player.dimension.playSound("leashknot.break", player.getHeadLocation());
    system24.clearRun(interval);
  });
});
world25.afterEvents.playerSpawn.subscribe((event) => {
  const { player, initialSpawn } = event;
  if (!initialSpawn) return;
  system24.runTimeout(() => {
    var _a, _b, _c;
    if (!((_a = player.entityRidingOn) == null ? void 0 : _a.matches({ type: "tcsmp:grappling_hook_seat" }))) return;
    const playerSeat = player.entityRidingOn;
    const seat = playerSeat.entityRidingOn;
    const stake = seat == null ? void 0 : seat.leashHolder;
    playerSeat.ejectRider(player);
    for (const entity of [playerSeat, seat, stake])
      if (entity == null ? void 0 : entity.isValid) entity.remove();
    const slot = (_b = player.inventory.container) == null ? void 0 : _b.firstMatch((item) => item.typeId === "tcsmp:empty_grappling_hook");
    let hook = (_c = slot == null ? void 0 : slot.getItem()) == null ? void 0 : _c.clone("tcsmp:grappling_hook");
    hook.lockMode = ItemLockMode.none;
    slot == null ? void 0 : slot.setItem(player.getGameMode() === GameMode3.Creative ? hook : hook.damage());
    if (!(slot == null ? void 0 : slot.hasItem()))
      player.dimension.playSound("random.break", player.getHeadLocation());
    else player.dimension.playSound("leashknot.break", player.getHeadLocation());
  }, 5);
});
var grapplingHookComponent = {
  onUse({ source }) {
    const { dimension } = source;
    dimension.playSound("grappling_hook.loading.start", source.getHeadLocation());
  }
};
var grappling_hook_default = grapplingHookComponent;

// scripts/item_components/katana.ts
import { EntityDamageCause as EntityDamageCause5, GameMode as GameMode4, ItemComponentTypes as ItemComponentTypes4, ItemLockMode as ItemLockMode2, MolangVariableMap as MolangVariableMap5, system as system25, TicksPerSecond as TicksPerSecond4, world as world26 } from "@minecraft/server";

// behaviours/items/katana.item.json
var katana_item_default = {
  format_version: "1.26.20",
  "minecraft:item": {
    description: {
      identifier: "tcsmp:katana",
      menu_category: {
        category: "equipment"
      }
    },
    components: {
      "tcsmp:katana": {},
      "tcsmp:durability_fix": {},
      "minecraft:max_stack_size": 1,
      "minecraft:display_name": {
        value: "item.tcsmp:katana.name"
      },
      "minecraft:icon": {
        textures: {
          default: "katana"
        }
      },
      "minecraft:hand_equipped": true,
      "minecraft:can_destroy_in_creative": false,
      "minecraft:damage": 6,
      "minecraft:enchantable": {
        slot: "sword",
        value: 10
      },
      "minecraft:shooter": {
        charge_on_draw: false,
        max_draw_duration: 500
      },
      "minecraft:use_modifiers": {
        use_duration: 500,
        movement_modifier: 0.5
      },
      "minecraft:durability": {
        max_durability: 250
      },
      "minecraft:repairable": {
        repair_items: [{
          items: [
            "minecraft:iron_ingot"
          ],
          repair_amount: 62
        }]
      },
      "minecraft:rarity": "rare",
      "minecraft:tags": {
        tags: [
          "minecraft:is_sword",
          "minecraft:is_tool",
          "minecraft:iron_tier"
        ]
      }
    }
  }
};

// scripts/item_components/katana.ts
var MAX_DURATION2 = TicksPerSecond4 * katana_item_default["minecraft:item"].components["minecraft:use_modifiers"].use_duration;
var USE_TIME2 = TicksPerSecond4 * 0.5;
var DASH_SPEED = 4;
var AIR_DASH_SPEED = 0.75;
var DASH_TIME = TicksPerSecond4 * 0.2;
var ParticleIntervals = {};
world26.afterEvents.itemReleaseUse.subscribe((event) => {
  const { source, itemStack, useDuration } = event, { dimension } = source;
  if (!(itemStack == null ? void 0 : itemStack.hasComponent("tcsmp:katana"))) return;
  const particles = ParticleIntervals[source.id];
  if (particles) system25.clearRun(particles);
  if (MAX_DURATION2 - useDuration < USE_TIME2)
    return source.stopSound("katana.draw");
  const head = source.getHeadLocation();
  source.dimension.playSound("katana.dash", head);
  const view = source.getViewDirection();
  const direction = Vec3.normalize(Vec3.from(view.x, 0, view.z));
  if (!source.isOnGround || source.isInWater)
    return source.applyImpulse(Vec3.mul(direction, AIR_DASH_SPEED));
  source.applyImpulse(Vec3.mul(direction, DASH_SPEED));
  const molang = new MolangVariableMap5();
  molang.setVector3("direction", direction);
  dimension.spawnParticle("tcsmp:katana_dash", source.location, molang);
  const slot = source.inventory.container.getSlot(source.selectedSlotIndex);
  slot.lockMode = ItemLockMode2.slot;
  let ticks = 0, hits = 0;
  const hitEntityIds = [];
  const interval = system25.runInterval(() => {
    const entities = dimension.getEntities({
      location: source.location,
      maxDistance: 4.5,
      excludeNames: [source.name],
      excludeTypes: ["minecraft:item"]
    });
    for (const entity of entities) {
      if (hitEntityIds.find((id) => id === entity.id)) continue;
      const to_entity = Vec3.sub(entity.location, source.location);
      if (Vec3.dot(to_entity, direction) < 0) continue;
      hits += +applyKatanaDamage(itemStack, source, entity);
      hitEntityIds.push(entity.id);
    }
    if (ticks === DASH_TIME) {
      slot.lockMode = ItemLockMode2.none;
      if (source.getGameMode() !== GameMode4.Creative && hits) {
        slot.setItem(itemStack.damage(hits));
        if (!slot.hasItem()) dimension.playSound(
          "random.break",
          source.getHeadLocation(),
          { pitch: 0.9 }
        );
      }
      return system25.clearRun(interval);
    } else ++ticks;
  });
});
function applyKatanaDamage(katana, attacker, target) {
  const undead = target.matches({ families: ["undead"] });
  const arthropod = target.matches({ families: ["arthropod"] });
  const enchantable = katana.getComponent(ItemComponentTypes4.Enchantable);
  const getEnchantmentLevel = (id) => {
    var _a;
    return ((_a = enchantable == null ? void 0 : enchantable.getEnchantment(id)) == null ? void 0 : _a.level) ?? 0;
  };
  const bane_of_arthropods = getEnchantmentLevel(MinecraftEnchantmentTypes.BaneOfArthropods);
  const fire_aspect = getEnchantmentLevel(MinecraftEnchantmentTypes.FireAspect);
  const sharpness = getEnchantmentLevel(MinecraftEnchantmentTypes.Sharpness);
  const smite = getEnchantmentLevel(MinecraftEnchantmentTypes.Smite);
  const sharp_damage = Math.floor(1.25 * sharpness);
  const smite_damage = undead ? Math.floor(2.5 * smite) : 0;
  const bane_damage = arthropod ? Math.floor(2.5 * bane_of_arthropods) : 0;
  const damage = 6 + sharp_damage + smite_damage + bane_damage;
  const onFireTime = 4 * fire_aspect;
  const hit2 = target.applyDamage(damage, {
    cause: EntityDamageCause5.entityAttack,
    damagingEntity: attacker
  });
  if (hit2 && onFireTime) target.setOnFire(onFireTime);
  return hit2;
}
var katanaComponent = {
  onUse({ source }) {
    source.stopSound("katana.draw");
    source.playSound("katana.draw");
    const particles = ParticleIntervals[source.id];
    if (particles) system25.clearRun(particles);
    const { dimension } = source;
    ParticleIntervals[source.id] = system25.runInterval(() => {
      dimension.spawnParticle("tcsmp:katana_charge", source.location);
    }, 2);
  }
};
var katana_default = katanaComponent;

// scripts/item_components/random_exp_damage.ts
import { EntityDamageCause as EntityDamageCause6, EquipmentSlot as EquipmentSlot3, world as world27 } from "@minecraft/server";
world27.beforeEvents.entityHurt.subscribe((event) => {
  var _a;
  const { damageSource } = event, damagingEntity = damageSource.damagingEntity;
  const damagingItem = (_a = damagingEntity.equipment) == null ? void 0 : _a.getEquipment(EquipmentSlot3.Mainhand);
  const component = damagingItem == null ? void 0 : damagingItem.getComponent("tcsmp:random_exp_damage");
  if (!component) return;
  const params = component.customComponentParameters.params;
  let damage = event.damage + roundTo(randomExp(params.mean_damage), 1);
  event.damage = damage;
}, { allowedDamageCauses: [EntityDamageCause6.entityAttack] });
var randomExpDamageComponent = {};
var random_exp_damage_default = randomExpDamageComponent;

// scripts/item_components/lucks_bane.ts
import { EquipmentSlot as EquipmentSlot4, MolangVariableMap as MolangVariableMap6, system as system26, world as world28 } from "@minecraft/server";
world28.afterEvents.entityHurt.subscribe((event) => {
  var _a, _b;
  const { damage, damageSource, hurtEntity } = event;
  if (!hurtEntity.isValid) return;
  const { damagingEntity } = damageSource, { dimension } = hurtEntity;
  const weapon = (_a = damagingEntity == null ? void 0 : damagingEntity.equipment) == null ? void 0 : _a.getEquipmentSlot(EquipmentSlot4.Mainhand);
  if (!((_b = weapon == null ? void 0 : weapon.getItem()) == null ? void 0 : _b.hasComponent("tcsmp:lucks_bane"))) return;
  dimension.playSound("lucks_bane.coins", Vec3.above(hurtEntity.location));
  dimension.spawnParticle("tcsmp:lucks_bane_coin", Vec3.above(hurtEntity.location));
  const toEntity = Vec3.normalize(Vec3.sub(
    hurtEntity.getHeadLocation(),
    damagingEntity.getHeadLocation()
  ));
  const target = Vec3.sub(hurtEntity.getHeadLocation(), toEntity);
  for (let i = 0; i < damage; i += 2) {
    system26.runTimeout(() => {
      dimension.playSound("lucks_bane.big_hit", target);
      const molang = new MolangVariableMap6();
      molang.setFloat("half", +(Math.floor(damage - i) == 1));
      dimension.spawnParticle("tcsmp:lucks_bane_heart", target, molang);
    }, i);
  }
});
var lucksBaneComponent = {};
var lucks_bane_default = lucksBaneComponent;

// scripts/item_components/backstab.ts
import { EntityDamageCause as EntityDamageCause7, EquipmentSlot as EquipmentSlot5, system as system27, TicksPerSecond as TicksPerSecond5, world as world29 } from "@minecraft/server";
var BackstabTimes = {};
var BACKSTAB_DELAY = 1.5 * TicksPerSecond5;
var ENTITY_ANGLE = Math.PI / 3;
var COS_ENTITY = Math.cos(ENTITY_ANGLE);
var LOOK_ANGLE = 3 * Math.PI / 5;
var COS_LOOK = Math.cos(LOOK_ANGLE);
world29.beforeEvents.entityHurt.subscribe((event) => {
  var _a;
  const { damageSource, hurtEntity } = event, { damagingEntity } = damageSource;
  const item = (_a = damagingEntity.equipment) == null ? void 0 : _a.getEquipment(EquipmentSlot5.Mainhand);
  const component = item == null ? void 0 : item.getComponent("tcsmp:backstab");
  const lastBackstabbedTick = BackstabTimes[hurtEntity.id] ?? 0;
  if (!component || system27.currentTick - lastBackstabbedTick < BACKSTAB_DELAY) return;
  else BackstabTimes[hurtEntity.id] = system27.currentTick;
  const params = component.customComponentParameters.params;
  const { dimension } = hurtEntity;
  const view = damagingEntity.getViewDirection();
  const head = damagingEntity.getHeadLocation();
  const targetView = hurtEntity.getViewDirection();
  const targetHead = hurtEntity.getHeadLocation();
  const toEntity = Vec3.normalize(Vec3.sub(targetHead, head));
  if (Vec3.dot(toEntity, view) < COS_ENTITY) return;
  if (Vec3.dot(targetView, view) < COS_LOOK) return;
  event.damage += params.extra_damage;
  system27.run(() => {
    dimension.playSound("knife.backstab", hurtEntity.location);
    dimension.spawnParticle("tcsmp:backstab", Vec3.sub(targetHead, toEntity));
  });
}, { allowedDamageCauses: [EntityDamageCause7.entityAttack] });
var backstabComponent = {};
var backstab_default = backstabComponent;

// scripts/item_components/gerbil.ts
import { EntityComponentTypes as EntityComponentTypes7, EquipmentSlot as EquipmentSlot6, ItemStack as ItemStack8, Player as Player27, system as system28, TicksPerSecond as TicksPerSecond6, world as world30 } from "@minecraft/server";
var PICKUP_DELAY = 0.25 * TicksPerSecond6;
var PickupTimes = {};
world30.afterEvents.playerInteractWithEntity.subscribe((event) => {
  const { player, target, itemStack } = event;
  if (!target.isValid || !player.isValid) return;
  if (!target.matches({ type: "tcsmp:gerbil" })) return;
  if (target.getComponent(EntityComponentTypes7.IsBaby)) return;
  if (itemStack) return;
  const tameable = target.getComponent(EntityComponentTypes7.Tameable);
  if ((tameable == null ? void 0 : tameable.tamedToPlayerId) != player.id) return;
  const item = new ItemStack8("tcsmp:gerbil");
  if (target.nameTag != "\xA7G\xA7E\xA7R\xA7B\xA7I\xA7L")
    item.nameTag = target.nameTag;
  target.remove();
  player.equipment.getEquipmentSlot(EquipmentSlot6.Mainhand).setItem(item);
  const head = player.getHeadLocation();
  player.dimension.playSound("random.pop", head, {
    pitch: randomRange(0.6, 2.2),
    volume: 0.25
  });
  PickupTimes[player.id] = system28.currentTick;
});
var gerbilComponent = {
  onUseOn(event) {
    const { source, itemStack, faceLocation, block, blockFace } = event;
    if (!(source instanceof Player27)) return;
    const lastPickedUpTime = PickupTimes[source.id] ?? 0;
    if (system28.currentTick - lastPickedUpTime < PICKUP_DELAY) return;
    const offset = Vec3.saturate(Vec3.fromDirection(blockFace));
    const target = Vec3.add(block, faceLocation, offset);
    const gerbil = source.dimension.spawnEntity("tcsmp:gerbil", target);
    gerbil.nameTag = itemStack.nameTag ?? "\xA7G\xA7E\xA7R\xA7B\xA7I\xA7L";
    gerbil.triggerEvent("tcsmp:grow_up");
    const tameable = gerbil.getComponent(EntityComponentTypes7.Tameable);
    tameable.tame(source);
    const head = source.getHeadLocation();
    gerbil.lookAt(head);
    source.equipment.getEquipmentSlot(EquipmentSlot6.Mainhand).setItem();
    source.dimension.playSound("random.pop", head, {
      pitch: randomRange(0.55, 0.75),
      volume: 0.3
    });
  }
};
var gerbil_default = gerbilComponent;

// scripts/item_components/random_effect_on_hit.ts
import { EffectTypes, EquipmentSlot as EquipmentSlot7, TicksPerSecond as TicksPerSecond7, world as world31 } from "@minecraft/server";
var randomEffectOnHitComponent = {};
world31.afterEvents.entityHitEntity.subscribe((event) => {
  const { hitEntity } = event;
  if (!hitEntity.equipment) return;
  const armour = [
    hitEntity.equipment.getEquipment(EquipmentSlot7.Head),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Chest),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Legs),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Feet)
  ];
  for (const item of armour) {
    if (item == null ? void 0 : item.hasComponent("tcsmp:random_effect_on_hit")) {
      const effect = randomElement(EffectTypes.getAll());
      return hitEntity.addEffect(effect, TicksPerSecond7 * 3);
    }
  }
});
world31.afterEvents.projectileHitEntity.subscribe((event) => {
  const hitEntity = event.getEntityHit().entity;
  if (!(hitEntity == null ? void 0 : hitEntity.isValid)) return;
  if (!hitEntity.equipment) return;
  const armour = [
    hitEntity.equipment.getEquipment(EquipmentSlot7.Head),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Chest),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Legs),
    hitEntity.equipment.getEquipment(EquipmentSlot7.Feet)
  ];
  for (const item of armour) {
    if (item == null ? void 0 : item.hasComponent("tcsmp:random_effect_on_hit")) {
      const effect = randomElement(EffectTypes.getAll());
      if (Math.random() <= 0.5)
        return hitEntity.addEffect(effect, TicksPerSecond7 * 3);
    }
  }
});
var random_effect_on_hit_default = randomEffectOnHitComponent;

// scripts/item_components/global_cooldown.ts
import { ItemComponentTypes as ItemComponentTypes5, world as world32 } from "@minecraft/server";
var globalCooldownComponent = {
  onUse(event) {
    var _a;
    const cooldown = (_a = event.itemStack) == null ? void 0 : _a.getComponent(ItemComponentTypes5.Cooldown);
    for (const player of world32.getAllPlayers()) cooldown == null ? void 0 : cooldown.startCooldown(player);
  }
};
var global_cooldown_default = globalCooldownComponent;

// scripts/item_components/auto_lore.ts
import { world as world33 } from "@minecraft/server";
world33.afterEvents.playerInventoryItemChange.subscribe((event) => {
  var _a;
  const component = (_a = event.itemStack) == null ? void 0 : _a.getComponent("tcsmp:auto_lore");
  if (!component) return;
  const lore_key = component.customComponentParameters.params.lore;
  const itemSlot = event.player.inventory.container.getSlot(event.slot);
  itemSlot.setLore([{ translate: lore_key }]);
});
var autoLoreComponent = {};
var auto_lore_default = autoLoreComponent;

// scripts/item_components/durability_fix.ts
import { EquipmentSlot as EquipmentSlot8, GameMode as GameMode5, world as world34 } from "@minecraft/server";
var BlockBreakCost = {
  "minecraft:is_axe": 1,
  "minecraft:is_pickaxe": 1,
  "minecraft:is_shovel": 1,
  "minecraft:is_hoe": 1,
  "minecraft:is_shears": 1,
  "minecraft:is_sword": 2,
  "minecraft:is_trident": 2
};
var EntityAttackCost = {
  "minecraft:is_axe": 2,
  "minecraft:is_pickaxe": 2,
  "minecraft:is_shovel": 2,
  "minecraft:is_hoe": 2,
  "minecraft:is_shears": 0,
  "minecraft:is_sword": 1,
  "minecraft:is_trident": 1
};
world34.afterEvents.playerBreakBlock.subscribe((event) => {
  const { itemStackBeforeBreak, player, dimension } = event;
  if (!(itemStackBeforeBreak == null ? void 0 : itemStackBeforeBreak.hasComponent("tcsmp:durability_fix"))) return;
  if (player.getGameMode() == GameMode5.Creative) return;
  const toolTag = itemStackBeforeBreak.getTags().find((tag) => !!BlockBreakCost[tag]);
  const damage = toolTag ? BlockBreakCost[toolTag] : 2;
  const item = itemStackBeforeBreak.damage(damage);
  const slot = player.equipment.getEquipmentSlot(EquipmentSlot8.Mainhand);
  slot.setItem(item);
  if (!item) dimension.playSound(
    "random.break",
    player.getHeadLocation(),
    { pitch: 0.9 }
  );
});
var durabilityFixComponent = {
  onBeforeDurabilityDamage(event) {
    var _a, _b;
    const { itemStack, hitEntity } = event;
    const unbreaking = ((_b = (_a = itemStack == null ? void 0 : itemStack.enchantable) == null ? void 0 : _a.getEnchantment(MinecraftEnchantmentTypes.Unbreaking)) == null ? void 0 : _b.level) ?? 0;
    const toolTag = itemStack == null ? void 0 : itemStack.getTags().find((tag) => !!BlockBreakCost[tag]);
    const damage = toolTag ? EntityAttackCost[toolTag] : 0;
    event.durabilityDamage = Math.random() >= 1 / (unbreaking + 1) || hitEntity.isInvunerable ? 0 : damage;
  }
};
var durability_fix_default = durabilityFixComponent;

// scripts/item_components/nausea_spell.ts
import { TicksPerSecond as TicksPerSecond8 } from "@minecraft/server";
var nauseaSpellComponent = {
  onUse({ source }) {
    const { dimension, location } = source;
    for (const entity of dimension.getEntities({ location, maxDistance: 10 })) {
      entity.addEffect(MinecraftEffectTypes.Nausea, 30 * TicksPerSecond8);
    }
  }
};
var nausea_spell_default = nauseaSpellComponent;

// scripts/item_components/undead_spell.ts
import { EntityComponentTypes as EntityComponentTypes8, TicksPerSecond as TicksPerSecond9, world as world35 } from "@minecraft/server";
var ENTITY_COUNT = 12;
var SKELETON_CHANCE = 5 / 12;
var ValidDimensionIds = /* @__PURE__ */ new Set([
  MinecraftDimensionTypes.Overworld,
  MinecraftDimensionTypes.Nether
]);
world35.beforeEvents.itemUse.subscribe((event) => {
  const { source, itemStack } = event, { dimension } = source;
  if (!itemStack.hasComponent("tcsmp:undead_spell")) return;
  event.cancel = !ValidDimensionIds.has(dimension.id);
});
var undeadSpellComponent = {
  onUse({ source }) {
    const { dimension, location } = source;
    const faction = FactionRegistry.getFaction(source);
    const colourIndex = faction ? Object.values(FactionColour).indexOf(faction.colour) + 1 : 0;
    source.addEffect(MinecraftEffectTypes.Darkness, TicksPerSecond9 * 3.5, { showParticles: false });
    for (let i = 0; i < ENTITY_COUNT; ++i) {
      const sample = Vec2.toVectorXZ(randBoundedDisk(4, 8));
      const target = Vec3.add(location, Vec3.fromVectorXZ(sample));
      const block = dimension.getTopmostBlock(target, location.y + 4);
      if (!block) continue;
      const spawn_location = Vec3.above(block.bottomCenter());
      const entityId = Math.random() <= SKELETON_CHANCE ? "tcsmp:faded_skeleton" : "tcsmp:faded_zombie";
      const entity = dimension.spawnEntity(entityId, spawn_location);
      entity.getComponent(EntityComponentTypes8.Tameable).tame(source);
      entity.setProperty("tcsmp:faction_variant", colourIndex);
      const sound = entityId == "tcsmp:faded_zombie" ? "mob.faded_zombie.say" : "mob.faded_skeleton.say";
      dimension.playSound(sound, entity.location, { pitch: randomRange(0.8, 1.2) });
    }
  }
};
var undead_spell_default = undeadSpellComponent;

// scripts/item_components/tnt_shield.ts
import { EntityDamageCause as EntityDamageCause8, EquipmentSlot as EquipmentSlot9, GameMode as GameMode6, Player as Player28, world as world36 } from "@minecraft/server";
world36.beforeEvents.entityHurt.subscribe((event) => {
  const { damageSource, hurtEntity } = event;
  const view = hurtEntity.getViewDirection();
  const hview = Vec3.normalize(Vec3.from(view.x, 0, view.z));
  const direction = damageSource.cause == EntityDamageCause8.entityAttack ? Vec3.normalize(Vec3.sub(hurtEntity.location, damageSource.damagingEntity.location)) : Vec3.normalize(damageSource.damagingProjectile.getVelocity());
  const hdirection = Vec3.normalize(Vec3.from(direction.x, 0, direction.z));
  if (Vec3.dot(hdirection, hview) > -0.5 || !hurtEntity.isSneaking) return;
  event.cancel = isUsingTNTShield(event.hurtEntity);
}, { allowedDamageCauses: [
  EntityDamageCause8.entityAttack,
  EntityDamageCause8.projectile
] });
world36.afterEvents.projectileHitEntity.subscribe((event) => {
  const hitEntity = event.getEntityHit().entity;
  if (!hitEntity.isValid || !isUsingTNTShield(hitEntity)) return;
  hitTNTShield(hitEntity, event.hitVector);
});
world36.afterEvents.entityHitEntity.subscribe((event) => {
  const { hitEntity, damagingEntity } = event;
  if (!hitEntity.isValid || !isUsingTNTShield(hitEntity)) return;
  const toHolder = Vec3.normalize(Vec3.sub(hitEntity.location, damagingEntity.location));
  hitTNTShield(hitEntity, toHolder);
});
function isUsingTNTShield(holder) {
  var _a, _b;
  if (!holder.isSneaking) return false;
  const mainhand = (_a = holder.equipment) == null ? void 0 : _a.getEquipment(EquipmentSlot9.Mainhand);
  const offhand = (_b = holder.equipment) == null ? void 0 : _b.getEquipment(EquipmentSlot9.Offhand);
  if ((offhand == null ? void 0 : offhand.typeId) == "minecraft:shield") return false;
  return (offhand == null ? void 0 : offhand.typeId) == "tcsmp:tnt_shield" || (mainhand == null ? void 0 : mainhand.typeId) == "tcsmp:tnt_shield";
}
function hitTNTShield(holder, direction) {
  var _a, _b, _c;
  const { dimension } = holder, view = holder.getViewDirection();
  const hview = Vec3.normalize(Vec3.from(view.x, 0, view.z));
  const hdirection = Vec3.normalize(Vec3.from(direction.x, 0, direction.z));
  if (Vec3.dot(hdirection, hview) > -0.5 || !holder.isSneaking) return;
  dimension.createExplosion(holder.location, 4, {
    breaksBlocks: false,
    source: holder
  });
  holder.applyKnockback(Vec3.mul(hdirection, 1.25), 0.33);
  if (holder instanceof Player28 && holder.getGameMode() == GameMode6.Creative) return;
  const mainhand = (_a = holder.equipment) == null ? void 0 : _a.getEquipmentSlot(EquipmentSlot9.Mainhand);
  const offhand = (_b = holder.equipment) == null ? void 0 : _b.getEquipmentSlot(EquipmentSlot9.Offhand);
  const usingOffhand = (offhand == null ? void 0 : offhand.hasItem()) && offhand.typeId == "tcsmp:tnt_shield";
  const slot = usingOffhand ? offhand : mainhand;
  const item = (_c = slot == null ? void 0 : slot.getItem()) == null ? void 0 : _c.damage();
  slot == null ? void 0 : slot.setItem(item);
  if (!item) dimension.playSound(
    "random.break",
    holder.getHeadLocation(),
    { pitch: 0.9 }
  );
}

// scripts/item_components/export.ts
var ItemComponents = [
  {
    name: "tcsmp:spell_scroll",
    component: spell_scroll_default
  },
  {
    name: "tcsmp:return_spell",
    component: return_spell_default
  },
  {
    name: "tcsmp:thunder_spell",
    component: thunder_spell_default
  },
  {
    name: "tcsmp:growth_spell",
    component: growth_spell_default
  },
  {
    name: "tcsmp:decay_spell",
    component: decay_spell_default
  },
  {
    name: "tcsmp:grappling_hook",
    component: grappling_hook_default
  },
  {
    name: "tcsmp:katana",
    component: katana_default
  },
  {
    name: "tcsmp:random_exp_damage",
    component: random_exp_damage_default
  },
  {
    name: "tcsmp:lucks_bane",
    component: lucks_bane_default
  },
  {
    name: "tcsmp:backstab",
    component: backstab_default
  },
  {
    name: "tcsmp:gerbil",
    component: gerbil_default
  },
  {
    name: "tcsmp:random_effect_on_hit",
    component: random_effect_on_hit_default
  },
  {
    name: "tcsmp:global_cooldown",
    component: global_cooldown_default
  },
  {
    name: "tcsmp:auto_lore",
    component: auto_lore_default
  },
  {
    name: "tcsmp:durability_fix",
    component: durability_fix_default
  },
  {
    name: "tcsmp:nausea_spell",
    component: nausea_spell_default
  },
  {
    name: "tcsmp:undead_spell",
    component: undead_spell_default
  }
];
var export_default3 = ItemComponents;

// scripts/player_movement/slime_boots.ts
import { EquipmentSlot as EquipmentSlot10, system as system29, TicksPerSecond as TicksPerSecond10, world as world37 } from "@minecraft/server";
var Velocities = {};
var LastRidingTimes = {};
var RIDING_DELAY = 0.5 * TicksPerSecond10;
system29.runInterval(() => {
  for (const player of world37.getAllPlayers()) {
    const { dimension, equipment, location } = player;
    const lastVelocity = Velocities[player.id] ?? 0;
    const thisVelocity = player.getVelocity();
    const lastRidingTime = LastRidingTimes[player.id] ?? 0;
    const wasRiding = system29.currentTick - lastRidingTime < RIDING_DELAY;
    const below_block = player.getBlockStandingOn();
    if (!player.isSneaking && player.isOnGround && !player.isInWater && lastVelocity < -0.375 && !wasRiding && !(below_block == null ? void 0 : below_block.matches(MinecraftBlockTypes.Slime))) {
      const boots = equipment.getEquipment(EquipmentSlot10.Feet);
      if ((boots == null ? void 0 : boots.typeId) == "tcsmp:slime_boots") {
        dimension.playSound("land.slime", location, { volume: 0.22 });
        player.applyImpulse(Vec3.from(0, -0.95 * lastVelocity, 0));
      }
    }
    Velocities[player.id] = thisVelocity.y;
    if (player.entityRidingOn)
      LastRidingTimes[player.id] = system29.currentTick;
  }
});

// scripts/systems/aura.ts
import { EntityComponentTypes as EntityComponentTypes9, EntityDamageCause as EntityDamageCause9, Player as Player29, world as world38 } from "@minecraft/server";
var AuraTracking;
((AuraTracking2) => {
  function initialize() {
    world38.afterEvents.entityHurt.subscribe((event) => {
      var _a;
      switch (event.damageSource.cause) {
        case EntityDamageCause9.fall:
          const health = event.hurtEntity.getComponent(EntityComponentTypes9.Health);
          if (health.currentValue <= health.effectiveMin) break;
          updateAura(event.hurtEntity, -Math.ceil(event.damage / 2));
          break;
        case EntityDamageCause9.entityAttack:
          if (event.damageSource.damagingEntity instanceof Player29) {
            updateAura(event.damageSource.damagingEntity, 1);
            updateAura(event.hurtEntity, -1);
          }
          break;
        case EntityDamageCause9.projectile:
          const entity = event.damageSource.damagingProjectile;
          const owner = (_a = entity == null ? void 0 : entity.projectile) == null ? void 0 : _a.owner;
          if (owner instanceof Player29) {
            updateAura(owner, 2);
            updateAura(event.hurtEntity, -2);
          }
          break;
      }
    }, {
      entityTypes: [MinecraftEntityTypes.Player],
      allowedDamageCauses: [
        EntityDamageCause9.fall,
        EntityDamageCause9.entityAttack,
        EntityDamageCause9.projectile
      ]
    });
    world38.afterEvents.entityDie.subscribe((event) => {
      if (event.deadEntity instanceof Player29) updateAura(event.deadEntity, -20);
      else if (event.damageSource.damagingEntity instanceof Player29) {
        const player = event.damageSource.damagingEntity;
        const killedHealth = event.deadEntity.getComponent(EntityComponentTypes9.Health);
        updateAura(player, Math.ceil(killedHealth.effectiveMax / 10));
      }
    });
    world38.afterEvents.playerBreakBlock.subscribe((event) => {
      updateAura(event.player, 5);
    }, {
      blockTypes: [
        MinecraftBlockTypes.DiamondOre,
        MinecraftBlockTypes.DeepslateDiamondOre,
        MinecraftBlockTypes.AncientDebris
      ]
    });
  }
  AuraTracking2.initialize = initialize;
  function updateAura(entity, addition) {
    const auraScore = entity.getDynamicProperty("aura");
    const newScore = clamp(auraScore + addition, -100, 100);
    entity.setDynamicProperty("aura", newScore);
    const aura = world38.scoreboard.getObjective("aura");
    if (aura.hasParticipant(entity))
      aura.setScore(entity, newScore);
  }
  AuraTracking2.updateAura = updateAura;
})(AuraTracking || (AuraTracking = {}));

// scripts/systems/persistent_cooldowns.ts
import { world as world39 } from "@minecraft/server";
var CategoryList = /* @__PURE__ */ new Set();
world39.beforeEvents.playerLeave.subscribe(({ player }) => {
  for (const category of CategoryList) {
    const cooldown = player.getItemCooldown(category);
    player.setDynamicProperty(`cooldown/${category}`, cooldown);
  }
});
world39.afterEvents.playerSpawn.subscribe((event) => {
  const { initialSpawn, player } = event;
  if (!initialSpawn) return;
  for (const id of player.getDynamicPropertyIds()) {
    const [type, category] = id.split("/");
    if (type != "cooldown") continue;
    const duration = player.getDynamicProperty(id);
    player.startItemCooldown(category, duration);
  }
});
var PersistentCooldowns;
((PersistentCooldowns2) => {
  function register(cooldownCategory) {
    CategoryList.add(cooldownCategory);
  }
  PersistentCooldowns2.register = register;
})(PersistentCooldowns || (PersistentCooldowns = {}));

// scripts/main.ts
system30.beforeEvents.startup.subscribe(({ blockComponentRegistry, itemComponentRegistry, customCommandRegistry }) => {
  for (const register of export_default3)
    itemComponentRegistry.registerCustomComponent(register.name, register.component);
  for (const register of export_default)
    blockComponentRegistry.registerCustomComponent(register.name, register.component);
  for (const register of enums_default)
    customCommandRegistry.registerEnum(register.name, register.values);
  for (const register of export_default2)
    customCommandRegistry.registerCommand(register.command, register.callback);
  PersistentCooldowns.register("spell");
});
world40.afterEvents.worldLoad.subscribe(() => {
  if (!world40.scoreboard.getObjective("aura"))
    world40.scoreboard.setObjectiveAtDisplaySlot(DisplaySlotId.BelowName, {
      objective: world40.scoreboard.addObjective("aura", "Aura")
    });
  AuraTracking.initialize();
  WaypointManager.refreshFactionWaypoints();
});
world40.afterEvents.playerSpawn.subscribe((event) => {
  const { initialSpawn, player } = event;
  if (!initialSpawn) return;
  player.setDynamicProperty("tcsmp:faction_invite");
  NameRegistry.setName(player.id, player.name);
  const faction = FactionRegistry.getFaction(player);
  if (faction) {
    player.nameTag = player.name + `
\xA7${faction.colour}${faction.name}\xA7r`;
    WaypointManager.refreshFactionWaypoints();
  }
  player.removeTag("tcsmp:is_being_dragged");
  if (!player.getDynamicProperty("aura")) {
    player.setDynamicProperty("aura", 0);
    world40.scoreboard.getObjective("aura").setScore(player, 0);
  }
});
//# sourceMappingURL=main.js.map